// Package agent is the harness core: the model↔tools loop, extracted from
// any particular frontend. A Session holds one conversation; frontends
// (terminal REPL, web server) drive it through Send and receive everything
// worth rendering through the Events interface. This package never prints —
// the repo's "domain layer silent, frontends own output" convention applied
// to the agent itself.
package agent

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"reflect"
	"sync"
	"time"

	"github.com/davidadel66/evie/internal/memory"
	"github.com/davidadel66/evie/internal/openrouter"
	"github.com/davidadel66/evie/internal/tools"
)

const DefaultModel = openrouter.AstraModel

var ErrBusy = errors.New("agent: a turn is already in progress")

type sessionUnavailableError struct{ cause error }

func (e sessionUnavailableError) Error() string {
	return fmt.Sprintf("acquire turn lease: %v", e.cause)
}

func (e sessionUnavailableError) Unwrap() []error {
	return []error{ErrSessionUnavailable, e.cause}
}

type Session struct {
	mu        sync.Mutex
	client    Client
	compactor Client
	toolset   tools.Toolset
	// legacyToolsetPending supports the former New + Send(extra...) entry
	// point. It is resolved once, before the first turn, and never changes
	// afterward. New production sessions use NewWithToolset instead.
	legacyToolsetPending bool
	legacyToolSignatures []legacyToolSignature
	profile              openrouter.ContextProfile
	reasoning            *openrouter.ReasoningConfig
	configurationErr     error
	history              History
	scope                memory.ScopeContext
	owner                TurnOwnership
	composer             *ContextComposer
	timing               turnTiming
}

type legacyToolSignature struct {
	Schema        openrouter.Tool
	NeedsApproval bool
	HasExecute    bool
	HasPrepare    bool
}
type Client interface {
	// ChatStream callbacks need not be synchronous with its return. Session
	// owns a per-call lifetime gate that closes admission and joins admitted
	// callbacks before it inspects the response or advances turn state.
	ChatStream(
		ctx context.Context,
		req openrouter.ChatRequest,
		h openrouter.StreamHandlers,
	) (openrouter.ChatResponse, error)
}
type Events interface {
	Delta(text string)                         // streaming assistant text
	Reasoning(text string)                     // public thinking text; empty starts activity
	ReasoningDone()                            // thinking ended for this assistant message
	AssistantDone(content string)              // authoritative committed content for every assistant message, even empty (tool-only)
	ToolCall(id, name, args string)            // durable intent, before preparation and approval
	ToolResult(id, content string, isErr bool) // tool finished (includes declines)
	ResponseDiscarded(reason DiscardReason, message string)
}

// ActivityEvents optionally enriches the public transcript at durable commit
// boundaries. AssistantCommitted replaces AssistantDone, never duplicates it.
// Provider callbacks are joined before either assistant notification.
type ActivityEvents interface {
	TurnStarted(id memory.EventID, at time.Time)
	AssistantCommitted(event memory.Event)
}

func (s *Session) Send(
	ctx context.Context,
	input string,
	ev Events,
	approve tools.Approver,
	extra ...tools.Tool,
) (retErr error) {
	if s.configurationErr != nil {
		return s.configurationErr
	}
	observation := beginForegroundObservation(ctx, s.history)
	defer observation.finish()
	if !s.mu.TryLock() {
		return ErrBusy
	}
	defer s.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return err
	}
	if s.owner == nil {
		return errors.New("agent: turn ownership is not configured")
	}
	signatures := legacyToolSignatures(extra)
	if !s.legacyToolsetPending && len(extra) != 0 && !reflect.DeepEqual(signatures, s.legacyToolSignatures) {
		return errors.New("agent: session Toolset is already pinned")
	}

	lease, err := s.owner.Acquire(ctx, s.timing.leaseDuration)
	if err != nil {
		if s.owner.IsConflict(err) {
			return fmt.Errorf("%w: %v", ErrLeaseConflict, err)
		}
		if s.owner.IsSessionInactive(err) {
			return sessionUnavailableError{cause: err}
		}
		return fmt.Errorf("acquire turn lease: %w", err)
	}
	if s.legacyToolsetPending {
		s.toolset = s.toolset.WithTools(extra)
		s.legacyToolSignatures = signatures
		s.legacyToolsetPending = false
	}

	coordinator := newTurnCoordinator(ctx)
	coordinator.setStage(memory.StageTurnStart)
	defer coordinator.cancel()
	stopHeartbeat := s.startHeartbeat(ctx, coordinator, lease)
	defer func() {
		stopHeartbeat()
		cleanupCtx, cancel := s.timing.newCleanupContext(ctx, s.timing.cleanupTimeout)
		defer cancel()
		if releaseErr := s.owner.Release(cleanupCtx, lease); releaseErr != nil {
			retErr = errors.Join(retErr, fmt.Errorf("release turn lease: %w", releaseErr))
		}
	}()

	if err := ctx.Err(); err != nil {
		coordinator.selectCause(callerCause(err), err, 0)
		return err
	}

	rootEvent, err := s.history.Append(coordinator.ctx, lease, memory.EventInput{
		Type:    memory.EventUserMessage,
		Role:    memory.RoleUser,
		Content: input,
	})
	if err != nil {
		if cause := coordinator.result(); cause.kind != causeNone {
			return cause.err
		}
		if ctxErr := ctx.Err(); ctxErr != nil {
			coordinator.selectCause(callerCause(ctxErr), ctxErr, 0)
			return ctxErr
		}
		if s.owner.IsLeaseLost(err) {
			coordinator.selectCause(causeLeaseLost, err, 0)
			return fmt.Errorf("%w: %v", ErrLeaseLost, err)
		}
		coordinator.selectCause(causeStorage, err, 0)
		return fmt.Errorf("persist user message: %w", err)
	}
	if observation != nil {
		observation.record.RootID = rootEvent.ID
	}
	if activity, ok := ev.(ActivityEvents); ok {
		activity.TurnStarted(rootEvent.ID, rootEvent.RecordedAt)
	}
	progress := &turnProgress{rootTurnID: rootEvent.ID, requestParentID: rootEvent.ID, foreground: observation}
	turnErr := s.runOwnedTurn(coordinator, lease, ev, approve, progress)
	if turnErr != nil && coordinator.result().kind == causeNone {
		coordinator.selectCause(causeStorage, turnErr, 0)
	}

	cause := coordinator.result()
	if cause.kind == causeSuccess {
		return nil
	}
	if cause.err != nil {
		turnErr = cause.err
	}

	stopHeartbeat()
	if rootEvent.ID != "" && causeHasDurableTerminal(cause.kind) {
		terminalCtx, cancel := s.timing.newCleanupContext(ctx, s.timing.cleanupTimeout)
		terminalStarted := time.Now()
		terminalErr := s.appendTerminal(terminalCtx, lease, rootEvent.ID, progress.requestParentID, cause)
		cancel()
		if terminalErr == nil {
			outcome := "failed"
			if cause.kind == causeCallerCancelled || cause.kind == causeCallerDeadline {
				outcome = "interrupted"
			}
			observation.terminal(terminalStarted, outcome)
		}
		if terminalErr != nil {
			turnErr = errors.Join(turnErr, fmt.Errorf("persist terminal event: %w", terminalErr))
		}
	}
	wasRendered, reasoningOpen, assistantCommitted := progress.rendered.discardState()
	if reasoningOpen {
		ev.ReasoningDone()
	}
	if wasRendered && !assistantCommitted {
		if reason := cause.discardReason(); reason != "" {
			ev.ResponseDiscarded(reason, DiscardedResponseMessage)
		}
	}
	return turnErr
}

func legacyToolSignatures(definitions []tools.Tool) []legacyToolSignature {
	if len(definitions) == 0 {
		return nil
	}
	schemas := tools.NewToolset(definitions).Schemas()
	signatures := make([]legacyToolSignature, len(definitions))
	for i, definition := range definitions {
		signatures[i] = legacyToolSignature{
			Schema:        schemas[i],
			NeedsApproval: definition.NeedsApproval,
			HasExecute:    definition.Execute != nil,
			HasPrepare:    definition.Prepare != nil,
		}
	}
	return signatures
}

func resolveReasoning(v string) *openrouter.ReasoningConfig {
	switch v {
	case "off":
		return nil
	case "high", "medium", "low":
		return &openrouter.ReasoningConfig{Effort: v}
	default:
		return &openrouter.ReasoningConfig{Enabled: true}
	}
}

func resolveModelReasoning(model, value string) (*openrouter.ReasoningConfig, error) {
	if !openrouter.UsesResponses(model) {
		return resolveReasoning(value), nil
	}
	switch value {
	case "", "on":
		return &openrouter.ReasoningConfig{Effort: "low", Summary: "concise"}, nil
	case "low", "medium", "high", "xhigh", "max":
		return &openrouter.ReasoningConfig{Effort: value, Summary: "concise"}, nil
	default:
		return nil, errors.New("Astra requires EVIE_REASONING=on, low, medium, high, xhigh, or max; reasoning cannot be disabled")
	}
}

// ValidateModelConfiguration is shared by CLI/server startup before creating
// durable sessions. Constructors also retain the error for embedded callers.
func ValidateModelConfiguration(model string) error {
	_, err := resolveModelReasoning(model, os.Getenv("EVIE_REASONING"))
	return err
}

func New(
	client Client,
	profile openrouter.ContextProfile,
	history History,
	scope memory.ScopeContext,
	owner TurnOwnership,
) *Session {
	session := NewWithToolset(client, profile, history, scope, owner, tools.BuiltinToolset())
	session.legacyToolsetPending = true
	return session
}

// NewWithToolset constructs a session with one resolved immutable Toolset.
func NewWithToolset(
	client Client,
	profile openrouter.ContextProfile,
	history History,
	scope memory.ScopeContext,
	owner TurnOwnership,
	toolset tools.Toolset,
) *Session {
	return NewWithCompactorAndToolset(client, client, profile, history, scope, owner, toolset)
}

// NewWithCompactor keeps summary generation separately controllable while the
// default New constructor uses the existing conversational transport for both
// request kinds.
func NewWithCompactor(
	client Client,
	compactor Client,
	profile openrouter.ContextProfile,
	history History,
	scope memory.ScopeContext,
	owner TurnOwnership,
) *Session {
	session := NewWithCompactorAndToolset(
		client, compactor, profile, history, scope, owner, tools.BuiltinToolset(),
	)
	session.legacyToolsetPending = true
	return session
}

// NewWithCompactorAndToolset constructs a session with independently supplied
// conversational and compaction clients plus one resolved immutable Toolset.
func NewWithCompactorAndToolset(
	client Client,
	compactor Client,
	profile openrouter.ContextProfile,
	history History,
	scope memory.ScopeContext,
	owner TurnOwnership,
	toolset tools.Toolset,
) *Session {
	reasoning, configurationErr := resolveModelReasoning(profile.Model(), os.Getenv("EVIE_REASONING"))
	return &Session{
		client:           client,
		compactor:        compactor,
		toolset:          toolset,
		profile:          profile,
		reasoning:        reasoning,
		configurationErr: configurationErr,
		scope:            scope,
		history:          history,
		owner:            owner,
		composer:         NewContextComposer(CanonicalRequestEstimator{}),
		timing:           defaultTurnTiming,
	}
}

func (s *Session) ContextProfile() openrouter.ContextProfileDiagnostics {
	return s.profile.Diagnostics()
}

func assistantEventInput(msg openrouter.Message, usage *openrouter.TokenUsage) (
	memory.EventInput, error,
) {
	payload := memory.AssistantMessagePayload{
		ToolCalls: make([]memory.ToolCall, len(msg.ToolCalls)),
		Usage:     memoryUsage(usage),
	}
	for _, part := range msg.TextParts {
		payload.TextParts = append(payload.TextParts, memory.AssistantTextPart{Text: part.Text, Phase: part.Phase, AfterToolCalls: part.AfterToolCalls})
	}

	for i, call := range msg.ToolCalls {
		payload.ToolCalls[i] = memory.ToolCall{
			ID:        call.ID,
			Name:      call.Function.Name,
			Arguments: call.Function.Arguments,
		}
	}

	if err := payload.ValidateTextParts(msg.Content); err != nil {
		return memory.EventInput{}, err
	}
	payloadJSON, err := json.Marshal(payload)
	if err != nil {
		return memory.EventInput{}, fmt.Errorf("encode assistant payload: %w", err)
	}

	return memory.EventInput{
		Type:    memory.EventAssistantMessage,
		Role:    memory.RoleAssistant,
		Content: msg.Content,
		Payload: payloadJSON,
	}, nil
}

func memoryUsage(usage *openrouter.TokenUsage) *memory.TokenUsage {
	if usage == nil {
		return nil
	}
	mapped := &memory.TokenUsage{
		InputTokens:           nonNegativeInt64(usage.InputTokens),
		OutputTokens:          nonNegativeInt64(usage.OutputTokens),
		TotalTokens:           nonNegativeInt64(usage.TotalTokens),
		ReasoningOutputTokens: nonNegativeInt64(usage.ReasoningOutputTokens),
		CachedInputTokens:     nonNegativeInt64(usage.CachedInputTokens),
		CacheWriteInputTokens: nonNegativeInt64(usage.CacheWriteInputTokens),
	}
	if mapped.InputTokens == nil && mapped.OutputTokens == nil && mapped.TotalTokens == nil &&
		mapped.ReasoningOutputTokens == nil && mapped.CachedInputTokens == nil &&
		mapped.CacheWriteInputTokens == nil {
		return nil
	}
	return mapped
}

func nonNegativeInt64(value *int64) *int64 {
	if value == nil || *value < 0 {
		return nil
	}
	copy := *value
	return &copy
}

func toolIntentInput(
	parentID memory.EventID,
	executionID memory.ExecutionID,
	call openrouter.ToolCall,
) (memory.EventInput, error) {
	payloadJSON, err := json.Marshal(memory.ToolIntentPayload{
		Call: memory.ToolCall{
			ID:        call.ID,
			Name:      call.Function.Name,
			Arguments: call.Function.Arguments,
		},
	})
	if err != nil {
		return memory.EventInput{}, fmt.Errorf("encode tool intent payload: %w", err)
	}

	return memory.EventInput{
		ParentID:    parentID,
		Type:        memory.EventToolIntent,
		ExecutionID: executionID,
		Payload:     payloadJSON,
	}, nil
}

func toolOutcomeInput(
	parentID memory.EventID,
	executionID memory.ExecutionID,
	result openrouter.Message,
	eventType memory.EventType,
) (memory.EventInput, error) {
	switch eventType {
	case memory.EventToolSucceeded,
		memory.EventToolFailed,
		memory.EventToolCancelled:
	default:
		return memory.EventInput{}, fmt.Errorf(
			"invalid tool outcome type %q",
			eventType,
		)
	}

	payloadJSON, err := json.Marshal(memory.ToolResultPayload{
		ToolCallID: result.ToolCallID,
		IsError:    eventType == memory.EventToolFailed,
	})
	if err != nil {
		return memory.EventInput{}, fmt.Errorf("encode tool outcome payload: %w", err)
	}

	return memory.EventInput{
		ParentID:    parentID,
		Type:        eventType,
		Role:        memory.RoleTool,
		ExecutionID: executionID,
		Content:     result.Content,
		Payload:     payloadJSON,
	}, nil
}

func approvalEventInput(
	parentID memory.EventID,
	executionID memory.ExecutionID,
	decision tools.Decision,
) (memory.EventInput, error) {
	return approvalEventInputWithHashes(parentID, executionID, decision, "", "")
}

func semanticApprovalEventInput(
	parentID memory.EventID,
	executionID memory.ExecutionID,
	decision tools.Decision,
	proposalSHA256 string,
	preparedSHA256 string,
) (memory.EventInput, error) {
	if proposalSHA256 == "" || preparedSHA256 == "" {
		return memory.EventInput{}, errors.New("semantic approval requires exact proposal and prepared hashes")
	}
	return approvalEventInputWithHashes(parentID, executionID, decision, proposalSHA256, preparedSHA256)
}

func approvalEventInputWithHashes(
	parentID memory.EventID,
	executionID memory.ExecutionID,
	decision tools.Decision,
	proposalSHA256 string,
	preparedSHA256 string,
) (memory.EventInput, error) {
	var storedDecision memory.ApprovalDecision

	switch decision {
	case tools.Approved:
		storedDecision = memory.ApprovalApproved
	case tools.Declined:
		storedDecision = memory.ApprovalDeclined
	case tools.Expired:
		storedDecision = memory.ApprovalExpired
	default:
		return memory.EventInput{}, fmt.Errorf(
			"unsupported approval decision %d",
			decision,
		)
	}

	payloadJSON, err := json.Marshal(memory.ApprovalPayload{
		Decision:       storedDecision,
		ProposalSHA256: proposalSHA256,
		PreparedSHA256: preparedSHA256,
	})
	if err != nil {
		return memory.EventInput{}, fmt.Errorf("encode approval payload: %w", err)
	}

	return memory.EventInput{
		ParentID:    parentID,
		Type:        memory.EventApproval,
		ExecutionID: executionID,
		Payload:     payloadJSON,
	}, nil
}
