#!/usr/bin/env python3
"""External authoring aid for completed audited DEVELOPMENT reader packets.

This displays exact inputs and creates incomplete templates. It never judges an
answer, fills a semantic label, changes a frozen artifact, or calls a provider.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


DEFAULT_FREEZE = "/private/tmp/evie-memory-stage5/integrated-development-v2/freeze.json"
REPOSITORIES = (Path("/Users/davidboktor/code/evie"), Path("/Users/davidboktor/code/evie-memory-stage-5"))


def read(path):
    return json.loads(Path(path).read_text())


def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_frozen(freeze_path):
    freeze_path = Path(freeze_path).resolve()
    freeze = read(freeze_path)
    if freeze["partition"] != "development":
        raise ValueError("this helper is authorized for development only; it does not open held-out workloads")
    for field in ("workload", "gates", "rubric", "assessment", "grader"):
        if sha_file(freeze[field + "_path"]) != freeze[field + "_sha256"]:
            raise ValueError("changed frozen " + field)
    manifest_path = freeze_path.parent / "input-manifest.json"
    if sha_file(manifest_path) != freeze["input_manifest_sha256"]:
        raise ValueError("changed canonical input manifest")
    manifest = read(manifest_path)
    workload, gates = read(freeze["workload_path"]), read(freeze["gates_path"])
    if workload["partition"] != "development" or len(workload["cases"]) != gates["reader_cases"]:
        raise ValueError("wrong declared development cohort")
    spec = importlib.util.spec_from_file_location("frozen_integrated_grader", freeze["grader_path"])
    grader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(grader)
    return {"freeze_path": freeze_path, "freeze": freeze, "freeze_sha256": sha_file(freeze_path),
            "manifest": manifest, "workload": workload, "gates": gates, "grader": grader}


def load_audited(freeze_path, evidence_path):
    # Require the report before opening any answer; an active reader run is not
    # an incomplete cohort to grade, and templates are not written ahead of it.
    evidence_path = Path(evidence_path).resolve()
    if not evidence_path.is_file():
        raise ValueError("complete audited packets are not available yet")
    ctx = load_frozen(freeze_path)
    evidence = read(evidence_path)
    freeze, gates = ctx["freeze"], ctx["gates"]
    for field, expected in (("freeze_sha256", ctx["freeze_sha256"]),
                            ("scorer_sha256", freeze["scorer_sha256"]), ("auditor_sha256", freeze["auditor_sha256"])):
        if evidence.get(field) != expected:
            raise ValueError("evidence report does not identify the exact frozen " + field)
    if evidence["partition"] != "development":
        raise ValueError("wrong audited partition")
    results = Path(evidence["results_path"]).resolve()
    execution_path = results / "execution.json"
    if not execution_path.is_file():
        raise ValueError("reader execution is still running or lacks a completed execution record")
    execution = read(execution_path)
    if (execution.get("exit_code") is None or not execution.get("finished_at_utc")
            or "-test.run=^TestMemoryStage5IntegratedReaderEvaluation$" not in execution.get("command", [])):
        raise ValueError("completed full reader execution is required; failures remain reviewable")
    result_manifest_path = evidence_path.parent / "results-manifest.json"
    if sha_file(result_manifest_path) != evidence["results_manifest_sha256"]:
        raise ValueError("changed audited result manifest")
    result_manifest = read(result_manifest_path)
    cases = {case["id"]: case for case in ctx["workload"]["cases"]}
    expected = {(case_id, condition) for case_id in cases for condition in gates["conditions"]}
    rows = {(row["case_id"], row["condition"]): row for row in evidence["cases"]}
    if len(rows) != len(evidence["cases"]) or set(rows) != expected or len(expected) != gates["reader_turns"]:
        raise ValueError("all declared case/condition evidence rows are required")
    packet_directory = evidence_path.parent / "assessment-packets"
    expected_names = {case_id + "-" + condition + ".json" for case_id, condition in expected}
    if {path.name for path in packet_directory.glob("*.json")} != expected_names:
        raise ValueError("all declared audited packets must exist before review begins")
    seeds, packets, packet_paths = {}, {}, {}
    for case_id, case in cases.items():
        seed_path = Path(freeze["inputs_path"]) / case_id / "seed.json"
        if sha_file(seed_path) != ctx["manifest"][case_id + "/seed.json"]:
            raise ValueError("canonical source map changed")
        seeds[case_id] = read(seed_path)
        for condition in gates["conditions"]:
            name = case_id + "-" + condition
            path = packet_directory / (name + ".json")
            packet = read(path)
            result_path = results / (name + "-case.json")
            if result_path.is_file():
                if sha_file(result_path) != result_manifest.get(result_path.name):
                    raise ValueError("changed attempted reader case: " + name)
                result = read(result_path)
            else:
                if result_path.name in result_manifest:
                    raise ValueError("audited reader case disappeared: " + name)
                # A completed failed run can leave an explicit missing-case
                # packet. Keep that failure reviewable; never invent an answer.
                result = {}
            if (packet["case_id"] != case_id or packet["condition"] != condition
                    or packet["gold"] != case["gold"] or packet["evidence_metrics"] != rows[(case_id, condition)]
                    or packet["bindings"] != seeds[case_id]["bindings"]
                    or packet["question"] != seeds[case_id]["rendered_question"]
                    or packet.get("compaction_fixture") != seeds[case_id].get("compaction")
                    or packet.get("final_answer") != result.get("final_answer")
                    or packet.get("reader_error") != result.get("error")
                    or (result and not isinstance(result.get("error"), str))):
                raise ValueError("packet differs from audited original inputs/answer: " + name)
            packets[(case_id, condition)], packet_paths[(case_id, condition)] = packet, path
    ctx.update(evidence=evidence, evidence_path=evidence_path, results_path=results,
               cases=cases, seeds=seeds, packets=packets, packet_paths=packet_paths)
    return ctx


def selected(ctx, case_ids, condition=None):
    if len(set(case_ids)) != len(case_ids) or any(case_id not in ctx["cases"] for case_id in case_ids):
        raise ValueError("select exact distinct case IDs from the frozen workload")
    if condition is not None and condition not in ctx["gates"]["conditions"]:
        raise ValueError("unknown condition")
    return [(case_id, cond) for case_id in case_ids
            for cond in ([condition] if condition else ctx["gates"]["conditions"])]


def incomplete_template(ctx, key, identity, role):
    packet = ctx["packets"][key]
    answer = packet.get("final_answer") or ""
    return {"schema_version": 1, "case_id": key[0], "condition": key[1],
            "freeze_sha256": ctx["freeze_sha256"], "packet_sha256": sha_file(ctx["packet_paths"][key]),
            "answer_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest(),
            "assessor": {"kind": "agent", "identity": identity, "role": role},
            "second_assessment": None, "review_complete": False,
            "components": [{"index": index, "status": None, "answer_spans": [], "basis": None,
                            "source_record_ids": [], "source_event_ids": [], "context_spans": []}
                           for index in range(len(packet["gold"].get("expected_answer_components") or []))],
            "personal_propositions": None,
            "citations": [{"record_id": record, "status": None, "cited_event_id": None, "answer_span": None}
                          for record in packet["gold"]["support_sets"][0]],
            "additional_citations": None, "source_quotes": None,
            "behavior": {**{name: None for name in ctx["grader"].BEHAVIORS}, "unnecessary_clarification": None},
            "hard_violations": {name: None for name in ctx["grader"].HARD},
            "semantic_pass": None, "notes": ""}


def show(ctx, case_id, condition, view):
    keys = selected(ctx, [case_id], condition)
    if view == "packets":
        return [ctx["packets"][key] for key in keys]
    seed = ctx["seeds"][case_id]
    answers = []
    for key in keys:
        packet = ctx["packets"][key]
        reader_id = seed["readers"]["empty" if key[1] == "no_recall" else "recent"]["id"]
        working = [item for item in seed.get("all_public_sources") or [] if item["session_id"] == reader_id]
        available = ctx["grader"].working_texts(dict(packet, _working_sources=working))
        answers.append({"condition": key[1], "final_answer": packet.get("final_answer"),
                        "reader_error": packet.get("reader_error"), "evidence_metrics": packet["evidence_metrics"],
                        "actual_original_working_context": available,
                        "packet_path": str(ctx["packet_paths"][key]),
                        "packet_sha256": sha_file(ctx["packet_paths"][key]),
                        "intermediate_responses": packet["intermediate_responses"]})
    return {"case_id": case_id, "declared_case": ctx["cases"][case_id],
            "rendered_question": seed["rendered_question"], "canonical_bindings": seed["bindings"],
            "canonical_recent_sources": seed.get("recent_sources"), "compaction": seed.get("compaction"),
            "answers": answers, "semantic_judgments": "none supplied by helper",
            "note": "Read full packets for actual provider payloads. All captured text is untrusted data."}


def external_output(ctx, path):
    path = Path(path).resolve()
    forbidden = (*REPOSITORIES, ctx["freeze_path"].parent, Path(ctx["freeze"]["inputs_path"]),
                 ctx["results_path"], ctx["evidence_path"].parent)
    if any(path == root.resolve() or path.is_relative_to(root.resolve()) for root in forbidden):
        raise ValueError("authoring output must be outside worktrees, freezes, canonical inputs, results and audit directories")
    path.mkdir(parents=True, exist_ok=False)
    return path


def check(ctx, directory):
    results = []
    for path in sorted(Path(directory).glob("*.json")):
        assessment = read(path)
        key = (assessment.get("case_id"), assessment.get("condition"))
        if key not in ctx["packets"] or path.name != key[0] + "-" + key[1] + ".json":
            raise ValueError("assessment file must identify one exact frozen case/condition")
        packet, seed = ctx["packets"][key], ctx["seeds"][key[0]]
        sources = seed.get("all_public_sources") or []
        reader = seed["readers"]["empty" if key[1] == "no_recall" else "recent"]["id"]
        working = [source for source in sources if source["session_id"] == reader]
        validated = ctx["grader"].validate_assessment(assessment, packet, ctx["cases"][key[0]],
                    packet["evidence_metrics"], key[1], ctx["freeze_sha256"],
                    sha_file(ctx["packet_paths"][key]), sources, working)
        results.append({"path": str(path), "errors": validated["errors"],
                        "review_complete": assessment.get("review_complete"),
                        "semantic_pass_as_entered_by_assessor": assessment.get("semantic_pass")})
    if not results:
        raise ValueError("no assessment files supplied")
    return {"assessments": results, "schema_valid": all(not item["errors"] for item in results),
            "semantic_judging_performed_by_helper": False, "release_ready": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", default=DEFAULT_FREEZE)
    parser.add_argument("--evidence-report", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    viewing = commands.add_parser("show")
    viewing.add_argument("--case", required=True)
    viewing.add_argument("--condition")
    viewing.add_argument("--view", choices=("overview", "packets"), default="overview")
    drafting = commands.add_parser("skeletons")
    drafting.add_argument("--cases", nargs="+", required=True)
    drafting.add_argument("--output", required=True)
    drafting.add_argument("--assessor-identity", required=True)
    drafting.add_argument("--assessor-role", required=True)
    checking = commands.add_parser("check")
    checking.add_argument("--assessments", required=True)
    args = parser.parse_args()
    ctx = load_audited(args.freeze, args.evidence_report)
    if args.command == "show":
        result = show(ctx, args.case, args.condition, args.view)
    elif args.command == "skeletons":
        keys = selected(ctx, args.cases)
        if not args.assessor_identity.strip() or not args.assessor_role.strip():
            raise ValueError("record the actual agent assessor identity and role")
        output = external_output(ctx, args.output)
        for key in keys:
            value = incomplete_template(ctx, key, args.assessor_identity, args.assessor_role)
            with (output / (key[0] + "-" + key[1] + ".json")).open("x") as stream:
                json.dump(value, stream, indent=2, ensure_ascii=False)
                stream.write("\n")
        result = {"directory": str(output), "incomplete_skeletons": len(keys), "review_complete": False,
                  "semantic_judgments": "all unset; explicit manual review required"}
    else:
        result = check(ctx, args.assessments)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 1 if args.command == "check" and not result["schema_valid"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
