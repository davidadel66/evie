"""Format-only controls; no model output or workload quality measurements."""
import copy
import importlib.util
import unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('existing_grade_controls', '/tmp/evie-stage5-grade-control-checks.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
grade=old.grade

class CitationControls(unittest.TestCase):
    def extra(self):
        c,p,r,a=old.example()
        p['bindings']['r2']={'source': {'event_id':'event-2','session_id':'source','actor':'owner','evidence':'Another attributed original.'}}
        r['union'].append('r2')
        p['final_answer'] += ' Also source event-2.'
        a['answer_sha256']=grade.sha(p['final_answer'].encode())
        a['additional_citations']=[{'status':'correct','cited_event_id':'event-2','answer_span':'Also source event-2.','source_record_ids':['r2'],'source_event_ids':['event-2']}]
        return c,p,r,a
    def evaluate(self,c,p,r,a):
        return grade.validate_assessment(a,p,c,r,a['condition'],'freeze','packet')
    def test_correct_extra_counts_in_total(self):
        result=self.evaluate(*self.extra())
        self.assertEqual(result['errors'],[])
        self.assertEqual((result['citation_hits'],result['required_citation_hits'],result['additional_citation_hits'],result['additional_citation_denominator']),(2,1,1,1))
    def test_wrong_known_extra_cannot_pass_and_retains_denominator(self):
        c,p,r,a=self.extra();a['additional_citations'][0]['status']='wrong'
        result=self.evaluate(c,p,r,a)
        self.assertIn('semantic pass contradicts an incorrect original source citation',result['errors'])
        a['semantic_pass']=False
        result=self.evaluate(c,p,r,a)
        self.assertEqual(result['errors'],[])
        self.assertEqual((result['citation_hits'],result['required_citation_hits'],result['additional_citation_hits'],result['additional_citation_denominator']),(1,1,0,1))
    def test_missing_explicit_additional_inventory_is_invalid(self):
        c,p,r,a=self.extra();del a['additional_citations']
        result=self.evaluate(c,p,r,a)
        self.assertIn('additional_citations must explicitly enumerate any other citations',result['errors'])
    def test_baseline_absence_permits_missing_but_never_wrong_citation(self):
        c,p,r,a=self.extra();r['union']=[];a['condition']='no_recall';a['additional_citations']=[]
        p['final_answer']='I cannot recall. Source event-2.';a['answer_sha256']=grade.sha(p['final_answer'].encode())
        a['components'][0].update(status='missing',answer_spans=[],**old.basis('none'));a['personal_propositions']=[]
        a['citations'][0].update(status='wrong',cited_event_id='event-2',answer_span='Source event-2.')
        result=self.evaluate(c,p,r,a)
        self.assertIn('semantic pass contradicts an incorrect original source citation',result['errors'])
        a['citations'][0].update(status='missing',cited_event_id='',answer_span='')
        self.assertEqual(self.evaluate(c,p,r,a)['errors'],[])

if __name__=='__main__':
    suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(old.Controls),unittest.defaultTestLoader.loadTestsFromTestCase(CitationControls)])
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
