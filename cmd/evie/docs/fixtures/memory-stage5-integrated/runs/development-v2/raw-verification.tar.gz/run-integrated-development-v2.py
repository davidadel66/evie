from pathlib import Path
import json,subprocess,hashlib,importlib.util
from datetime import datetime,timezone
base=Path('/tmp/evie-memory-stage5');root=Path('/Users/davidboktor/code/evie-memory-stage-5')
cmd=json.loads((base/'integrated-freeze-v2-command.json').read_text());runner=Path(cmd[1])
s=importlib.util.spec_from_file_location('runner',runner);r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
plan=base/'integrated-development-v2-plan.json'
r.write_json(plan,dict(declared_at_utc=datetime.now(timezone.utc).isoformat(),freeze_command=cmd,measurement_order=['index','local','operating','reader'],failure_policy='No retry or warmup. Preserve every first attempt; continue independent local/operating diagnostics after failure, withhold reader generation if any of those prerequisite executions fail.',gates_sha256=r.sha256(root/'cmd/evie/docs/fixtures/memory-stage5-integrated/adopted-gates-v1.json')))
def execute(command,stem):
 with (base/(stem+'-console.log')).open('x') as log:
  completed=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps(dict(stage=stem,exit_code=completed.returncode)),flush=True)
 return completed.returncode
if execute(cmd,'integrated-freeze-v2'):raise SystemExit(1)
freeze=(base/'integrated-development-v2/freeze.json').resolve();f=json.loads(freeze.read_text())
attestation=json.loads((base/'integrated-development-v2-checks/deterministic-pending-freeze.json').read_text())
manifest=json.loads((freeze.parent/'compiled-source-manifest.json').read_text())
assert manifest==json.loads((base/'integrated-development-v2-checks/verified-source-manifest.json').read_text())
assert manifest=={n:r.sha256(root/n) for n in manifest}
assert attestation['matrix_sha256']==f['matrix_sha256']
attestation.update(freeze_sha256=r.sha256(freeze),compiled_source_manifest_sha256=f['compiled_source_manifest_sha256'])
r.write_json(base/'integrated-development-v2-deterministic.json',attestation)
failures=[]
for mode in ['index','local','operating']:
 command=['python3','-B',str(freeze.parent/'run.py'),'run','--freeze',str(freeze),'--mode',mode,'--output',str(base/('integrated-development-v2-'+mode))]
 r.write_json(base/('integrated-development-v2-'+mode+'-command.json'),command)
 if execute(command,'integrated-development-v2-'+mode):failures.append(mode)
if failures:
 r.write_json(base/'integrated-development-v2-reader-not-run.json',dict(reason='Prerequisite execution failed; no reader generations started.',failed_modes=failures,recorded_at_utc=datetime.now(timezone.utc).isoformat()))
 raise SystemExit(1)
command=['python3','-B',str(freeze.parent/'run.py'),'run','--freeze',str(freeze),'--mode','reader','--output',str(base/'integrated-development-v2-reader')]
r.write_json(base/'integrated-development-v2-reader-command.json',command)
raise SystemExit(execute(command,'integrated-development-v2-reader'))
