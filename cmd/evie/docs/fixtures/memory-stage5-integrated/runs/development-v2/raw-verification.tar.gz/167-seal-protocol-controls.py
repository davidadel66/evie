"""Synthetic protocol-only controls; no evaluation inputs/results/model calls."""
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
REPO=Path('/Users/davidboktor/code/evie-memory-stage-5')
spec=importlib.util.spec_from_file_location('seal_runner',REPO/'cmd/evie/docs/fixtures/memory-stage5-integrated/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
STUB='''"""FORMAT-ONLY pure auditor stub: does not represent any measurement."""
import hashlib,json
from pathlib import Path
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def build_report(**inputs):
    return {'schema_version':1,'freeze_sha256':sha(inputs['freeze']),
      'partition':'development','complete':True,'all_required_gates_pass':True,
      'release_ready':False,'resource_aggregator_sha256':sha(__file__),
      'gates':[{'id':'synthetic-format-only','status':'pass'}],'failures':[],
      'measurement_inputs':inputs,'input_sha256':{p:sha(p) for p in inputs.values()},
      'format_marker':json.loads(Path(inputs['deterministic']).read_text())['format_marker']}
'''
class SealControls(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='evie-seal-format-only-')
        self.addCleanup(self.temp.cleanup);self.base=Path(self.temp.name)
        self.auditor=self.base/'format_only_auditor.py';self.auditor.write_text(STUB)
        self.freeze=self.base/'freeze.json'
        self.frozen={'resources_path':str(self.auditor),'resources_sha256':runner.sha256(self.auditor)}
        self.freeze.write_text(json.dumps(self.frozen))
        self.inputs={'freeze':str(self.freeze)}
        for field in ['evidence_report','quality_report','local','index','operating','deterministic']:
            p=self.base/(field+'.json');p.write_text(json.dumps({'format_marker':'retained-format-only'}));self.inputs[field]=str(p)
        spec=importlib.util.spec_from_file_location('format_stub',self.auditor);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        self.report=mod.build_report(**self.inputs);self.path=self.base/'format_report.json';self.save()
    def save(self):self.path.write_text(json.dumps(self.report))
    def check(self):return runner.verified_development_report(self.freeze,self.frozen,self.path)
    def test_positive_complete_protocol_recomputes_exactly(self):self.assertEqual(self.check(),self.report)
    def test_flag_only_report_rejected(self):
        self.report={k:self.report[k] for k in ['freeze_sha256','partition','all_required_gates_pass']};self.save()
        with self.assertRaisesRegex(RuntimeError,'complete passing'):self.check()
    def test_altered_bound_input_rejected(self):
        Path(self.inputs['quality_report']).write_text('changed format input')
        with self.assertRaisesRegex(RuntimeError,'input changed'):self.check()
    def test_changed_report_recomputed_mismatch_rejected(self):
        self.report['format_marker']='changed report only';self.save()
        with self.assertRaisesRegex(RuntimeError,'re-computation'):self.check()
    def test_wrong_aggregator_identity_rejected(self):
        self.report['resource_aggregator_sha256']='0'*64;self.save()
        with self.assertRaisesRegex(RuntimeError,'complete passing'):self.check()
    def test_missing_measurement_mode_rejected(self):
        del self.report['measurement_inputs']['operating'];self.save()
        with self.assertRaisesRegex(RuntimeError,'exact measurement inputs'):self.check()
    def test_changed_frozen_auditor_rejected(self):
        self.auditor.write_text(STUB+'\n# changed frozen source\n')
        with self.assertRaisesRegex(RuntimeError,'auditor changed'):self.check()
    def test_incomplete_gate_and_nonempty_failure_rejected(self):
        self.report['gates'][0]['status']='incomplete';self.report['failures']=['format only incomplete'];self.save()
        with self.assertRaisesRegex(RuntimeError,'complete passing'):self.check()

if __name__=='__main__':unittest.main(verbosity=2)
