"""Synthetic citation arithmetic and read-only report API controls; no model calls."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path('/Users/davidboktor/code/evie-memory-stage-5/cmd/evie/docs/fixtures/memory-stage5-integrated')
spec = importlib.util.spec_from_file_location('resource_controls', ROOT / 'resources.py')
resources = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resources)

class Controls(unittest.TestCase):
    def fixture(self, correct_extra=True):
        r = resources.Report.__new__(resources.Report)
        r.checks, r.summaries = [], {}
        r.cases = [{'id':'case', 'gold':{'support_sets':[['record']], 'expected_answer_components':['fact']}}]
        r.conditions = ['tool_only']
        hits = int(correct_extra)
        row = {'case_id':'case', 'condition':'tool_only', 'assessment_valid':True,
               'component_denominator':1, 'required_citation_denominator':1,
               'additional_citation_denominator':1, 'citation_denominator':2,
               'required_citation_hits':1, 'additional_citation_hits':hits, 'citation_hits':1+hits,
               'semantic_pass':correct_extra}
        summary = {'required_correct_citations':1, 'required_citation_denominator':1,
                   'additional_correct_citations':hits, 'additional_citation_denominator':1,
                   'correct_citations':1+hits, 'citation_denominator':2,
                   'original_event_citation_accuracy':(1+hits)/2}
        return r, {'cases':[row], 'conditions':{'tool_only':summary}}

    def assert_clean(self, r, quality):
        r.quality_counts(quality)
        self.assertTrue(all(g['status']=='pass' for g in r.checks), r.checks)

    def test_valid_extra_counts_as_additional_support(self):
        self.assert_clean(*self.fixture())

    def test_wrong_extra_keeps_accuracy_denominator(self):
        r, quality = self.fixture(False)
        self.assert_clean(r, quality)
        self.assertEqual(quality['conditions']['tool_only']['original_event_citation_accuracy'], .5)

    def test_wrong_extra_cannot_claim_semantic_pass(self):
        r, quality = self.fixture(False)
        quality['cases'][0]['semantic_pass'] = True
        r.quality_counts(quality)
        self.assertTrue(any(g['status']=='fail' for g in r.checks), r.checks)

    def test_wrong_extra_cannot_disappear_from_total(self):
        for target, key, value in [('row','citation_denominator',1), ('row','additional_citation_denominator',-1),
                                   ('row','required_citation_denominator',0), ('row','citation_hits',2),
                                   ('summary','citation_denominator',1), ('summary','original_event_citation_accuracy',1.0)]:
            with self.subTest(target=target, key=key):
                r, quality = self.fixture(False)
                entry = quality['cases'][0] if target=='row' else quality['conditions']['tool_only']
                entry[key] = value
                r.quality_counts(quality)
                self.assertTrue(any(g['status']=='fail' for g in r.checks), r.checks)

    def test_missing_assessment_still_retains_required_denominator(self):
        r, quality = self.fixture(False)
        row=quality['cases'][0]
        row.update(assessment_valid=False, required_citation_hits=0, additional_citation_hits=0, citation_hits=0)
        quality['conditions']['tool_only'].update(required_correct_citations=0, correct_citations=0, original_event_citation_accuracy=0)
        r.quality_counts(quality)
        self.assertTrue(any(g['id']=='quality:required_denominators' and g['status']=='fail' for g in r.checks))
        self.assertEqual(row['citation_denominator'],2)

    def test_api_returns_json_native_repeatable_incomplete_report_without_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            freeze = base/'freeze.json'
            freeze.write_text('{}')
            paths = {name:str(base/name) for name in ('evidence_report','quality_report','local','index','operating','deterministic')}
            paths['freeze']=str(freeze)
            before={str(p):p.read_bytes() for p in base.rglob('*') if p.is_file()}
            first=resources.build_report(**paths)
            second=resources.build_report(**first['measurement_inputs'])
            self.assertEqual(first, second)
            self.assertEqual(first,json.loads(json.dumps(first)))
            self.assertFalse(first['all_required_gates_pass'])
            self.assertFalse(first['complete'])
            self.assertEqual(first['measurement_inputs'],{k:str(Path(v).resolve()) for k,v in paths.items()})
            self.assertEqual(before,{str(p):p.read_bytes() for p in base.rglob('*') if p.is_file()})
            output=base/'output'
            command=['python3',str(ROOT/'resources.py')]
            for name,value in paths.items(): command.extend(['--'+name.replace('_','-'),value])
            command.extend(['--output',str(output)])
            run=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(run.returncode,1,run.stderr)
            self.assertEqual(first,json.loads((output/'report.json').read_text()))

if __name__=='__main__': unittest.main(verbosity=2)
