package agent

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/davidadel66/evie/internal/memory"
	"github.com/davidadel66/evie/internal/openrouter"
)

type History interface {
	Append(
		ctx context.Context,
		lease memory.TurnLease,
		input memory.EventInput,
	) (memory.Event, error)
	Events(ctx context.Context) ([]memory.Event, error)
}

type workingContextProvider interface {
	WorkingContext(context.Context) (string, error)
}

type completeToolResultGroup struct {
	resultIndexes []int
}

func completeToolResultGroups(events []memory.Event) ([]completeToolResultGroup, error) {
	omit, err := incompleteToolGroupEvents(events)
	if err != nil {
		return nil, err
	}
	var groups []completeToolResultGroup
	for i, event := range events {
		if event.Type != memory.EventAssistantMessage || omit[i] {
			continue
		}
		var payload memory.AssistantMessagePayload
		if err := decodeEventPayload(event, &payload); err != nil {
			return nil, err
		}
		if len(payload.ToolCalls) == 0 {
			continue
		}
		group := completeToolResultGroup{}
		for j := i + 1; j < len(events); j++ {
			if events[j].Type == memory.EventAssistantMessage || events[j].Type == memory.EventUserMessage {
				break
			}
			if omit[j] || (events[j].Type != memory.EventToolSucceeded &&
				events[j].Type != memory.EventToolFailed && events[j].Type != memory.EventToolCancelled) {
				continue
			}
			var result memory.ToolResultPayload
			if err := decodeEventPayload(events[j], &result); err != nil {
				return nil, err
			}
			position := len(group.resultIndexes)
			if position >= len(payload.ToolCalls) || result.ToolCallID != payload.ToolCalls[position].ID {
				return nil, fmt.Errorf("tool event %q is out of order for assistant event %q", events[j].ID, event.ID)
			}
			group.resultIndexes = append(group.resultIndexes, j)
		}
		if len(group.resultIndexes) != len(payload.ToolCalls) {
			return nil, fmt.Errorf("complete assistant event %q has an inconsistent result group", event.ID)
		}
		groups = append(groups, group)
	}
	return groups, nil
}

func messagesFromEvents(events []memory.Event) ([]openrouter.Message, error) {
	return messagesFromEventsWithContinuation(events, nil)
}

func messagesFromEventsWithContinuation(events []memory.Event, continuation map[memory.EventID][]json.RawMessage) ([]openrouter.Message, error) {
	var messages []openrouter.Message
	omit, err := incompleteToolGroupEvents(events)
	if err != nil {
		return nil, err
	}

	for i, event := range events {
		if omit[i] {
			continue
		}
		switch event.Type {
		case memory.EventUserMessage:
			if event.Role != memory.RoleUser {
				return nil, fmt.Errorf("user event %q has role %q", event.ID, event.Role)
			}
			messages = append(messages, openrouter.Message{
				Role:    "user",
				Content: event.Content,
			})
		case memory.EventAssistantMessage:
			if event.Role != memory.RoleAssistant {
				return nil, fmt.Errorf("assistant event %q has role %q", event.ID, event.Role)
			}

			var payload memory.AssistantMessagePayload
			if err := decodeEventPayload(event, &payload); err != nil {
				return nil, err
			}
			if err := payload.ValidateTextParts(event.Content); err != nil {
				return nil, err
			}
			var textParts []openrouter.TextPart
			for _, part := range payload.TextParts {
				textParts = append(textParts, openrouter.TextPart{Text: part.Text, Phase: part.Phase, AfterToolCalls: part.AfterToolCalls})
			}

			var toolCalls []openrouter.ToolCall
			responseItems := continuation[event.ID]
			for _, call := range payload.ToolCalls {
				if call.ID == "" || call.Name == "" {
					return nil, fmt.Errorf("assistant event %q contains an incomplete tool call", event.ID)
				}
				arguments := call.Arguments
				if call.Name == "memory_expand_conversation" {
					// Source references are resolved from the current request's
					// revalidated evidence, never replayed through durable tool
					// arguments. Keep the original event intact for inspection.
					arguments = `{"evidence_id":"[source reference recorded in request receipt]"}`
					// Native continuation items contain the original arguments;
					// canonical replay is required to honor the same boundary.
					responseItems = nil
				}
				toolCalls = append(toolCalls, openrouter.ToolCall{
					ID:   call.ID,
					Type: "function",
					Function: openrouter.FunctionCall{
						Name:      call.Name,
						Arguments: arguments,
					},
				})
			}

			messages = append(messages, openrouter.Message{
				Role:          "assistant",
				Content:       event.Content,
				ToolCalls:     toolCalls,
				TextParts:     textParts,
				ResponseItems: responseItems,
			})

		case memory.EventToolSucceeded,
			memory.EventToolFailed,
			memory.EventToolCancelled:
			if event.Role != memory.RoleTool {
				return nil, fmt.Errorf("tool event %q has role %q", event.ID, event.Role)
			}

			var payload memory.ToolResultPayload
			if err := decodeEventPayload(event, &payload); err != nil {
				return nil, err
			}

			if payload.ToolCallID == "" {
				return nil, fmt.Errorf("tool event %q has no tool call ID", event.ID)
			}

			messages = append(messages, openrouter.Message{
				Role:       "tool",
				Content:    event.Content,
				ToolCallID: payload.ToolCallID,
			})

		case memory.EventToolIntent,
			memory.EventApproval,
			memory.EventExecutionResolved,
			memory.EventTurnFailed,
			memory.EventTurnInterrupted,
			memory.EventContextSnapshot,
			memory.EventContextCompacted:
			continue

		default:
			return nil, fmt.Errorf("unsupported history event type %q", event.Type)

		}
	}
	return messages, nil
}

func incompleteToolGroupEvents(events []memory.Event) (map[int]bool, error) {
	omit := make(map[int]bool)
	claimedResults := make(map[int]bool)
	for i, event := range events {
		if event.Type != memory.EventAssistantMessage {
			continue
		}
		var payload memory.AssistantMessagePayload
		if err := decodeEventPayload(event, &payload); err != nil {
			return nil, err
		}
		if len(payload.ToolCalls) == 0 {
			continue
		}

		requested := make(map[string]bool, len(payload.ToolCalls))
		for _, call := range payload.ToolCalls {
			if call.ID == "" || call.Name == "" {
				return nil, fmt.Errorf("assistant event %q contains an incomplete tool call", event.ID)
			}
			if _, exists := requested[call.ID]; exists {
				return nil, fmt.Errorf("assistant event %q repeats tool call ID %q", event.ID, call.ID)
			}
			requested[call.ID] = false
		}
		groupEnd := len(events)
		for j := i + 1; j < len(events); j++ {
			if events[j].Type == memory.EventAssistantMessage || events[j].Type == memory.EventUserMessage {
				groupEnd = j
				break
			}
			if events[j].Type != memory.EventToolSucceeded &&
				events[j].Type != memory.EventToolFailed &&
				events[j].Type != memory.EventToolCancelled {
				continue
			}
			var result memory.ToolResultPayload
			if err := decodeEventPayload(events[j], &result); err != nil {
				return nil, err
			}
			terminal, ok := requested[result.ToolCallID]
			if !ok {
				return nil, fmt.Errorf("tool event %q does not match the preceding assistant tool-call group", events[j].ID)
			}
			if terminal {
				return nil, fmt.Errorf("tool call ID %q has multiple terminal results", result.ToolCallID)
			}
			requested[result.ToolCallID] = true
			claimedResults[j] = true
		}
		complete := true
		for _, terminal := range requested {
			complete = complete && terminal
		}
		if complete {
			continue
		}
		omit[i] = true
		for j := i + 1; j < groupEnd; j++ {
			if events[j].Type != memory.EventToolSucceeded &&
				events[j].Type != memory.EventToolFailed &&
				events[j].Type != memory.EventToolCancelled {
				continue
			}
			var result memory.ToolResultPayload
			if err := decodeEventPayload(events[j], &result); err != nil {
				return nil, err
			}
			if _, ok := requested[result.ToolCallID]; ok {
				omit[j] = true
			}
		}
	}
	for i, event := range events {
		if event.Type != memory.EventToolSucceeded && event.Type != memory.EventToolFailed &&
			event.Type != memory.EventToolCancelled {
			continue
		}
		if !claimedResults[i] {
			return nil, fmt.Errorf("tool event %q is orphaned from an assistant tool-call group", event.ID)
		}
	}
	return omit, nil
}

func decodeEventPayload(event memory.Event, destination any) error {
	payload := event.Payload
	if len(payload) == 0 {
		payload = json.RawMessage(`{}`)
	}
	if err := json.Unmarshal(payload, destination); err != nil {
		return fmt.Errorf("decode %s event %q payload: %w", event.Type, event.ID, err)
	}
	return nil
}

// HistoryEvents returns saved evidence for a frontend, without replaying tools
// or applying model-context compaction. It never exposes a partial local turn.
func (s *Session) HistoryEvents(ctx context.Context) ([]memory.Event, error) {
	if !s.mu.TryLock() {
		return nil, ErrBusy
	}
	defer s.mu.Unlock()
	return s.history.Events(ctx)
}
