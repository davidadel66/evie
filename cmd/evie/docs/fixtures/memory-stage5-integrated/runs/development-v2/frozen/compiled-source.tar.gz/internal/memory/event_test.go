package memory

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"strings"
	"testing"
)

func TestAssistantTextPartsValidatePublicOrdering(t *testing.T) {
	for _, test := range []struct {
		name  string
		parts []AssistantTextPart
		valid bool
	}{
		{"legacy", nil, true},
		{"ordered", []AssistantTextPart{{Text: "a", Phase: "commentary"}, {Text: "b", Phase: "final_answer", AfterToolCalls: 1}}, true},
		{"out of order", []AssistantTextPart{{Text: "a", AfterToolCalls: 1}, {Text: "b"}}, false},
		{"negative offset", []AssistantTextPart{{Text: "ab", AfterToolCalls: -1}}, false},
		{"past calls", []AssistantTextPart{{Text: "ab", AfterToolCalls: 2}}, false},
		{"unknown phase", []AssistantTextPart{{Text: "ab", Phase: "reasoning"}}, false},
		{"content mismatch", []AssistantTextPart{{Text: "a"}}, false},
	} {
		t.Run(test.name, func(t *testing.T) {
			payload := AssistantMessagePayload{TextParts: test.parts, ToolCalls: []ToolCall{{ID: "call-1", Name: "echo", Arguments: `{}`}}}
			if err := payload.ValidateTextParts("ab"); (err == nil) != test.valid {
				t.Fatalf("validation=%v expected valid=%v", err, test.valid)
			}
		})
	}
}

func TestAssistantMessagePayloadUsageJSONPreservesPartialZeroAndAbsence(t *testing.T) {
	zero, total := int64(0), int64(12)
	payload := AssistantMessagePayload{Usage: &TokenUsage{
		InputTokens: &zero,
		TotalTokens: &total,
	}}
	encoded, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	const want = `{"usage":{"input_tokens":0,"total_tokens":12}}`
	if string(encoded) != want {
		t.Fatalf("payload JSON=%s, want %s", encoded, want)
	}

	var decoded AssistantMessagePayload
	if err := json.Unmarshal(encoded, &decoded); err != nil {
		t.Fatal(err)
	}
	if decoded.Usage == nil || decoded.Usage.InputTokens == nil || *decoded.Usage.InputTokens != 0 ||
		decoded.Usage.TotalTokens == nil || *decoded.Usage.TotalTokens != 12 ||
		decoded.Usage.OutputTokens != nil {
		t.Fatalf("round-tripped payload=%+v usage=%+v", decoded, decoded.Usage)
	}

	absent, err := json.Marshal(AssistantMessagePayload{})
	if err != nil {
		t.Fatal(err)
	}
	if string(absent) != `{}` {
		t.Fatalf("absent usage JSON=%s, want {}", absent)
	}
}

func TestContextSnapshotPayloadValidation(t *testing.T) {
	valid := ContextSnapshotPayload{
		SchemaVersion: 1, ComposerVersion: "context-composer-v1", EstimatorVersion: "canonical-json-bytes-v1",
		Iteration: 1, ConfiguredModel: "vendor/model", CanonicalModel: "vendor/model",
		ProfileSource: "explicit_override", HardWindowTokens: 262144, WorkingCeilingTokens: 262144,
		OutputReserveTokens: 16384, EstimationMarginTokens: 4096, UsableInputBytes: 241664,
		SerializedBytes: 1234, RoughTokenEstimate: 309, RequestSHA256: strings.Repeat("a", 64),
		RetainedFirstEventID: "event-1", RetainedFirstSequence: 1,
		RetainedLastEventID: "event-2", RetainedLastSequence: 2,
		MessageCount: 3, ToolSchemaCount: 2, SystemMessageBytes: 100, HistoryMessageBytes: 300,
		ToolSchemaBytes: 200, RequestSettingsBytes: 80,
	}
	if err := valid.Validate(); err != nil {
		t.Fatalf("valid payload rejected: %v", err)
	}

	tests := []struct {
		name   string
		mutate func(*ContextSnapshotPayload)
	}{
		{"unsupported version", func(p *ContextSnapshotPayload) { p.SchemaVersion = 2 }},
		{"bad arithmetic", func(p *ContextSnapshotPayload) { p.UsableInputBytes++ }},
		{"oversized request", func(p *ContextSnapshotPayload) { p.SerializedBytes = p.UsableInputBytes + 1 }},
		{"bad hash", func(p *ContextSnapshotPayload) { p.RequestSHA256 = "secret" }},
		{"backward frontier", func(p *ContextSnapshotPayload) { p.RetainedLastSequence = 0 }},
		{"unknown failure", func(p *ContextSnapshotPayload) { p.CompactionFailureCategory = "raw provider error" }},
		{"unexpected advertised metadata", func(p *ContextSnapshotPayload) { p.AdvertisedModel = "secret" }},
		{"compaction without summary", func(p *ContextSnapshotPayload) { p.ActiveCompactionEventID = "compaction-1" }},
		{"summary without compaction", func(p *ContextSnapshotPayload) { p.SummaryMessageBytes = 10 }},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			payload := valid
			tt.mutate(&payload)
			if err := payload.Validate(); err == nil {
				t.Fatalf("invalid payload validated: %+v", payload)
			}
		})
	}
}

func TestContextCompactedPayloadValidation(t *testing.T) {
	var summaryBuilder strings.Builder
	for _, heading := range ContextCompactionSectionHeadings() {
		fmt.Fprintf(&summaryBuilder, "## %s\nkept\n\n", heading)
	}
	summary := summaryBuilder.String()
	digest := sha256.Sum256([]byte(summary))
	valid := ContextCompactedPayload{
		SchemaVersion: ContextCompactedSchemaVersion,
		Generation:    1, Trigger: ContextCompactionManual,
		CoveredFirstEventID: "event-1", CoveredFirstSequence: 1,
		CoveredLastEventID: "event-2", CoveredLastSequence: 2,
		FirstRetainedEventID: "event-3", CanonicalModel: "vendor/model",
		PromptVersion: "compaction-v1", SummaryBytes: int64(len(summary)),
		SummarySHA256: fmt.Sprintf("%x", digest),
	}
	if err := valid.Validate(summary); err != nil {
		t.Fatalf("valid payload rejected: %v", err)
	}
	tests := []struct {
		name   string
		mutate func(*ContextCompactedPayload)
	}{
		{"unsupported version", func(p *ContextCompactedPayload) { p.SchemaVersion++ }},
		{"missing generation", func(p *ContextCompactedPayload) { p.Generation = 0 }},
		{"manual generation has prior", func(p *ContextCompactedPayload) { p.PriorCompactionEventID = "prior" }},
		{"unknown trigger", func(p *ContextCompactedPayload) { p.Trigger = "automatic-ish" }},
		{"backward coverage", func(p *ContextCompactedPayload) { p.CoveredLastSequence = 0 }},
		{"missing retained identity", func(p *ContextCompactedPayload) { p.FirstRetainedEventID = "" }},
		{"wrong byte count", func(p *ContextCompactedPayload) { p.SummaryBytes++ }},
		{"wrong digest", func(p *ContextCompactedPayload) { p.SummarySHA256 = strings.Repeat("0", 64) }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			payload := valid
			test.mutate(&payload)
			if err := payload.Validate(summary); err == nil {
				t.Fatalf("invalid payload validated: %+v", payload)
			}
		})
	}
}

func TestContextCompactedPayloadAcceptsAutomaticTrigger(t *testing.T) {
	var summaryBuilder strings.Builder
	for _, heading := range ContextCompactionSectionHeadings() {
		fmt.Fprintf(&summaryBuilder, "## %s\nkept\n\n", heading)
	}
	summary := summaryBuilder.String()
	digest := sha256.Sum256([]byte(summary))
	payload := ContextCompactedPayload{
		SchemaVersion:       ContextCompactedSchemaVersion,
		Generation:          1,
		Trigger:             ContextCompactionAutomatic,
		CoveredFirstEventID: "first", CoveredFirstSequence: 1,
		CoveredLastEventID: "last", CoveredLastSequence: 2,
		FirstRetainedEventID: "retained", CanonicalModel: "test/model",
		PromptVersion: ContextCompactionPromptVersion,
		SummaryBytes:  int64(len(summary)), SummarySHA256: fmt.Sprintf("%x", digest),
	}
	if err := payload.Validate(summary); err != nil {
		t.Fatalf("automatic trigger: %v", err)
	}
}

func TestContextCompactedPayloadValidatesExactAdvance(t *testing.T) {
	prior := ContextCompactedPayload{Generation: 1, FirstRetainedEventID: "turn-4"}
	next := ContextCompactedPayload{
		Generation: 2, PriorCompactionEventID: "compaction-1", CoveredFirstEventID: "turn-4",
	}
	if err := next.ValidateAdvance("compaction-1", prior); err != nil {
		t.Fatalf("valid advance: %v", err)
	}
	for _, test := range []struct {
		name   string
		mutate func(*ContextCompactedPayload)
	}{
		{name: "generation", mutate: func(payload *ContextCompactedPayload) { payload.Generation++ }},
		{name: "prior link", mutate: func(payload *ContextCompactedPayload) { payload.PriorCompactionEventID = "other" }},
		{name: "frontier", mutate: func(payload *ContextCompactedPayload) { payload.CoveredFirstEventID = "turn-3" }},
	} {
		t.Run(test.name, func(t *testing.T) {
			candidate := next
			test.mutate(&candidate)
			if err := candidate.ValidateAdvance("compaction-1", prior); err == nil {
				t.Fatalf("invalid advance accepted: %+v", candidate)
			}
		})
	}
}

func TestTurnTerminalPayloadClosedStageAndClassificationMatrix(t *testing.T) {
	stages := []TurnStage{
		StageTurnStart, StageProvider, StageAssistantCommit, StageToolPrepare,
		StageToolApproval, StageToolExecute, StageToolCommit,
	}
	for _, stage := range stages {
		for _, tt := range []struct {
			eventType      EventType
			classification TurnClassification
		}{
			{EventTurnFailed, ClassificationProviderError},
			{EventTurnFailed, ClassificationProviderResponseInvalid},
			{EventTurnInterrupted, ClassificationCallerCancelled},
			{EventTurnInterrupted, ClassificationCallerDeadlineExceeded},
		} {
			payload := TurnTerminalPayload{TurnID: "turn", Classification: tt.classification, Stage: stage}
			if err := payload.Validate(tt.eventType); err != nil {
				t.Errorf("stage=%q classification=%q: %v", stage, tt.classification, err)
			}
		}
	}

	invalid := []TurnTerminalPayload{
		{TurnID: "turn", Classification: ClassificationProviderError, Stage: "unknown"},
		{TurnID: "", Classification: ClassificationProviderError, Stage: StageProvider},
		{TurnID: "turn", Classification: "unknown", Stage: StageProvider},
	}
	for _, payload := range invalid {
		if err := payload.Validate(EventTurnFailed); err == nil {
			t.Errorf("invalid payload validated: %+v", payload)
		}
	}
}

func TestTurnTerminalPayloadHTTPStatusOnlyAcceptsNon2xxProviderErrors(t *testing.T) {
	for _, status := range []int{100, 199, 300, 404, 503, 999} {
		payload := TurnTerminalPayload{TurnID: "turn", Classification: ClassificationProviderError, Stage: StageProvider, HTTPStatus: &status}
		if err := payload.Validate(EventTurnFailed); err != nil {
			t.Errorf("status %d rejected: %v", status, err)
		}
	}
	for _, status := range []int{0, 99, 200, 204, 299, 1000} {
		payload := TurnTerminalPayload{TurnID: "turn", Classification: ClassificationProviderError, Stage: StageProvider, HTTPStatus: &status}
		if err := payload.Validate(EventTurnFailed); err == nil {
			t.Errorf("status %d accepted", status)
		}
	}
}
