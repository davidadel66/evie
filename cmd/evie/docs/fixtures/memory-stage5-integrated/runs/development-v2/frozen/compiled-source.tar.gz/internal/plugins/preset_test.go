package plugins

import (
	"context"
	"encoding/json"
	"errors"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	kernelcomposition "github.com/davidadel66/evie/internal/composition"
	"github.com/davidadel66/evie/internal/eviedb"
	"github.com/davidadel66/evie/internal/task"
	"github.com/davidadel66/evie/internal/tools"
)

type cancelingEnabledStateStore struct {
	*enabledStateMemoryStore
	cancelReads bool
	entered     chan struct{}
}

func (s *cancelingEnabledStateStore) PluginEnabled(
	ctx context.Context,
	id string,
) (bool, uint64, bool, error) {
	if s.cancelReads {
		close(s.entered)
		<-ctx.Done()
		return false, 0, false, ctx.Err()
	}
	return s.enabledStateMemoryStore.PluginEnabled(ctx, id)
}

func TestStandardPresetComposesOnlyItsPinnedCapabilities(t *testing.T) {
	if got := canonicalPresetVersion(standardPresetContent()); got != StandardPresetVersion {
		t.Fatalf("standard canonical version = %q, want reserved %q", got, StandardPresetVersion)
	}
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}

	composition, err := manager.ResolvePreset("")
	if err != nil {
		t.Fatal(err)
	}
	if PresetID(composition.Receipt.Preset.ID) != StandardPresetID ||
		composition.Receipt.Preset.Version != StandardPresetVersion {
		t.Fatalf("preset identity = %+v, want %s@%s", composition.Receipt.Preset, StandardPresetID, StandardPresetVersion)
	}
	if composition.Receipt.EvieVersion != EvieVersion {
		t.Fatalf("Evie version = %q, want %q", composition.Receipt.EvieVersion, EvieVersion)
	}
	wantTodo := []tools.Tool{
		tools.TodoScopedListTool(), tools.TodoScopedAddTool(), tools.TodoTreeGetTool(), tools.TodoClaimedUpdateTool(),
		tools.TodoDecomposeTool(), tools.TodoClaimTool(), tools.TodoReleaseTool(),
	}
	wantSchemas := schemaNames(tools.KernelToolset().
		WithTools(tools.FinanceTools()).
		WithTools(tools.WebTools()).
		WithTools(tools.YouTubeTools()).
		WithTools(wantTodo))
	if got := schemaNames(composition.Toolset); !reflect.DeepEqual(got, wantSchemas) {
		t.Fatalf("standard schemas = %v, want %v", got, wantSchemas)
	}

	standard := BuiltinStandardPreset()
	standard.RequiredCapabilities[0].ID = "changed.capability"
	again := BuiltinStandardPreset()
	if again.RequiredCapabilities[0].ID == "changed.capability" {
		t.Fatal("caller mutated immutable built-in standard preset")
	}
	if _, err := manager.ResolvePreset("missing"); err == nil ||
		!strings.Contains(err.Error(), `Agent Preset "missing" is not allowed`) {
		t.Fatalf("unknown explicit preset error = %v", err)
	}
}

func TestPreRetrievalStandardReceiptKeepsExactToolsWhenMemoryProviderUpgrades(t *testing.T) {
	t.Setenv("EVIE_REMOTE_MEMORY", "on")
	makeManager := func(memoryPlugin Plugin) *Manager {
		manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}), memoryPlugin)
		if err != nil {
			t.Fatal(err)
		}
		for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID, MemoryPluginID} {
			if err := manager.SetEnabled(id, true); err != nil {
				t.Fatal(err)
			}
		}
		return manager
	}
	plugin := NewMemory(&stubSemanticKernel{})
	legacyPreset := BuiltinStandardPreset()
	legacyPreset.Version = "sha256:35d56debddef4411a4a9eff972376708bf8aabb811f02e25df5c93582e066754"
	legacyPreset.OptionalCapabilities = nil
	for _, capability := range plugin.ResumableToolCapabilities("1.1.0") {
		legacyPreset.OptionalCapabilities = append(legacyPreset.OptionalCapabilities, CapabilityRequirement{ID: capability.ID, Compatibility: VersionRange{Minimum: "1.0.0", MaximumExclusive: "2.0.0"}})
	}
	if got := canonicalPresetVersion(legacyPreset); got != legacyPreset.Version {
		t.Fatalf("historical content hash=%s, want frozen %s", got, legacyPreset.Version)
	}
	legacy, err := makeManager(preRetrievalMemoryPlugin{plugin}).resolvePreset(legacyPreset)
	if err != nil {
		t.Fatal(err)
	}
	current := makeManager(plugin)
	resumed, err := current.ResumeComposition(legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) || !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatal("resuming added capabilities or rewrote the old receipt")
	}
	if countSchema(resumed.Toolset, "memory_search") != 0 {
		t.Fatal("old conversation gained relevance search")
	}
	if len(resumed.CompatibilityResolutions) != 1 || resumed.CompatibilityResolutions[0].OriginalProvider.ImplementationVersion != "1.1.0" || resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.2.0" {
		t.Fatalf("missing exact provider compatibility audit: %+v", resumed.CompatibilityResolutions)
	}
	fresh, err := current.ResolvePreset(StandardPresetID)
	if err != nil {
		t.Fatal(err)
	}
	if fresh.Receipt.Preset.Version == legacy.Receipt.Preset.Version || countSchema(fresh.Toolset, "memory_search") != 1 {
		t.Fatal("new conversation does not pin a new retrieval composition")
	}
}

type preRetrievalMemoryPlugin struct{ *Memory }

func (p preRetrievalMemoryPlugin) ToolCapabilities() []ToolCapability {
	return p.Memory.ResumableToolCapabilities("1.1.0")
}
func (p preRetrievalMemoryPlugin) Manifest() Manifest {
	manifest := p.Memory.Manifest()
	manifest.ImplementationVersion = "1.1.0"
	manifest.ResumableFrom = nil
	manifest.Capabilities = nil
	for _, capability := range p.ToolCapabilities() {
		manifest.Capabilities = append(manifest.Capabilities, CapabilityContract{ID: capability.ID, Version: capability.ContractVersion})
	}
	return manifest
}

func TestPreYouTubeExtractionStandardReceiptResumesWithoutMutation(t *testing.T) {
	if got := canonicalPresetVersion(preYouTubeStandardPreset()); got != preYouTubeStandardPresetVersion {
		t.Fatalf("pre-YouTube canonical version = %q, want frozen %q", got, preYouTubeStandardPresetVersion)
	}
	compatibility := VersionRange{Minimum: "1.0.0", MaximumExclusive: "2.0.0"}
	legacyPreset := Preset{
		ID:      StandardPresetID,
		Version: "sha256:41b87e45541e81e6a6e45b4cb5877db1d6fb7ab0ebb3cea5f4b24df5f77c2734",
		RequiredCapabilities: []CapabilityRequirement{
			{ID: FinanceSyncCapabilityID, Compatibility: compatibility},
			{ID: FinanceRulesCapabilityID, Compatibility: compatibility},
			{ID: FinanceCategorizeCapabilityID, Compatibility: compatibility},
			{ID: WebFetchCapabilityID, Compatibility: compatibility},
			{ID: WebSearchCapabilityID, Compatibility: compatibility},
		},
	}
	legacyManager, err := NewManager(tools.LegacyKernelToolset(), NewWeb(), NewFinance())
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(legacyPreset)
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "evie.db")
	db, err := eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	store := eviedb.NewStore(db)
	session, err := store.CreateGlobalSessionWithComposition(context.Background(), legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	db, err = eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	store = eviedb.NewStore(db)
	storedReceipt, err := store.GetCompositionReceipt(context.Background(), session.ID)
	if err != nil {
		t.Fatal(err)
	}

	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(storedReceipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) {
		t.Fatalf("resume mutated legacy receipt\n got: %#v\nwant: %#v", resumed.Receipt, legacy.Receipt)
	}
	if !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("resumed legacy schemas changed\n got: %#v\nwant: %#v", resumed.Toolset.Schemas(), legacy.Toolset.Schemas())
	}
	for _, name := range []string{"youtube_transcript", "youtube_scrape_channel"} {
		if countSchema(resumed.Toolset, name) != 1 {
			t.Fatalf("legacy resume exposes %q %d times", name, countSchema(resumed.Toolset, name))
		}
	}
}

func TestPostMemoryPreYouTubeStandardReceiptResumesWithoutMutation(t *testing.T) {
	legacyManager, err := NewManager(tools.LegacyKernelToolset(), NewWeb(), NewFinance())
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preYouTubeStandardPreset())
	if err != nil {
		t.Fatal(err)
	}

	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) ||
		!reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("post-Memory pre-YouTube receipt changed: got=%+v want=%+v", resumed.Receipt, legacy.Receipt)
	}
}

func TestPreTodoExtractionStandardReceiptResumesWithoutMutation(t *testing.T) {
	if got := canonicalPresetVersion(preTodoStandardPreset()); got != preTodoStandardPresetVersion {
		t.Fatalf("pre-Todo canonical version = %q, want frozen %q", got, preTodoStandardPresetVersion)
	}
	legacyManager, err := NewManager(
		tools.PreTodoExtractionKernelToolset(), NewWeb(), NewFinance(), NewYouTube(),
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "evie.db")
	db, err := eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	store := eviedb.NewStore(db)
	session, err := store.CreateGlobalSessionWithComposition(context.Background(), legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	db, err = eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	store = eviedb.NewStore(db)
	storedReceipt, err := store.GetCompositionReceipt(context.Background(), session.ID)
	if err != nil {
		t.Fatal(err)
	}

	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(storedReceipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) {
		t.Fatalf("resume mutated pre-Todo receipt\n got: %#v\nwant: %#v", resumed.Receipt, legacy.Receipt)
	}
	if !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("resumed pre-Todo schemas changed\n got: %#v\nwant: %#v", resumed.Toolset.Schemas(), legacy.Toolset.Schemas())
	}
	for _, name := range []string{"todo_list", "todo_add"} {
		if countSchema(resumed.Toolset, name) != 1 {
			t.Fatalf("pre-Todo resume exposes %q %d times", name, countSchema(resumed.Toolset, name))
		}
	}
}

type preDurableTodoPlugin struct{}

func (preDurableTodoPlugin) Start(context.Context) error { return nil }

func (preDurableTodoPlugin) Stop(context.Context) error { return nil }

func (preDurableTodoPlugin) Manifest() Manifest {
	return Manifest{
		ID: TodoPluginID, ImplementationVersion: "1.0.0",
		KernelCompatibility: VersionRange{Minimum: KernelAPIVersion, MaximumExclusive: "2.0.0"},
		Capabilities: []CapabilityContract{
			{ID: TodoListCapabilityID, Version: "1.0.0"},
			{ID: TodoAddCapabilityID, Version: "1.0.0"},
		},
	}
}

func (preDurableTodoPlugin) ToolCapabilities() []ToolCapability {
	definitions := tools.TodoTools()
	return []ToolCapability{
		{ID: TodoListCapabilityID, ContractVersion: "1.0.0", Tool: definitions[0]},
		{ID: TodoAddCapabilityID, ContractVersion: "1.0.0", Tool: definitions[1]},
	}
}

func TestPreDurableTodoStandardReceiptResumesThroughDeclaredCompatibility(t *testing.T) {
	if got := canonicalPresetVersion(preDurableTodoStandardPreset()); got != preDurableTodoPresetVersion {
		t.Fatalf("pre-durable-Todo canonical version = %q, want frozen %q", got, preDurableTodoPresetVersion)
	}
	legacyManager, err := NewManager(
		tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), preDurableTodoPlugin{},
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preDurableTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}

	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) ||
		!reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("compatible resume changed frozen composition: %+v", resumed)
	}
	if len(resumed.CompatibilityResolutions) != 1 ||
		resumed.CompatibilityResolutions[0].OriginalProvider.ID != string(TodoPluginID) ||
		resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.7.0" {
		t.Fatalf("Todo compatibility resolutions = %+v", resumed.CompatibilityResolutions)
	}
}

type preLifecycleTodoPlugin struct{ service task.Service }

func (preLifecycleTodoPlugin) Start(context.Context) error { return nil }
func (preLifecycleTodoPlugin) Stop(context.Context) error  { return nil }
func (preLifecycleTodoPlugin) Manifest() Manifest {
	return Manifest{
		ID: TodoPluginID, ImplementationVersion: "1.1.0",
		KernelCompatibility: VersionRange{Minimum: KernelAPIVersion, MaximumExclusive: "2.0.0"},
		Capabilities: []CapabilityContract{
			{ID: TodoListCapabilityID, Version: "1.0.0"},
			{ID: TodoAddCapabilityID, Version: "1.0.0"},
			{ID: TodoGetCapabilityID, Version: "1.0.0"},
		},
	}
}
func (p preLifecycleTodoPlugin) ToolCapabilities() []ToolCapability {
	return NewTodo(p.service).ResumableToolCapabilities("1.1.0")
}

func TestPreLifecycleTodoStandardReceiptResumesWithExactFrozenTools(t *testing.T) {
	if got := canonicalPresetVersion(preLifecycleTodoStandardPreset()); got != preLifecycleTodoPresetVersion {
		t.Fatalf("pre-lifecycle-Todo canonical version = %q, want frozen %q", got, preLifecycleTodoPresetVersion)
	}
	service := &taskServiceFixture{}
	legacyManager, err := NewManager(
		tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), preLifecycleTodoPlugin{service: service},
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preLifecycleTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "evie.db")
	db, err := eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	store := eviedb.NewStore(db)
	session, err := store.CreateGlobalSessionWithComposition(context.Background(), legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	db, err = eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	storedReceipt, err := eviedb.NewStore(db).GetCompositionReceipt(context.Background(), session.ID)
	if err != nil {
		t.Fatal(err)
	}
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(service))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(storedReceipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) || !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("compatible resume changed #119 composition: %+v", resumed)
	}
	if len(resumed.CompatibilityResolutions) != 1 ||
		resumed.CompatibilityResolutions[0].OriginalProvider.ImplementationVersion != "1.1.0" ||
		resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.7.0" {
		t.Fatalf("Todo compatibility resolutions = %+v", resumed.CompatibilityResolutions)
	}
	if countSchema(resumed.Toolset, "todo_update") != 0 {
		t.Fatal("#119 receipt unexpectedly gained todo_update")
	}
}

type preIdempotentTodoPlugin struct{ service task.Service }

func (preIdempotentTodoPlugin) Start(context.Context) error { return nil }
func (preIdempotentTodoPlugin) Stop(context.Context) error  { return nil }
func (preIdempotentTodoPlugin) Manifest() Manifest {
	return Manifest{
		ID: TodoPluginID, ImplementationVersion: "1.2.0",
		KernelCompatibility: VersionRange{Minimum: KernelAPIVersion, MaximumExclusive: "2.0.0"},
		Capabilities: []CapabilityContract{
			{ID: TodoListCapabilityID, Version: "1.1.0"},
			{ID: TodoAddCapabilityID, Version: "1.0.0"},
			{ID: TodoGetCapabilityID, Version: "1.0.0"},
			{ID: TodoUpdateCapabilityID, Version: "1.0.0"},
		},
	}
}
func (p preIdempotentTodoPlugin) ToolCapabilities() []ToolCapability {
	return NewTodo(p.service).ResumableToolCapabilities("1.2.0")
}

func TestPreIdempotencyStandardReceiptResumesWithExactFrozenTools(t *testing.T) {
	service := &taskServiceFixture{}
	legacyManager, err := NewManager(
		tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), preIdempotentTodoPlugin{service: service},
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preTreeTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}

	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(service))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) || !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("compatible resume changed #120 composition: %+v", resumed)
	}
	if len(resumed.CompatibilityResolutions) != 1 ||
		resumed.CompatibilityResolutions[0].OriginalProvider.ImplementationVersion != "1.2.0" ||
		resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.7.0" {
		t.Fatalf("Todo compatibility resolutions = %+v", resumed.CompatibilityResolutions)
	}
	for _, schema := range resumed.Toolset.Schemas() {
		if schema.Function.Name != "todo_add" && schema.Function.Name != "todo_update" {
			continue
		}
		if _, exists := schema.Function.Parameters.Properties["idempotency_key"]; exists {
			t.Fatalf("#120 receipt gained idempotency input in %s", schema.Function.Name)
		}
	}
}

type preTreeTodoPlugin struct{ service task.Service }

func (preTreeTodoPlugin) Start(context.Context) error { return nil }
func (preTreeTodoPlugin) Stop(context.Context) error  { return nil }
func (preTreeTodoPlugin) Manifest() Manifest {
	return Manifest{
		ID: TodoPluginID, ImplementationVersion: "1.3.0",
		KernelCompatibility: VersionRange{Minimum: KernelAPIVersion, MaximumExclusive: "2.0.0"},
		Capabilities: []CapabilityContract{
			{ID: TodoListCapabilityID, Version: "1.1.0"},
			{ID: TodoAddCapabilityID, Version: "1.1.0"},
			{ID: TodoGetCapabilityID, Version: "1.0.0"},
			{ID: TodoUpdateCapabilityID, Version: "1.1.0"},
		},
	}
}
func (p preTreeTodoPlugin) ToolCapabilities() []ToolCapability {
	return NewTodo(p.service).ResumableToolCapabilities("1.3.0")
}

func TestPreTreeStandardReceiptResumesWithExactFrozenTools(t *testing.T) {
	service := &taskServiceFixture{}
	legacyManager, err := NewManager(
		tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), preTreeTodoPlugin{service: service},
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preTreeTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(service))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	resumed, err := manager.ResumeComposition(legacy.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) || !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("compatible resume changed #121 composition: %+v", resumed)
	}
	if len(resumed.CompatibilityResolutions) != 1 ||
		resumed.CompatibilityResolutions[0].OriginalProvider.ImplementationVersion != "1.3.0" ||
		resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.7.0" {
		t.Fatalf("Todo compatibility resolutions = %+v", resumed.CompatibilityResolutions)
	}
	if countSchema(resumed.Toolset, "todo_decompose") != 0 {
		t.Fatal("#121 receipt unexpectedly gained todo_decompose")
	}
}

type preClaimsTodoPlugin struct{ service task.Service }

func (preClaimsTodoPlugin) Start(context.Context) error { return nil }
func (preClaimsTodoPlugin) Stop(context.Context) error  { return nil }
func (preClaimsTodoPlugin) Manifest() Manifest {
	return Manifest{
		ID: TodoPluginID, ImplementationVersion: "1.4.0",
		KernelCompatibility: VersionRange{Minimum: KernelAPIVersion, MaximumExclusive: "2.0.0"},
		Capabilities: []CapabilityContract{
			{ID: TodoListCapabilityID, Version: "1.2.0"},
			{ID: TodoAddCapabilityID, Version: "1.2.0"},
			{ID: TodoGetCapabilityID, Version: "1.1.0"},
			{ID: TodoUpdateCapabilityID, Version: "1.2.0"},
			{ID: TodoDecomposeCapabilityID, Version: "1.0.0"},
		},
	}
}
func (p preClaimsTodoPlugin) ToolCapabilities() []ToolCapability {
	return NewTodo(p.service).ResumableToolCapabilities("1.4.0")
}

func TestPreClaimsStandardReceiptResumesFrozenUpdateWithAuditedCompatibility(t *testing.T) {
	if got := canonicalPresetVersion(preClaimsTodoStandardPreset()); got != preClaimsTodoPresetVersion {
		t.Fatalf("pre-claims canonical version = %q, want %q", got, preClaimsTodoPresetVersion)
	}
	path := filepath.Join(t.TempDir(), "evie.db")
	db, err := eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	store := eviedb.NewStore(db)
	session, err := store.CreateGlobalSession(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	lease, err := store.AcquireTurnLease(context.Background(), session.ID, "frozen-holder", time.Hour)
	if err != nil {
		t.Fatal(err)
	}
	ctx := task.WithMutationAttribution(context.Background(), task.MutationAttribution{
		ActorID: "local", SessionID: string(session.ID), RunID: "frozen-run",
		LeaseHolderID: string(lease.HolderID), LeaseToken: uint64(lease.FencingToken), LeaseGeneration: uint64(lease.Generation),
	})
	created, err := store.CreateGlobalTask(ctx, task.CreateInput{Title: "frozen claim compatibility", IdempotencyKey: "frozen-root"})
	if err != nil {
		t.Fatal(err)
	}
	retryTask, err := store.CreateGlobalTask(ctx, task.CreateInput{Title: "pre-claims retry", IdempotencyKey: "frozen-retry-root"})
	if err != nil {
		t.Fatal(err)
	}
	blocked := task.StatusBlocked
	preUpgrade, err := store.ManagementUpdateGlobalTask(ctx, retryTask.ID, task.UpdateInput{
		ExpectedRevision: 1, Status: &blocked, IdempotencyKey: "frozen-retry-update",
	}, "pre-claims fixture")
	if err != nil {
		t.Fatal(err)
	}
	preUpgradeEvents, err := store.ListTaskEvents(context.Background(), retryTask.ID)
	if err != nil {
		t.Fatal(err)
	}
	legacyManager, err := NewManager(
		tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), preClaimsTodoPlugin{service: store},
	)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := legacyManager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	legacy, err := legacyManager.resolvePreset(preClaimsTodoStandardPreset())
	if err != nil {
		t.Fatal(err)
	}
	if err := store.SaveCompositionReceipt(context.Background(), session.ID, legacy.Receipt); err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	db, err = eviedb.OpenDBAt(path)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	store = eviedb.NewStore(db)
	storedReceipt, err := store.GetCompositionReceipt(context.Background(), session.ID)
	if err != nil {
		t.Fatal(err)
	}
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(store))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	current, err := manager.NewSessionToolset()
	if err != nil {
		t.Fatal(err)
	}
	withoutClaim := executeTodoToolContext(t, ctx, current, "todo_update",
		`{"task_id":"`+string(created.ID)+`","expected_revision":1,"status":"in_progress","idempotency_key":"current-without-claim"}`)
	if !withoutClaim.IsErr || !strings.Contains(withoutClaim.Content, "active claim is required") {
		t.Fatalf("current update without claim = %+v", withoutClaim)
	}
	resumed, err := manager.ResumeComposition(storedReceipt)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resumed.Receipt, legacy.Receipt) || !reflect.DeepEqual(resumed.Toolset.Schemas(), legacy.Toolset.Schemas()) {
		t.Fatalf("compatible resume changed #122 composition: %+v", resumed)
	}
	if len(resumed.CompatibilityResolutions) != 1 ||
		resumed.CompatibilityResolutions[0].OriginalProvider.ImplementationVersion != "1.4.0" ||
		resumed.CompatibilityResolutions[0].ReplacementImplementationVersion != "1.7.0" ||
		countSchema(resumed.Toolset, "todo_claim") != 0 || countSchema(resumed.Toolset, "todo_release") != 0 {
		t.Fatalf("pre-claims compatibility = %+v", resumed.CompatibilityResolutions)
	}
	updated := executeTodoToolContext(t, ctx, resumed.Toolset, "todo_update",
		`{"task_id":"`+string(created.ID)+`","expected_revision":1,"status":"in_progress","idempotency_key":"frozen-update"}`)
	if updated.IsErr {
		t.Fatalf("frozen update required new claim: %+v", updated)
	}
	events, err := store.ListTaskEvents(context.Background(), created.ID)
	if err != nil || len(events) < 2 || !events[len(events)-1].ManagementOverride ||
		events[len(events)-1].ClaimReason != "legacy_receipt" {
		t.Fatalf("frozen compatibility audit = %+v, %v", events, err)
	}
	retried := executeTodoToolContext(t, ctx, resumed.Toolset, "todo_update",
		`{"task_id":"`+string(retryTask.ID)+`","expected_revision":1,"status":"blocked","idempotency_key":"frozen-retry-update"}`)
	var retriedTask task.Task
	if retried.IsErr || json.Unmarshal([]byte(retried.Content), &retriedTask) != nil || !reflect.DeepEqual(retriedTask, preUpgrade) {
		t.Fatalf("frozen pre-claims retry = %+v decoded=%+v want=%+v", retried, retriedTask, preUpgrade)
	}
	afterRetryEvents, err := store.ListTaskEvents(context.Background(), retryTask.ID)
	if err != nil || !reflect.DeepEqual(afterRetryEvents, preUpgradeEvents) {
		t.Fatalf("frozen retry events = %+v, %v; want %+v", afterRetryEvents, err, preUpgradeEvents)
	}
}

func TestPresetResolutionFailsRequiredAndPersistsOptionalDiagnostics(t *testing.T) {
	required := fakeToolPlugin("required", "required.echo", "required_echo", "required")
	optional := fakeToolPlugin("optional", "optional.echo", "optional_echo", "optional")
	manager, err := NewManager(tools.NewToolset(nil), required, optional)
	if err != nil {
		t.Fatal(err)
	}
	preset := Preset{
		ID:      "fixture",
		Version: "sha256:3df4b83c2a4f7b40c88c1a78237f622644487aa118f47d2194d637c452432bbd",
		RequiredCapabilities: []CapabilityRequirement{{
			ID: "required.echo", Compatibility: VersionRange{Minimum: "1.0.0", MaximumExclusive: "2.0.0"},
		}},
		OptionalCapabilities: []CapabilityRequirement{{
			ID: "optional.echo", Compatibility: VersionRange{Minimum: "1.0.0", MaximumExclusive: "2.0.0"},
		}},
	}

	if _, err := manager.resolvePreset(preset); err == nil ||
		!strings.Contains(err.Error(), `required Capability "required.echo"`) ||
		!strings.Contains(err.Error(), `enable plugin "required"`) {
		t.Fatalf("missing required error = %v", err)
	}
	if err := manager.SetEnabled("required", true); err != nil {
		t.Fatal(err)
	}
	incompatible := preset
	incompatible.RequiredCapabilities = append([]CapabilityRequirement(nil), preset.RequiredCapabilities...)
	incompatible.RequiredCapabilities[0].Compatibility = VersionRange{Minimum: "2.0.0", MaximumExclusive: "3.0.0"}
	if _, err := manager.resolvePreset(incompatible); err == nil ||
		!strings.Contains(err.Error(), "outside required range [2.0.0,3.0.0)") {
		t.Fatalf("incompatible required Capability error = %v", err)
	}
	composition, err := manager.resolvePreset(preset)
	if err != nil {
		t.Fatal(err)
	}
	if len(composition.Warnings) != 1 ||
		!strings.Contains(composition.Warnings[0], `optional Capability "optional.echo"`) {
		t.Fatalf("warnings = %v", composition.Warnings)
	}
	wantReceiptWarnings := []CompositionWarning{{
		Code: kernelcomposition.WarningProviderDisabled, CapabilityID: "optional.echo", ProviderID: "optional",
	}}
	if !reflect.DeepEqual(composition.Receipt.Warnings, wantReceiptWarnings) {
		t.Fatalf("receipt warnings = %v, want %v", composition.Receipt.Warnings, wantReceiptWarnings)
	}
	assertToolResult(t, composition.Toolset, "required_echo", "required")
	assertUnknownTool(t, composition.Toolset, "optional_echo")

	if err := manager.SetEnabled("optional", true); err != nil {
		t.Fatal(err)
	}
	newComposition, err := manager.resolvePreset(preset)
	if err != nil {
		t.Fatal(err)
	}
	assertToolResult(t, newComposition.Toolset, "optional_echo", "optional")
	assertUnknownTool(t, composition.Toolset, "optional_echo")
}

func TestPresetValidityIgnoresConnectionReadiness(t *testing.T) {
	manager, err := NewManager(
		tools.NewToolset(nil),
		fakeToolPlugin("account", "account.read", "account_read", "connect account"),
	)
	if err != nil {
		t.Fatal(err)
	}
	if err := manager.SetEnabled("account", true); err != nil {
		t.Fatal(err)
	}
	preset := fixturePreset("account.read")
	preset.Configuration = []ConfigurationReference{{
		Kind: ConfigurationConnection, ID: "c9299e6b-81db-47df-8ee7-d5d9a5f9e94f",
	}}
	composition, err := manager.resolvePreset(preset)
	if err != nil {
		t.Fatalf("connection readiness invalidated preset: %v", err)
	}
	assertToolResult(t, composition.Toolset, "account_read", "connect account")
	if !reflect.DeepEqual(composition.Receipt.Configuration, preset.Configuration) {
		t.Fatalf("missing Connection ID receipt refs = %#v, want %#v", composition.Receipt.Configuration, preset.Configuration)
	}
}

func fixturePreset(required CapabilityID) Preset {
	return Preset{
		ID:      "fixture",
		Version: "sha256:3df4b83c2a4f7b40c88c1a78237f622644487aa118f47d2194d637c452432bbd",
		RequiredCapabilities: []CapabilityRequirement{{
			ID: required, Compatibility: VersionRange{Minimum: "1.0.0", MaximumExclusive: "2.0.0"},
		}},
	}
}

func TestReceiptRejectsContentThatCouldCarryCredentials(t *testing.T) {
	preset := fixturePreset("fixture.echo")
	preset.Configuration = []ConfigurationReference{{Kind: ConfigurationConnection, ID: "sk-live-secret-token"}}
	manager, err := NewManager(tools.NewToolset(nil), fakeToolPlugin("fixture", "fixture.echo", "fixture_echo", "ok"))
	if err != nil {
		t.Fatal(err)
	}
	if err := manager.SetEnabled("fixture", true); err != nil {
		t.Fatal(err)
	}
	if _, err := manager.resolvePreset(preset); err == nil || !strings.Contains(err.Error(), "canonical UUID") {
		t.Fatalf("credential-shaped configuration error = %v", err)
	}
}

func TestResumeCompositionRequiresEveryExactPinnedProviderAndSchema(t *testing.T) {
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []PluginID{WebPluginID, FinancePluginID, YouTubePluginID, TodoPluginID} {
		if err := manager.SetEnabled(id, true); err != nil {
			t.Fatal(err)
		}
	}
	pinned, err := manager.ResolvePreset("")
	if err != nil {
		t.Fatal(err)
	}

	changedProvider := pinned.Receipt
	changedProvider.Providers = append([]ProviderReceipt(nil), pinned.Receipt.Providers...)
	changedProvider.Providers[0].ImplementationVersion = "1.0.1"
	if _, err := manager.ResumeComposition(changedProvider); err == nil ||
		!strings.Contains(err.Error(), `provider plugin "finance" requires implementation version "1.0.1"`) {
		t.Fatalf("changed provider resume error = %v", err)
	}

	changedSchema := pinned.Receipt
	changedSchema.Capabilities = append([]CapabilityReceipt(nil), pinned.Receipt.Capabilities...)
	changedSchema.Capabilities[0].SchemaSHA256 = strings.Repeat("0", 64)
	if _, err := manager.ResumeComposition(changedSchema); err == nil ||
		!strings.Contains(err.Error(), `pinned Capability "finance.sync" requires schema`) {
		t.Fatalf("changed schema resume error = %v", err)
	}

	if err := manager.SetEnabled(FinancePluginID, false); err != nil {
		t.Fatal(err)
	}
	if _, err := manager.ResumeComposition(pinned.Receipt); err == nil ||
		!strings.Contains(err.Error(), `pinned provider plugin "finance" is disabled`) {
		t.Fatalf("missing pinned provider resume error = %v", err)
	}
}

func TestResumeCompositionContextCancelsEnabledStateRefresh(t *testing.T) {
	manager, err := NewManager(tools.KernelToolset(), NewWeb(), NewFinance(), NewYouTube(), NewTodo(&taskServiceFixture{}))
	if err != nil {
		t.Fatal(err)
	}
	store := &cancelingEnabledStateStore{enabledStateMemoryStore: &enabledStateMemoryStore{
		values: map[string]bool{string(WebPluginID): true, string(FinancePluginID): true, string(YouTubePluginID): true, string(TodoPluginID): true},
	}}
	if err := manager.ConfigureEnabledState(context.Background(), store, map[PluginID]bool{
		WebPluginID: true, FinancePluginID: true, YouTubePluginID: true, TodoPluginID: true,
	}); err != nil {
		t.Fatal(err)
	}
	pinned, err := manager.ResolvePreset("")
	if err != nil {
		t.Fatal(err)
	}

	store.cancelReads = true
	store.entered = make(chan struct{})
	ctx, cancel := context.WithCancel(context.Background())
	result := make(chan error, 1)
	go func() {
		_, resumeErr := manager.ResumeCompositionContext(ctx, pinned.Receipt)
		result <- resumeErr
	}()
	<-store.entered
	cancel()
	err = <-result
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("ResumeCompositionContext error = %v, want context canceled", err)
	}
}

func TestResumeCompositionUsesOnlyExplicitCompatibleReplacement(t *testing.T) {
	originalPlugin := fakeToolPlugin("fixture", "fixture.echo", "fixture_echo", "original")
	originalManager, err := NewManager(tools.NewToolset(nil), originalPlugin)
	if err != nil {
		t.Fatal(err)
	}
	if err := originalManager.SetEnabled("fixture", true); err != nil {
		t.Fatal(err)
	}
	preset := fixturePreset("fixture.echo")
	pinned, err := originalManager.resolvePreset(preset)
	if err != nil {
		t.Fatal(err)
	}

	exact, err := originalManager.resumePreset(preset, pinned.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	if len(exact.CompatibilityResolutions) != 0 {
		t.Fatalf("exact resume resolutions = %#v, want none", exact.CompatibilityResolutions)
	}

	replacementPlugin := fakeToolPlugin("fixture", "fixture.echo", "fixture_echo", "replacement")
	replacementPlugin.manifest.ImplementationVersion = "1.1.0"
	replacementPlugin.manifest.ResumableFrom = []ImplementationCompatibility{{
		ImplementationVersion: "1.0.0",
		Capabilities: []CapabilityCompatibility{{
			ID: "fixture.echo", ContractVersion: "1.0.0",
			SchemaSHA256: pinned.Receipt.Capabilities[0].SchemaSHA256,
		}},
	}}
	replacementManager, err := NewManager(tools.NewToolset(nil), replacementPlugin)
	if err != nil {
		t.Fatal(err)
	}
	if err := replacementManager.SetEnabled("fixture", true); err != nil {
		t.Fatal(err)
	}

	resumed, err := replacementManager.resumePreset(preset, pinned.Receipt)
	if err != nil {
		t.Fatal(err)
	}
	assertToolResult(t, resumed.Toolset, "fixture_echo", "replacement")
	if !reflect.DeepEqual(resumed.Receipt, pinned.Receipt) {
		t.Fatalf("resumed receipt = %#v, want immutable original %#v", resumed.Receipt, pinned.Receipt)
	}
	if len(resumed.CompatibilityResolutions) != 1 {
		t.Fatalf("replacement resolutions = %#v, want one", resumed.CompatibilityResolutions)
	}
	resolution := resumed.CompatibilityResolutions[0]
	if resolution.OriginalProvider.ID != "fixture" ||
		resolution.OriginalProvider.ImplementationVersion != "1.0.0" ||
		resolution.ReplacementImplementationVersion != "1.1.0" ||
		resolution.KernelAPIVersion != KernelAPIVersion ||
		len(resolution.Capabilities) != 1 ||
		resolution.Capabilities[0].ID != "fixture.echo" ||
		resolution.Capabilities[0].ContractVersion != "1.0.0" ||
		resolution.Capabilities[0].SchemaSHA256 != pinned.Receipt.Capabilities[0].SchemaSHA256 ||
		resolution.ResolvedAt.IsZero() {
		t.Fatalf("replacement resolution = %#v, want exact requirement, evidence, and time", resolution)
	}
}
