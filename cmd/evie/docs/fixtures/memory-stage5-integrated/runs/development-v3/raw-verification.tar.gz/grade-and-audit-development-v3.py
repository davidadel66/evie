from pathlib import Path
import shutil,json,subprocess,importlib.util
base=Path('/tmp/evie-memory-stage5');frozen=(base/'integrated-development-v3').resolve()
s=importlib.util.spec_from_file_location('runner',frozen/'run.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
destination=base/'integrated-development-v3-assessments';destination.mkdir(exist_ok=False)
for group in ['architecture','experiment','requirements']:
 source=base/('integrated-development-v3-assessments-'+group)
 files=list(source.glob('*.json'));assert len(files)==48
 for file in files:
  a=json.loads(file.read_text());assert a['review_complete'] is True
  target=destination/file.name;assert not target.exists();shutil.copyfile(file,target)
assert len(list(destination.glob('*.json')))==144
r.write_json(base/'integrated-development-v3-assessment-manifest.json',r.tree_hashes(destination))
commands=[('grade',['python3','-B',str(frozen/'grader.py'),'--freeze',str(frozen/'freeze.json'),'--evidence-report',str(base/'integrated-development-v3-evidence/evidence-report.json'),'--assessments',str(destination),'--output',str(base/'integrated-development-v3-quality')]),('resource',['python3','-B',str(frozen/'resources.py'),'--freeze',str(frozen/'freeze.json'),'--evidence-report',str(base/'integrated-development-v3-evidence/evidence-report.json'),'--quality-report',str(base/'integrated-development-v3-quality/quality-report.json'),'--local',str(base/'integrated-development-v3-local'),'--index',str(base/'integrated-development-v3-index'),'--operating',str(base/'integrated-development-v3-operating'),'--deterministic',str(base/'integrated-development-v3-deterministic.json'),'--output',str(base/'integrated-development-v3-resource')])]
for label,command in commands:
 prefix=base/('integrated-development-v3-'+label+'-execution')
 try:r.run_command(command,Path('/Users/davidboktor/code/evie-memory-stage-5'),prefix)
 except RuntimeError as error:print(str(error),flush=True)
 print(json.dumps(dict(stage=label,metadata=str(prefix)+'.json',result=json.loads(Path(str(prefix)+'.json').read_text())['exit_code'])),flush=True)
