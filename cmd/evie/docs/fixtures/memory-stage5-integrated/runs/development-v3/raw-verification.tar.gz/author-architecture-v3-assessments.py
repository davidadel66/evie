"""Serialize explicit manual v3 judgments after reading all 48 audited packets.

No labels are inferred from keywords or copied from another evaluation. The
helpers only format the manually selected spans, source bindings, and decisions.
"""
import json
from pathlib import Path

OUT=Path('/tmp/evie-memory-stage5/integrated-development-v3-assessments-architecture')
PACKETS=Path('/tmp/evie-memory-stage5/integrated-development-v3-evidence/assessment-packets')
CASE={1:'dev01_fresh_tea',2:'dev02_fresh_desk',3:'dev03_uncompiled_bike',4:'dev04_uncompiled_plant',5:'dev05_clear_reference',6:'dev06_ambiguous_reference',7:'dev07_compacted_clear',8:'dev08_compacted_ambiguous'}
NO_HARD={'fabricated_source_citations':0,'retired_as_current_assertions':0,'authority_or_speaker_violations':0,'silent_conflict_resolutions':0}
WRITTEN=set()

def packet(n,condition):
    return json.loads((PACKETS/(CASE[n]+'-'+condition+'.json')).read_text())

def provenance(span,basis='none',record=None,context=None):
    return {'answer_spans':[span] if span else [],'basis':basis,'source_record_ids':[record] if record else [],'source_event_ids':[],'context_spans':[context] if context else []}

def missing(index):
    return {'index':index,'status':'missing',**provenance('')}

def component(index,span,record=None,context=None,basis=None):
    return {'index':index,'status':'supported',**provenance(span,basis or ('retrieved_evidence' if record else 'working_context'),record,context)}

def fact(span,record=None,context=None,basis=None):
    return {'status':'grounded',**provenance(span,basis or ('retrieved_evidence' if record else 'working_context'),record,context)}

def write(n,condition,components,props,*,passed,notes,cited=None,quote_records=(),extra_spans=(),clarification='not_applicable',abstention='not_applicable',attribution='not_applicable',temporal='not_applicable',general='not_applicable'):
    p=packet(n,condition);name=CASE[n]+'-'+condition+'.json';path=OUT/name
    a=json.loads(path.read_text());answer=p['final_answer']
    assert a['review_complete'] is False,name
    citations=[]
    for record in p['gold']['support_sets'][0]:
        event=p['bindings'][record]['source']['event_id']
        citations.append({'record_id':record,'status':'correct' if cited==record else 'missing','cited_event_id':event if cited==record else '', 'answer_span':event if cited==record else ''})
    quotes=[]
    for record in quote_records:
        source=p['bindings'][record]['source'];quote=source['evidence']
        assert quote in answer,(name,'manually reviewed source quote not exact')
        quotes.append({'status':'correct','source_record_id':record,'source_event_id':source['event_id'],'answer_span':quote,'quote':quote})
    extra=[]
    for record,span in extra_spans:
        event=p['bindings'][record]['source']['event_id']
        extra.append({'status':'correct','cited_event_id':event,'answer_span':span,'source_record_ids':[record],'source_event_ids':[event]})
    for item in components+props:
        for span in item['answer_spans']: assert span in answer,(name,span)
        for record in item['source_record_ids']: item['source_event_ids'].append(p['bindings'][record]['source']['event_id'])
    a.update(review_complete=True,components=components,personal_propositions=props,citations=citations,additional_citations=extra,source_quotes=quotes,behavior={'clarification':clarification,'abstention':abstention,'attribution':attribution,'temporal':temporal,'conflict':'not_applicable','general':general,'unnecessary_clarification':False},hard_violations=NO_HARD,semantic_pass=passed,notes=notes)
    path.write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n');WRITTEN.add(name)

# Each baseline was read separately. These explicit missing judgments retain
# zero expected-fact/citation credit while recognizing honest absence.
write(1,'no_recall',[missing(0)],[],passed=True,abstention='pass',notes='No original preference evidence or working context was delivered. The answer honestly declines to name a tea or invent an event ID. Missing preference and citation retain zero coverage.')
write(1,'recent_context',[missing(0)],[],passed=True,abstention='pass',notes='No preference source or recent discussion was available. The answer makes no personal assertion and honestly refuses to guess. Baseline absence is appropriate, with missing fact/citation coverage.')
write(2,'no_recall',[missing(0)],[fact('Your current message mentions a stated preference for drawing after dinner',context='What kind of desk lamp suits my stated preference for drawing after dinner?',basis='current_request')],passed=True,abstention='pass',general='pass',notes='The answer explicitly separates optional general lamp advice from an unavailable recorded preference. Its only personal-context statement is grounded in the current question; it does not infer amber light, a source ID, or personal brightness/style requirements. Missing preference/citation receive no credit.')
write(2,'recent_context',[missing(0)],[fact('Your message mentions drawing after dinner',context='What kind of desk lamp suits my stated preference for drawing after dinner?',basis='current_request')],passed=True,abstention='pass',general='pass',notes='Clearly labeled general LED advice does not become a recovered personal preference. Drawing after dinner is supplied by the question. The original preference and citation are honestly unavailable and remain missing.')
write(3,'no_recall',[missing(0)],[],passed=True,abstention='pass',notes='No riding-condition evidence was delivered. The answer requests the original source instead of inventing a condition, diagnosis, or citation. Honest baseline absence retains zero coverage.')
write(3,'recent_context',[missing(0)],[],passed=True,abstention='pass',notes='The answer accurately states that the original riding condition and event ID are unavailable. It reports no guessed personal fact or mechanical diagnosis; required fact/citation remain missing.')
write(4,'no_recall',[missing(0),missing(1)],[],passed=True,abstention='pass',notes='Both tried and untried changes are explicitly left unknown. No cause, watering action, or original event is invented. Both required components and the citation retain zero credit.')
write(4,'recent_context',[missing(0),missing(1)],[],passed=True,abstention='pass',notes='The response distinguishes its lack of evidence from a factual answer and requests original history. Neither plant action is asserted; both components and source citation remain missing.')
write(5,'no_recall',[missing(0),missing(1)],[],passed=True,clarification='pass',abstention='pass',notes='The no-recall request includes no recipient context or preference. Asking who she means is appropriate for this actual baseline and invents neither Elena nor her tastes. Both recipient and preference components/citation remain missing.')
write(5,'recent_context',[missing(0),missing(1)],[],passed=True,clarification='pass',abstention='pass',general='pass',notes='Recent discussion identifies Elena, but the answer uses only her and does not explicitly establish the named recipient, so that component remains missing. It correctly lacks preference evidence, does not ask who the recipient is, and labels the card/bouquet suggestion as general. The question about tastes is appropriate to the missing preference. Honest baseline absence does not earn preference/citation credit.')
write(7,'no_recall',[missing(0),missing(1)],[],passed=True,clarification='pass',abstention='pass',notes='This baseline receives neither the continuity summary nor preference evidence. A focused identity question is appropriate and reports no invented recipient, preference, or source. Both components/citation remain missing.')
write(7,'recent_context',[missing(0),missing(1)],[fact('Leona, your mentor',context='Leona mentor retirement present remains to choose.')],passed=True,clarification='pass',abstention='pass',attribution='pass',notes='The actually delivered canonical summary supports Leona being the mentor, but the answer conditionally says if you mean Leona rather than explicitly confirming the intended recipient; component zero is conservatively missing. It does not ask a redundant recipient question, correctly refuses to derive a preference from compaction/raster debugging, and retains missing preference/citation coverage.')

# Fresh accepted preference: four independently read supplied-source answers.
for condition,span,quotes in [
 ('tool_only','You said you prefer **roasted barley tea** in the evening.',('dev01_tea',)),
 ('automatic','You said your preferred evening tea is **roasted barley tea**.',('dev01_tea',)),
 ('automatic_deeper','You said your preferred evening tea is **roasted barley tea**.',('dev01_tea',)),
 ('oracle','You said you prefer **roasted barley tea** in the evening.',()),
]:
    write(1,condition,[component(0,span,'dev01_tea')],[fact(span,'dev01_tea')],passed=True,cited='dev01_tea',quote_records=quotes,attribution='pass',notes='The actual accepted owner source states roasted barley tea as the evening preference. This answer states that fact, cites its exact original event, and makes no health-benefit or save claim. Every claimed source quote in this answer is exact; repeated statement/quotation expresses the same inventoried preference.')

for condition,span,quotes in [
 ('tool_only','A **warm amber desk lamp** suits your stated preference for drawing after dinner.',('dev02_lamp',)),
 ('automatic','A **warm amber desk lamp** suits your stated preference for drawing after dinner.',()),
 ('automatic_deeper','A **warm amber desk lamp** suits your stated preference for drawing after dinner.',('dev02_lamp',)),
 ('oracle','A **warm amber desk lamp** suits your stated preference for drawing after dinner.',('dev02_lamp',)),
]:
    write(2,condition,[component(0,span,'dev02_lamp')],[fact(span,'dev02_lamp')],passed=True,cited='dev02_lamp',quote_records=quotes,attribution='pass',general='pass' if condition in ('automatic','oracle') else 'not_applicable',notes='Warm amber light for drawing after dinner is supported by the delivered accepted owner statement and exact original event citation. Any arm/dimmer advice is explicitly a new suggestion, not a personal requirement. The deeper answer limits its unspecified-brand/brightness comment to the evidence. Claimed original quotation, where present, reproduces the full source bytes.')

for condition,span,quotes in [
 ('tool_only','You associated the dry clicking sound with **pedaling uphill in the largest rear cog—and only under that condition**.',('dev03_bike',)),
 ('automatic','You said the dry clicking sound occurs **only when you pedal uphill in the largest rear cog**.',()),
 ('automatic_deeper','You associated the dry clicking sound with **pedaling uphill in the largest rear cog—and only under that condition**.',()),
 ('oracle','You said the dry clicking sound occurs **only when you pedal uphill in the largest rear cog**.',()),
]:
    write(3,condition,[component(0,span,'dev03_bike')],[fact(span,'dev03_bike')],passed=True,cited='dev03_bike',quote_records=quotes,attribution='pass',temporal='pass',notes='The original owner episode supplies the exclusive uphill/largest-rear-cog condition. The answer attributes the report to the owner and cites the exact event; it does not diagnose a damaged part or promote the episode to accepted memory. Historical retrieval in the tool-only condition retains original wording support. No unrelated bell fact is asserted.')

for condition,move,not_water in [
 ('tool_only','You had tried moving the balcony fern away from the vent','You had not tried changing its watering schedule.'),
 ('automatic','You had tried moving the balcony fern away from the vent','You had not tried changing its watering schedule.'),
 ('automatic_deeper','moved the balcony fern away from the vent','not tried changing its watering schedule'),
 ('oracle','moved the balcony fern away from the vent','not tried changing its watering schedule'),
]:
    p=packet(4,condition)
    second=p['final_answer'].splitlines()[1]
    write(4,condition,[component(0,move,'dev04_plant'),component(1,not_water,'dev04_plant')],[fact(move,'dev04_plant'),fact('after which it perked up','dev04_plant'),fact(not_water,'dev04_plant')],passed=True,cited='dev04_plant',extra_spans=[('dev04_plant',second)],attribution='pass',temporal='pass',notes='The two actions and separate observed improvement are inventoried: moving away from the vent, subsequent perking up, and not trying a watering change. After which is temporal sequence rather than proof of cause. Each bullet cites the correct owner event; the repeated second citation is retained as an additional citation. No accepted diagnosis or new watering action is claimed.')

ELENA_CONTEXT='I am choosing a small thank-you present for my aunt Elena.'
for condition,span in [
 ('tool_only','A nice jar of **apricot preserves** would be a good small thank-you present for Elena—you previously said she likes them as a small present.'),
 ('automatic','A small jar of **apricot preserves** would be a good choice for Elena—you previously said she likes them as a small present.'),
 ('automatic_deeper','A nice jar of **apricot preserves** would be a good choice for Elena—you said she likes them as a small present.'),
 ('oracle','A small jar of **apricot preserves** would be a good choice for Elena—you said she likes them as a small present.'),
]:
    write(5,condition,[component(0,'Elena',context=ELENA_CONTEXT),component(1,span,'dev05_elena')],[fact('for Elena',context=ELENA_CONTEXT),fact(span,'dev05_elena')],passed=True,cited='dev05_elena',clarification='pass',attribution='pass',general='pass' if condition=='automatic' else 'not_applicable',notes='The named recipient Elena resolves the already explicit discussion; the aunt label distinguishes the same person and need not be redundantly restated to identify her. Her apricot-preserves preference comes from the accepted original owner source, not the unrelated recent Bruno/debugging mention. The answer cites that exact event and does not unnecessarily clarify. A thank-you note, where suggested, is general advice.')

LEONA_CONTEXT='Leona mentor retirement present remains to choose.'
for condition,span,quotes in [
 ('tool_only','Leona would prefer a **pocket star atlas over a decorative mug**, according to your original statement.',()),
 ('automatic','Leona would prefer a **pocket star atlas over a decorative mug**, according to your original statement',()),
 ('automatic_deeper','Leona would prefer a **pocket star atlas over a decorative mug**.',()),
 ('oracle','Leona would prefer a **pocket star atlas over a decorative mug**.',('dev07_leona',)),
]:
    props=[fact('Leona',context=LEONA_CONTEXT),fact(span,'dev07_leona')]
    if condition=='automatic': props.append(fact('for her retirement present',context=LEONA_CONTEXT))
    if condition=='oracle': props.append(fact('my mentor','dev07_leona'))
    write(7,condition,[component(0,'Leona',context=LEONA_CONTEXT),component(1,span,'dev07_leona')],props,passed=True,cited='dev07_leona',quote_records=quotes,clarification='pass',attribution='pass',notes='Actual canonical compaction supplies Leona/mentor recipient continuity only; the atlas-over-mug preference is grounded in the separately delivered accepted original owner source and exact event citation. The answer directly keeps Leona as the recipient without needless clarification. Any retirement-purpose wording comes from continuity. The oracle full-source quotation is exact; no summary is used as a preference source.')

# Each ambiguity answer was inspected individually; none recommends a personal
# gift or reports a preference. Candidate names are questions, not assertions.
for n,condition,notes in [
 (6,'no_recall','A single generic recipient question is appropriate because no candidate discussion was delivered. No candidate names or personal preferences are invented.'),
 (6,'recent_context','Asks Celia or Daria using the actual undecided reader discussion; gives no recommendation.'),
 (6,'tool_only','Asks Celia or Daria before any personalized suggestion. The current discussion explicitly leaves the recipient undecided.'),
 (6,'automatic','Asks Celia or Daria despite receiving both preferences; does not recommend either, even conditionally.'),
 (6,'automatic_deeper','Asks one focused Celia-or-Daria question, preserving the unresolved recipient despite available preference evidence.'),
 (6,'oracle','The no-support oracle plus actual undecided discussion yields the appropriate Celia-or-Daria clarification, with no preference asserted.'),
 (8,'no_recall','The single recipient-identification question also asks relationship information in the same focused request. With no candidate context, this is appropriate clarification rather than invented names or a personal recommendation.'),
 (8,'recent_context','The supplied canonical summary preserves an unresolved Roxana-or-Selma choice. The answer asks exactly that choice and suggests no keepsake.'),
 (8,'tool_only','The answer uses the unresolved Roxana/Selma continuity to ask before recommending. It makes no personal factual assertion or preference claim.'),
 (8,'automatic','Asks Roxana or Selma despite both accepted keepsake preferences being supplied. It does not silently turn compaction into an identity decision.'),
 (8,'automatic_deeper','The question remains focused on Roxana versus Selma, with no conditional keepsake suggestions before the user resolves the recipient.'),
 (8,'oracle','The summary identifies the two still-unresolved candidates; the answer clarifies them and does not manufacture preference evidence from the empty oracle support set.'),
]:
    write(n,condition,[],[],passed=True,clarification='pass',notes=notes+' No original-source citations or claimed verbatim source quotations occur; personal-proposition inventory is empty, not perfect grounding credit.')

assert len(WRITTEN)==48,len(WRITTEN)
print('Serialized 48 explicit manually reviewed v3 assessments; no automatic semantic judgments.')
