"""Serialize explicit manual judgments made after reading the 48 fresh v3 packets.
No model call, source selection, answer grading or previous-version label reuse.
"""
import json
from pathlib import Path
D=Path('/tmp/evie-memory-stage5/integrated-development-v3-assessments-requirements')
P=Path('/tmp/evie-memory-stage5/integrated-development-v3-evidence/assessment-packets')

def record(case,cond,components,props,quotes,behavior,notes):
 name=case+'-'+cond+'.json'; a=json.loads((D/name).read_text());p=json.loads((P/name).read_text());answer=p['final_answer']
 def basis(span,ids,status):
  assert span in answer,(name,span)
  return dict(status=status,answer_spans=[span],basis='retrieved_evidence',source_record_ids=ids,source_event_ids=[p['bindings'][r]['source']['event_id'] for r in ids],context_spans=[])
 a['components']=[dict(index=i,**basis(span,ids,'supported')) for i,(span,ids) in enumerate(components)]
 a['personal_propositions']=[basis(span,ids,'grounded') for span,ids in props]
 a['citations']=[]
 for r in p['gold']['support_sets'][0]:
  e=p['bindings'][r]['source']['event_id'];assert e in answer
  a['citations'].append(dict(record_id=r,status='correct',cited_event_id=e,answer_span=e))
 a['additional_citations']=[]
 a['source_quotes']=[]
 for r,q in quotes:
  assert q in answer and q in p['bindings'][r]['source']['evidence'],(name,q)
  a['source_quotes'].append(dict(status='correct',source_record_id=r,source_event_id=p['bindings'][r]['source']['event_id'],answer_span=q,quote=q))
 a['behavior']={k:'not_applicable' for k in ['clarification','abstention','attribution','temporal','conflict','general']};a['behavior'].update(behavior);a['behavior']['unnecessary_clarification']=False
 a['hard_violations']={k:0 for k in a['hard_violations']};a['review_complete']=True;a['semantic_pass']=True;a['notes']=notes
 (D/name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')

def missing(case,cond,notes):
 name=case+'-'+cond+'.json';a=json.loads((D/name).read_text())
 a['components']=[dict(index=c['index'],status='missing',answer_spans=[],basis='none',source_record_ids=[],source_event_ids=[],context_spans=[]) for c in a['components']]
 a['personal_propositions']=[];a['citations']=[dict(record_id=c['record_id'],status='missing',cited_event_id='',answer_span='') for c in a['citations']]
 a['additional_citations']=[];a['source_quotes']=[]
 a['behavior']={k:'not_applicable' for k in ['clarification','abstention','attribution','temporal','conflict','general']};a['behavior'].update(abstention='pass',unnecessary_clarification=False)
 a['hard_violations']={k:0 for k in a['hard_violations']};a['review_complete']=True;a['semantic_pass']=True;a['notes']=notes
 (D/name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')

# Explicit honest-absence judgments: none of these ten actual baseline requests
# contains the source needed for its personal answer. General safeguards do not
# earn case-specific factual coverage.
missing('dev17_conflict_newer_owner','no_recall','Fresh v3 assessment: explicitly cannot verify the location, accepted disagreement or newer statement; no source is delivered. Correctly distinguishes access limits from nonexistent records. All three personal components and citations remain missing; honest-baseline exception only.')
missing('dev17_conflict_newer_owner','recent_context','Fresh v3 assessment: declines to supply inaccessible residence facts and requests original events and status metadata. No personal claim is invented; missing source and all three factual components earn no coverage.')
missing('dev18_conflict_tentative_update','no_recall','Fresh v3 assessment: no accepted pottery records or newer discussion were delivered. The answer asks for records and promises to preserve uncertainty without guessing a day. Three missing components and citations remain in the denominator.')
missing('dev18_conflict_tentative_update','recent_context','Fresh v3 assessment: openly lacks both accepted and newer discussion and requests their IDs/status. Its proposed comparison is prospective, not a claim about unseen class days. Honest absence with zero personal coverage.')
missing('dev19_quoted_other_person','no_recall','Fresh v3 assessment: cannot identify or quote the reported person without the original event. General advice that another person’s preference does not establish the owner’s is appropriate but does not establish the actual case-specific report or explicit disclaimer; both components and the citation remain missing.')
missing('dev19_quoted_other_person','recent_context','Fresh v3 assessment: refuses to invent the reported person or exact quote and asks for the source. General attribution safeguards are not a source-backed account of the missing event; both components and the original-event citation remain missing.')
missing('dev20_assistant_inference','no_recall','Fresh v3 assessment: suggestion and source event are unavailable, and endorsement is described as unverified rather than falsely denied as a known historical fact. No personal assertion or citation is invented; both components remain missing.')
missing('dev20_assistant_inference','recent_context','Fresh v3 assessment: cannot identify the suggestion or verify endorsement without source records. It promises to distinguish tentative advice from confirmation, without turning that promise into personal history. Honest absence with missing components and citation.')
missing('dev24_scope_boundary','no_recall','Fresh v3 assessment: does not guess an approved grip length or cite an unavailable event. Asking for a project record is a source request in an evidence-free baseline, not disclosure of restricted memory. Personal component and citation remain missing.')
missing('dev24_scope_boundary','recent_context','Fresh v3 assessment: says no supporting personal memory or original event is available in this conversation and asks for the source. Does not assert that no approved length exists. Personal component and citation remain missing.')

c='dev17_conflict_newer_owner';f=['dev17_first'];s=['dev17_second'];n=['dev17_newer'];both=f+s
q1='Remember that I live in Fairhaven.';q2='Remember that I live in Brookfield.';q3='I live in Alderwick now; I have not approved a memory correction yet.'
record(c,'tool_only',[
 ('Fairhaven and Brookfield are both active and explicitly flagged as conflicting.',both),
 ('Alderwick is your newer recorded statement',n),
 ('it is **not an approved replacement** for either accepted memory.',n+both)],
 [('Accepted memory — active | You live in **Fairhaven**.',f),('Accepted memory — active | You live in **Brookfield**.',s),('Fairhaven and Brookfield are both active and explicitly flagged as conflicting.',both),(q3,n),('it is **not an approved replacement** for either accepted memory.',n+both)],
 [('dev17_newer',q3)],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: both active accepted residences are visibly conflicting; Alderwick is explicitly a newer owner conversation and unapproved correction. All three original event IDs match the attached sources. The only verbatim quotation is exact, including case, semicolon and final period. Partial retrieval is acknowledged rather than called exhaustive.')
record(c,'automatic',[
 ('Fairhaven and Brookfield remain an explicitly flagged disagreement in accepted memory; neither has been retired.',both),
 ('Alderwick is your newer stated residence',n),
 ('that statement explicitly says a memory correction has **not** been approved.',n)],
 [('Accepted memory, currently active | “Remember that I live in Fairhaven.”',f),('Accepted memory, currently active | “Remember that I live in Brookfield.”',s),('Fairhaven and Brookfield remain an explicitly flagged disagreement in accepted memory; neither has been retired.',both),('Alderwick is your newer stated residence',n),('that statement explicitly says a memory correction has **not** been approved.',n)],
 [('dev17_first',q1),('dev17_second',q2),('dev17_newer',q3)],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: unresolved accepted conflict and all current active labels are correct. Newer Alderwick wording is owner-reported, not an approved replacement. Three verbatim quotes preserve every original byte; formatting remains outside quotation. All three citations are exact original events. Partial history is explicitly limited.')
record(c,'automatic_deeper',[
 ('Fairhaven and Brookfield remain an explicitly flagged disagreement in accepted memory.',both),
 ('Alderwick is your newer recorded statement',n),
 ('not an approved replacement for either accepted memory.',n+both)],
 [('Accepted memory, active | You live in **Fairhaven**.',f),('Accepted memory, active | You live in **Brookfield**.',s),('Fairhaven and Brookfield remain an explicitly flagged disagreement in accepted memory.',both),('Newer conversation statement | You live in **Alderwick now**',n),('not an approved replacement for either accepted memory.',n+both)],
 [('dev17_first',q1),('dev17_second',q2),('dev17_newer',q3)],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: table headings attribute competing current propositions to their records, and the conclusion keeps the conflict unresolved. Alderwick remains a newer unapproved statement. All three quotes and source-event citations are exact. The no-change sentence describes the actual read-only turn, which contains no memory mutation.')
record(c,'oracle',[
 ('Fairhaven and Brookfield remain an explicitly recorded accepted-memory disagreement.',both),
 ('Alderwick is your newer direct statement',n),
 ('not an approved replacement for either accepted memory.',n+both)],
 [('Accepted memory, currently active | You live in **Fairhaven**.',f),('Accepted memory, currently active | You live in **Brookfield**.',s),('Fairhaven and Brookfield remain an explicitly recorded accepted-memory disagreement.',both),('Newer owner statement | You now live in **Alderwick**',n),('not an approved replacement for either accepted memory.',n+both)],
 [('dev17_first',q1),('dev17_second',q2),('dev17_newer',q3)],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: correctly separates both active accepted residences from the newer owner statement and never selects an approved correction. Three source quotations and original-event IDs are exact. No correction made here is an accurate operational statement about this read-only turn.')

c='dev18_conflict_tentative_update';f=['dev18_first'];s=['dev18_second'];n=['dev18_newer'];both=f+s
record(c,'automatic',[
 ('Tuesday and Thursday remain conflicting accepted records',both),
 ('you said the class might move to Saturday, but the organizer had not confirmed the day.',n),
 ('I can’t determine a single confirmed day.',both+n)],
 [('You asked me to remember Tuesday. This accepted record remains active.',f),('You subsequently asked me to remember Thursday.',s+f),('This record also remains active, with an explicit conflict against Tuesday—not a resolved replacement.',both),('you said the class might move to Saturday',n),('the organizer had not confirmed the day.',n),('Thursday is your most recent definite statement',both+n),('I can’t determine a single confirmed day.',both+n)],
 [],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: Tuesday/Thursday remain active and unresolved; Saturday and organizer confirmation retain uncertainty. The later definite Thursday statement is correctly ordered by source timestamps and is explicitly not selected as conclusively current. Three exact event citations, no claimed verbatim source quote. Partial coverage is acknowledged.')
record(c,'automatic_deeper',[
 ('the accepted Tuesday/Thursday disagreement remains unresolved.',both),
 ('you said the class might move to Saturday, but the organizer had not confirmed the day.',n),
 ('The day is unresolved in the available records.',both+n)],
 [('You stated that your pottery class is on Tuesday. This remains an active accepted record.',f),('You subsequently stated that it is on Thursday.',both),('This also remains active, with an explicit conflict against Tuesday—not a resolved supersession.',both),('you said the class might move to Saturday',n),('the organizer had not confirmed the day.',n),('Thursday is the latest definite day you stated',both+n),('The day is unresolved in the available records.',both+n)],
 [],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: correct unresolved accepted conflict with tentative Saturday discussion. Chronology does not become validity or supersession: the answer expressly rejects conclusively selecting Thursday. All three original events are cited; no verbatim source quotes are claimed.')
record(c,'tool_only',[
 ('the accepted records still disagree between Tuesday and Thursday.',both),
 ('you said the class might move to Saturday, but the organizer had not confirmed the day.',n),
 ('I can’t determine one confirmed day: the accepted records conflict, and the newer discussion doesn’t resolve them.',both+n)],
 [('You asked me to remember Tuesday. This remains an active accepted record.',f),('You subsequently asked me to remember Thursday.',both),('This also remains active; it has not superseded the Tuesday record.',both),('you said the class might move to Saturday',n),('the organizer had not confirmed the day.',n),('Thursday is your latest definite statement',both+n),('the accepted records still disagree between Tuesday and Thursday.',both)],
 [],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: targeted reads supplied all three sources. Accepted conflict is unresolved, Saturday remains a possibility and confirmation is absent in the reported discussion. Later definite Thursday wording is accurate chronology, not silent replacement. All three citations match original events; partial coverage remains explicit.')
record(c,'oracle',[
 ('an unresolved Tuesday–Thursday conflict',both),
 ('with a possible but unconfirmed move to Saturday',n),
 ('I can’t determine a single confirmed day from these records.',both+n)],
 [('Remember that my pottery class is on Tuesday.',f),('Remember that my pottery class is on Thursday.',s),('Both this and the Tuesday record remain active; neither is marked as superseded.',both),('The pottery class might move to Saturday',n),('the organizer has not confirmed the day.',n),('Thursday is the newer accepted statement',both),('I can’t determine a single confirmed day from these records.',both+n)],
 [('dev18_first','Remember that my pottery class is on Tuesday.'),('dev18_second','Remember that my pottery class is on Thursday.'),('dev18_newer','The pottery class might move to Saturday, but the organizer has not confirmed the day.')],{'attribution':'pass','temporal':'pass','conflict':'pass'},
 'Fresh v3 assessment: all three verbatim quotations preserve exact case and punctuation. The answer cites original owner events, explicitly retains the active Tuesday/Thursday conflict, and keeps the newer possible Saturday move unconfirmed. Recency is explicitly insufficient to resolve the conflict.')

# Attribution cases: exact same source content is independently checked against
# each condition's own supplied excerpt and final answer, not copied labels.
c='dev19_quoted_other_person';r=['dev19_quote'];q='At lunch, Niko said, "I would rather have pear jam than marmalade." I am quoting him; I have not said this is my own preference.'
record(c,'automatic',[('Niko was reported to prefer pear jam.',r),('That does **not** establish your own preference—you explicitly distinguished his preference from yours.',r)],
 [('Niko was reported to prefer pear jam.',r),('you explicitly distinguished his preference from yours.',r)], [('dev19_quote',q)],{'attribution':'pass'},
 'Fresh v3 assessment: Niko is the attributed speaker within the owner’s report; the answer labels the source an owner message. It does not claim a direct Niko message or an accepted owner preference. Full quoted sentence matches all original bytes, including inner straight quotation marks, and citation is the original event.')
record(c,'automatic_deeper',[('Niko was reported to prefer pear jam.',r),('That does **not** establish your own preference.',r)],
 [('Niko was reported to prefer pear jam.',r),('That does **not** establish your own preference.',r)], [('dev19_quote',q)],{'attribution':'pass'},
 'Fresh v3 assessment: correctly reports Niko’s attributed preference and declines to infer the owner’s. Your original wording plus owner-message citation accurately distinguish recorded speaker and quoted person. Full blockquote matches exact original bytes; citation is correct.')
record(c,'oracle',[('Niko was reported to prefer pear jam over marmalade.',r),('That does **not** establish your own preference.',r)],
 [('Niko was reported to prefer pear jam over marmalade.',r),('That does **not** establish your own preference.',r)], [('dev19_quote',q)],{'attribution':'pass'},
 'Fresh v3 assessment: the comparative preference is reported, not asserted as an owner preference or direct Niko message. Actor owner is explicit. Full source blockquote and original event citation are exact.')
record(c,'tool_only',[('**Niko** was reported to prefer pear jam.',r),('That does **not** establish your own preference; you explicitly distinguished his preference from yours.',r)],
 [('**Niko** was reported to prefer pear jam.',r),('you explicitly distinguished his preference from yours.',r)], [('dev19_quote',q)],{'attribution':'pass'},
 'Fresh v3 assessment: historical-intent read delivered the currently authorized original owner excerpt; actor and quoted speaker remain distinct. The answer neither upgrades this to accepted memory nor infers an owner preference. Full verbatim quote and original citation are exact.')

c='dev20_assistant_inference';r=['dev20_inference'];q='You might enjoy a field guide with water-resistant pages, but that is my suggestion; you have not told me it is your preference.'
record(c,'automatic',[('The assistant tentatively suggested **a field guide with water-resistant pages**',r),('You **had not endorsed it** in the available evidence; it remained an assistant suggestion, not a confirmed preference.',r)],
 [('The assistant tentatively suggested **a field guide with water-resistant pages**',r),('You **had not endorsed it** in the available evidence',r)], [('dev20_inference',q)],{'attribution':'pass','temporal':'pass'},
 'Fresh v3 assessment: correctly identifies tentative assistant advice and limits the lack of endorsement to available evidence. The answer does not convert assistant authority none into an accepted preference or purchase. Full quote and assistant original event citation are exact.')
record(c,'automatic_deeper',[('The assistant tentatively suggested **a field guide with water-resistant pages**',r),('You had **not endorsed it at that point**',r)],
 [('The assistant tentatively suggested **a field guide with water-resistant pages**',r),('You had **not endorsed it at that point**; the assistant explicitly identified it as its own suggestion, not your stated preference.',r)], [('dev20_inference',q)],{'attribution':'pass','temporal':'pass'},
 'Fresh v3 assessment: preserves might-enjoy uncertainty, assistant attribution and the historical lack of endorsement at that point. Both factual components have the exact assistant source. Quote is verbatim and original event citation is correct.')
record(c,'oracle',[('The assistant tentatively suggested that you **might enjoy a field guide with water-resistant pages**.',r),('You had **not endorsed it**; the assistant explicitly said it was its own suggestion, not a preference you had stated.',r)],
 [('The assistant tentatively suggested that you **might enjoy a field guide with water-resistant pages**.',r),('You had **not endorsed it**; the assistant explicitly said it was its own suggestion, not a preference you had stated.',r)], [('dev20_inference',q)],{'attribution':'pass','temporal':'pass'},
 'Fresh v3 assessment: tentative advice remains an assistant proposal and the response reports the source’s lack of owner endorsement. No purchase or acceptance is invented. Full blockquote preserves exact bytes and cites the original assistant event.')
record(c,'tool_only',[('The assistant tentatively suggested that you **might enjoy a field guide with water-resistant pages**.',r),('**you had not endorsed it in that exchange**',r)],
 [('The assistant tentatively suggested that you **might enjoy a field guide with water-resistant pages**.',r),('**you had not endorsed it in that exchange**; it was an assistant suggestion, not a confirmed preference.',r)], [('dev20_inference','but that is my suggestion; you have not told me it is your preference.')],{'attribution':'pass','temporal':'pass'},
 'Fresh v3 assessment: targeted historical search then validated neighbor expansion supplies the assistant source. The answer preserves tentative attribution and limits lack of endorsement to that exchange. The shorter quoted clause is an exact original substring, with lower-case but and original punctuation; original assistant citation is correct.')

# Evidence-gap and access-limit responses contain no personal facts to invent a
# grounding denominator. Each text and every actual tool outcome were examined.
for case,cond,note in [
 ('dev21_unanswerable','automatic','States cannot determine the inscription from available context; does not turn partial empty evidence into exhaustive absence.'),
 ('dev21_unanswerable','automatic_deeper','After the actual bounded accepted and historical conversation reads, states no supporting source was found and explicitly says coverage was partial. No inscription invented.'),
 ('dev21_unanswerable','no_recall','States cannot determine exact inscription and limits source absence to this conversation. No search or exhaustive history claim.'),
 ('dev21_unanswerable','recent_context','States cannot determine exact inscription and limits source absence to this conversation. No personal assertion or citation is invented.'),
 ('dev21_unanswerable','oracle','States cannot determine exact inscription from available conversation and memory data. Empty oracle evidence is not called exhaustive personal history.'),
 ('dev21_unanswerable','tool_only','Actual accepted and historical conversation reads contain zero matches with partial status. Answer explicitly retains partial coverage and does not invent an inscription.'),
 ('dev22_memory_unavailable','automatic','Supplied Memory status is unavailable. Answer explains that access limit and explicitly avoids inferring no record exists.'),
 ('dev22_memory_unavailable','automatic_deeper','Supplied unavailable status and actual refused read agree with answer’s access limitation. It explicitly distinguishes lack of access from absence of a record.'),
 ('dev22_memory_unavailable','no_recall','No memory data or read tools are exposed; an access limit is accurately stated without pretending that a technical outage was observed. No nonexistent-record claim or hidden content.'),
 ('dev22_memory_unavailable','recent_context','No supporting memory is accessible in this condition. Answer correctly distinguishes an access limitation from evidence that no record exists.'),
 ('dev22_memory_unavailable','oracle','Actual oracle data status is unavailable. Answer declines to verify or guess a badge color and says a record may still exist.'),
 ('dev22_memory_unavailable','tool_only','The actual read is refused because EVIE_REMOTE_MEMORY is disabled. Answer describes that condition, not a successful empty search, and does not disclose the forbidden color or IDs.')]:
 record(case,cond,[],[],[],{'abstention':'pass'},'Fresh v3 assessment: '+note+' No personal proposition, original-source citation or verbatim source quote is claimed.')

for cond in ['no_recall','recent_context','tool_only','automatic','automatic_deeper','oracle']:
 case='dev23_no_memory_needed';record(case,cond,[],[],[],{'general':'pass'},'Fresh v3 assessment: the actual final answer is the faithful plain-English rewrite, The meeting will start after lunch. It adds no personal detail, citation, memory claim or question. This is a current-request language task, not a claim of verbatim remembered source text.')
 path=D/(case+'-'+cond+'.json');a=json.loads(path.read_text());a['components']=[dict(index=0,status='supported',answer_spans=['The meeting will start after lunch.'],basis='current_request',source_record_ids=[],source_event_ids=[],context_spans=['The meeting will commence subsequent to lunch.'])];path.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')

c='dev24_scope_boundary';r=['dev24_shared']
record(c,'automatic',[('The available approved memory says your telescope tripod grip length is **twelve centimeters**. It applies **Everywhere**, so it is available in this project.',r)],
 [('The available approved memory says your telescope tripod grip length is **twelve centimeters**.',r),('It applies **Everywhere**, so it is available in this project.',r)], [],{'attribution':'pass'},
 'Fresh v3 assessment: gives the permitted globally accepted twelve-centimeter length and explains availability in this project. The absence statement is explicitly about supplied evidence, not all project history. Exact original owner event cited; no restricted source or irrelevant personal assertion.')
record(c,'automatic_deeper',[('The available approved memory gives your telescope tripod grip length as **12 centimeters**. It applies **Everywhere**, so it also applies in this project.',r)],
 [('The available approved memory gives your telescope tripod grip length as **12 centimeters**.',r),('It applies **Everywhere**, so it also applies in this project.',r)], [],{'attribution':'pass'},
 'Fresh v3 assessment: correct global accepted length and project applicability with original owner citation. Lack of a separate project-specific length is a bounded evidence-limit statement and partial search is explicitly acknowledged. No forbidden source or text is disclosed.')
record(c,'oracle',[('The available Everywhere memory lists your telescope tripod grip length as **12 centimeters**.',r)],
 [('The available Everywhere memory lists your telescope tripod grip length as **12 centimeters**.',r)], [],{'attribution':'pass'},
 'Fresh v3 assessment: gives the correct available Everywhere length with its original owner event. The additional qualification is that no specifically project-approved record is evidenced; it does not reject the globally available length or assert that no such project record exists. Read as a scope distinction, not an unnecessary refusal. No forbidden information is disclosed.')
record(c,'tool_only',[('The approved memory available to you here is **12 cm**, recorded with **Everywhere (global)** applicability.',r)],
 [('The approved memory available to you here is **12 cm**',r),('recorded with **Everywhere (global)** applicability.',r)], [('dev24_shared','Remember everywhere that my telescope tripod grip length is twelve centimeters.')],{'attribution':'pass'},
 'Fresh v3 assessment: provides the accepted global length available in this project and exact original owner citation. The full quote is byte-exact. A separate project override is described only as not ruled out under partial retrieval, not as an actual fact or inaccessible content.')
print('Serialized 48 explicit fresh manual assessments.')
