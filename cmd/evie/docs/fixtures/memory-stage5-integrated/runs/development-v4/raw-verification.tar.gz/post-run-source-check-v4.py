from pathlib import Path
import importlib.util,hashlib,json
b=Path('/tmp/evie-memory-stage5');f=b/'integrated-development-v4/freeze.json';root=Path('/Users/davidboktor/code/evie-memory-stage-5')
s=importlib.util.spec_from_file_location('frozen_v4_runner',f.parent/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.verify_freeze(f)
manifest=json.loads((f.parent/'compiled-source-manifest.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in manifest.items())
reader=b/'integrated-development-v4-reader';cases=list(reader.glob('*-case.json'));assert len(cases)==144
assert all(json.loads(p.read_text()).get('error')=='<nil>' for p in cases)
e=json.loads((b/'integrated-development-v4-evidence/evidence-report.json').read_text());calls=sum(v['observed_model_calls'] for v in e['conditions'].values());assert calls==len(list(reader.glob('*-wire-request.json')))==len(list(reader.glob('*-encoded-request.json')))
print(json.dumps(dict(frozen_inputs_verified=True,current_compiled_inputs_equal=len(manifest),reader_cases=len(cases),observed_model_calls=calls,exact_wire_and_encoded_requests=calls,turn_errors=0,source_violations=len(e['violations']))))
