"""Serialize explicit manual V4 judgments after reading all 48 packets; no semantic inference."""
from pathlib import Path
import json
BASE=Path('/tmp/evie-memory-stage5')
OUT=BASE/'integrated-development-v4-assessments-architecture'
PACKETS=BASE/'integrated-development-v4-evidence/assessment-packets'
rows={}

def declare(case,condition,*,components,props,citations,quotes,clarification,abstention,attribution,notes,semantic_pass=True):
    key=f'{case}-{condition}'
    assert key not in rows
    p=json.loads((PACKETS/(key+'.json')).read_text())
    a=json.loads((OUT/(key+'.json')).read_text())
    assert not a['review_complete']
    answer=p['final_answer']
    def fact(span,record=None,context=None,status='grounded'):
        assert span in answer,(key,span)
        return dict(status=status,answer_spans=[span],basis='retrieved_evidence' if record else 'working_context',source_record_ids=[record] if record else [],source_event_ids=[p['bindings'][record]['source']['event_id']] if record else [],context_spans=[context] if context else [])
    cs=[]
    for i,item in enumerate(components):
        if item is None:
            cs.append(dict(index=i,status='missing',answer_spans=[],basis='none',source_record_ids=[],source_event_ids=[],context_spans=[]))
        else:
            span,record,context=item
            cs.append(dict(index=i,**fact(span,record,context,'supported')))
    ps=[fact(*item) for item in props]
    required=[];extra=[]
    for record,spanlist in citations.items():
        event=p['bindings'][record]['source']['event_id']
        if not spanlist:
            required.append(dict(record_id=record,status='missing',cited_event_id='',answer_span=''))
        else:
            for j,span in enumerate(spanlist):
                assert span in answer and event in span,(key,span)
                if j==0: required.append(dict(record_id=record,status='correct',cited_event_id=event,answer_span=span))
                else:extra.append(dict(status='correct',cited_event_id=event,answer_span=span,source_record_ids=[record],source_event_ids=[event]))
    qs=[]
    for record,quote in quotes:
        # Correctness was manually judged; these assertions only guard transcription.
        assert quote in answer and quote in p['bindings'][record]['source']['evidence'],(key,quote)
        qs.append(dict(status='correct',source_record_id=record,source_event_id=p['bindings'][record]['source']['event_id'],answer_span=quote,quote=quote))
    a.update(review_complete=True,components=cs,personal_propositions=ps,citations=required,additional_citations=extra,source_quotes=qs,behavior=dict(clarification=clarification,abstention=abstention,attribution=attribution,temporal='not_applicable',conflict='not_applicable',general='not_applicable',unnecessary_clarification=False),hard_violations=dict(fabricated_source_citations=0,retired_as_current_assertions=0,authority_or_speaker_violations=0,silent_conflict_resolutions=0),semantic_pass=semantic_pass,notes=notes)
    rows[key]=a

def supported(case,condition,components,props,record,citation_spans,quotes=(),notes=''):
    declare(case,condition,components=components,props=props,citations={record:citation_spans},quotes=quotes,clarification='not_applicable',abstention='not_applicable',attribution='pass',notes=notes)

def baseline(case,condition,n,record,notes,components=None,props=(),clarification='not_applicable'):
    declare(case,condition,components=components if components is not None else [None]*n,props=props,citations={record:[]},quotes=[],clarification=clarification,abstention='pass',attribution='not_applicable',notes=notes)

# 01: each source-bearing answer explicitly states the same one preference and quotes its exact original.
c='dev01_fresh_tea';r='dev01_tea';event='7e1f5928-6e41-4eb3-95dc-f7787a07af2b';q='Remember that my preferred evening tea is roasted barley tea.'
baseline(c,'no_recall',1,r,'No source or working context was delivered. Honest explicit inability to identify the tea; no personal assertion, invented event or exhaustive absence claim. Missing component/citation earn zero coverage.')
baseline(c,'recent_context',1,r,'No relevant original or working context was available. Explicit refusal to guess is appropriate baseline behavior; the tea and citation remain missing.')
for condition,span in [('tool_only','You said you prefer **roasted barley tea** in the evening.'),('automatic','You said you prefer **roasted barley tea** in the evening.'),('automatic_deeper','You said you prefer **roasted barley tea** in the evening.'),('oracle','You said your preferred evening tea is **roasted barley tea**.')]:
    supported(c,condition,[(span,r,None)],[(span,r,None)],r,[event],[(r,q)],'Correct stated evening-tea preference, original owner attribution, exact original-event citation and exact quoted bytes. Repeating the same preference in the source quote adds no independent factual proposition. No invented health benefit or new save.')

# 02: buying suggestions are explicitly general; no preferences are inferred from them.
c='dev02_fresh_desk';r='dev02_lamp';event='72e85a4b-3af2-4348-9336-0cb44f95e5df';q='Remember that I prefer a warm amber desk lamp when I draw after dinner.'
baseline(c,'no_recall',1,r,'Explicitly general lamp advice, with clear lack of the original personal preference and source ID. The current-message description is a statement about task wording, not a verified prior preference. No brightness, handedness, budget or drawing-medium preference is asserted. Missing warm-amber component/citation retain zero credit.')
baseline(c,'recent_context',1,r,'General lighting advice is explicitly separated from any memory-backed match. No personal lighting requirement is asserted; the original preference and citation are acknowledged missing.')
for condition in ['tool_only','automatic','automatic_deeper','oracle']:
    span='A **warm amber desk lamp** suits your stated preference for drawing after dinner.'
    quotes=[(r,q)] if condition in ['tool_only','automatic_deeper','oracle'] else []
    supported(c,condition,[(span,r,None)],[(span,r,None)],r,[event],quotes,'Correct warm-amber preference and owner event. Any additional adjustability/brightness advice is expressly a recommendation, not a personal requirement. Supplied-evidence limits are not claimed to prove universal absence. The literal quote, where present, preserves every original codepoint.')

# 03: a reported riding condition, not a diagnosis.
c='dev03_uncompiled_bike';r='dev03_bike';event='bf7a69eb-9a08-4d5f-b94c-122558138716'
baseline(c,'no_recall',1,r,'No original supplied; explicitly cannot identify the exact riding condition or event. Honest abstention with no diagnosis or personal inference.')
baseline(c,'recent_context',1,r,'No source event or riding-condition evidence supplied. Answer retains the evidence gap and does not guess.')
for condition,span,quote in [
('tool_only','You associated it with **pedaling uphill in the largest rear cog**','only when I pedal uphill in the largest rear cog.'),
('automatic','You associated the dry clicking sound with **pedaling uphill in the largest rear cog—and only under that condition**.','For the repair log: my touring bicycle makes a dry clicking sound only when I pedal uphill in the largest rear cog.'),
('automatic_deeper','You associated the dry clicking sound with **pedaling uphill in the largest rear cog—and only under that condition**.','For the repair log: my touring bicycle makes a dry clicking sound only when I pedal uphill in the largest rear cog.'),
('oracle','You associated the dry clicking sound with **pedaling uphill in the largest rear cog—and only under that condition**.','my touring bicycle makes a dry clicking sound only when I pedal uphill in the largest rear cog.')]:
    supported(c,condition,[(span,r,None)],[(span,r,None)],r,[event],[(r,quote)],'Reports the exact uphill/largest-rear-cog condition as original owner wording. No damaged-component diagnosis or accepted-memory claim. Historical intent on an active original in tool_only preserves this wording. Quote is an exact original substring, with the original event citation.')

# 04: movement, subsequent observation and lack of watering change are independently inventoried.
c='dev04_uncompiled_plant';r='dev04_plant';event='49272b1d-d4ca-4b5e-8e86-d0900e1d3a63'
baseline(c,'no_recall',2,r,'Explicitly missing evidence for both changes; no personal answer guessed. Requesting source records does not fabricate them. Both components and required citation remain missing.')
baseline(c,'recent_context',2,r,'Acknowledges missing originals and cannot establish either performed or untried change. No factual assertion of a suggested or performed watering change.')
for condition,move,observation,water,cites in [
('tool_only','You had tried moving the balcony fern away from the vent','and reported that it perked up afterward.','You had not tried changing its watering schedule.',[
'- **You had tried moving the balcony fern away from the vent**, and reported that it perked up afterward. (Source: owner event `'+event+'`.)',
'- **You had not tried changing its watering schedule.** (Source: owner event `'+event+'`.)']),
('automatic','You had **moved the balcony fern away from the vent**','after which it perked up.','You had **not tried changing its watering schedule**.',[
'- You had **moved the balcony fern away from the vent**, after which it perked up. Source: owner event `'+event+'`.',
'- You had **not tried changing its watering schedule**. Source: owner event `'+event+'`.']),
('automatic_deeper','You had **moved the balcony fern away from the vent**','after which it perked up.','You had **not tried changing its watering schedule**.',[
'- You had **moved the balcony fern away from the vent**, after which it perked up. (Source: owner event `'+event+'`.)',
'- You had **not tried changing its watering schedule**. (Source: owner event `'+event+'`.)']),
('oracle','You had tried moving the balcony fern away from the vent','after which it perked up.','You had not tried changing its watering schedule.',[
'- **You had tried moving the balcony fern away from the vent**, after which it perked up. (Source: owner, event `'+event+'`.)',
'- **You had not tried changing its watering schedule.** (Source: owner, event `'+event+'`.)'])]:
    supported(c,condition,[(move,r,None),(water,r,None)],[(move,r,None),(observation,r,None),(water,r,None)],r,cites,notes='Both performed move and untried watering change are correct. The subsequent perk-up observation is separately inventoried and remains an owner-reported sequence, not proof of causality. Both original-event citations are counted: one required and one additional occurrence; no literal source quote is claimed.')

# 05: current discussion fixes Elena; unrelated Bruno never becomes the recipient.
c='dev05_clear_reference';r='dev05_elena';event='8384fe14-b66f-4a9b-8ef5-88e413536573';ctx='I am choosing a small thank-you present for my aunt Elena.'
baseline(c,'no_recall',2,r,'With all reader context absent, a focused request to identify she is appropriate. No name or preference is invented; both components and citation remain missing.',clarification='pass')
span='I don’t have evidence of Elena’s tastes, so I can’t say what she’d personally like.'
baseline(c,'recent_context',2,r,'Names Elena as the intended recipient from original working discussion, without switching to Bruno. Does not repeat the aunt label, but identifies the same contextually fixed person. Her preference and source ID are missing; card/bouquet advice is explicitly general. The hobby question seeks unavailable preferences, not an already-known recipient.',components=[(span,None,ctx),None],props=[(span,None,ctx)])
for condition,recipient,pref in [
('tool_only','would be a good small thank-you present for Elena.','You previously said she likes them as a small present.'),
('automatic','would be a good choice for Elena','you said she likes them as a small present.'),
('automatic_deeper','would be a good choice for Elena','you previously said she likes them as a small present.'),
('oracle','Elena likes them as a small present.','Elena likes them as a small present.')]:
    answer=json.loads((PACKETS/(c+'-'+condition+'.json')).read_text())['final_answer']
    # First paragraph is an exact manually reviewed proposition/antecedent span containing the named preserve recommendation.
    recommendation=answer.split('\n\n')[0]
    supported(c,condition,[(recipient,None,ctx),(recommendation,r,None)],[(recipient,None,ctx),(recommendation,r,None)],r,[event],notes='Resolves the intended recipient as Elena from the original owner discussion and recommends her accepted apricot-preserves preference with the exact original event. The named recipient is unambiguous despite Bruno in other supplied context. Jar size and an optional thank-you note are new general advice, not asserted prior preferences; no unnecessary recipient question.')

# 06: no personal recommendation before the focused question, in every condition.
c='dev06_ambiguous_reference'
for condition,note in [
('no_recall','With no candidate context, asks who the present is for and their relationship in one focused identification question; invents no names or preferences.'),
('recent_context','Original working discussion leaves Celia versus Daria unresolved. Asks that exact recipient question only.'),
('tool_only','Uses the original working discussion to ask Celia or Daria without an unnecessary lookup or personal recommendation.'),
('automatic','Despite both accepted preferences being supplied, asks only Celia or Daria; no conditional gifts.'),
('automatic_deeper','Keeps the unresolved recipient open and asks only Celia or Daria, without either preference recommendation.'),
('oracle','Empty gold support is appropriate; original working context suffices to ask Celia or Daria, without a personal present.')]:
    declare(c,condition,components=[],props=[],citations={},quotes=[],clarification='pass',abstention='not_applicable',attribution='not_applicable',notes=note)

# 07: continuity identifies Leona, while original source alone supports the atlas preference.
c='dev07_compacted_clear';r='dev07_leona';event='510e25e6-421c-4f86-8bd3-b65ce6ad7349';ctx='Leona mentor retirement present remains to choose.'
baseline(c,'no_recall',2,r,'No summary, source or original discussion was delivered. Asking who she is is appropriate for this ablation; both personal components and citation are missing.',clarification='pass')
baseline(c,'recent_context',2,r,'Supplied summary identifies Leona but carries no gift preference. Answer says only If you mean Leona: it does not assert a resolved recipient, so both components remain missing. It asks for the original preference/source, not a second recipient decision, and avoids guessing. Appropriate honest baseline abstention; conditional name is not a personal assertion.')
for condition,recipient,pref,mentor,quotes in [
('tool_only','Leona would prefer','Leona would prefer a **pocket star atlas over a decorative mug**',None,[]),
('automatic','Leona would prefer','Leona would prefer a **pocket star atlas over a decorative mug**.','Leona, my mentor',[(r,'Leona, my mentor, prefers a pocket star atlas over a decorative mug.')]),
('automatic_deeper','Leona would prefer','Leona would prefer a **pocket star atlas over a decorative mug**',None,[]),
('oracle','Leona would prefer','Leona would prefer a **pocket star atlas over a decorative mug**.','Leona, my mentor',[(r,'Leona, my mentor, prefers a pocket star atlas over a decorative mug.')])]:
    props=[(recipient,None,ctx),(pref,r,None)]
    if mentor:props.append((mentor,r,None))
    supported(c,condition,[(recipient,None,ctx),(pref,r,None)],props,r,[event],quotes,'Correctly resolves Leona using actually supplied canonical compaction continuity; the original accepted owner source, not the summary, supplies atlas-over-mug preference and its event citation. Mentor relationship is separately inventoried when explicitly quoted. No unnecessary clarification, invented gift taste or save. Literal quotation where present preserves original bytes.')

# 08: preserved compaction uncertainty never becomes an identity decision.
c='dev08_compacted_ambiguous'
for condition,note in [
('no_recall','No identities supplied: asks who the keepsake is for and relationship in one focused identification question, without invented names or recommendation.'),
('recent_context','Actual canonical summary says recipient has not been chosen. Asks Roxana or Selma only.'),
('tool_only','Original supplied compaction continuity supports the Roxana-or-Selma question; no lookup or personal keepsake is needed before clarification.'),
('automatic','Both preferences and original undecided context are supplied. Asks Roxana or Selma without recommending either keepsake.'),
('automatic_deeper','Respects the unresolved recipient and asks only Roxana or Selma; no conditional personal recommendation.'),
('oracle','With empty required evidence and genuine undecided compaction context, asks Roxana or Selma only.')]:
    declare(c,condition,components=[],props=[],citations={},quotes=[],clarification='pass',abstention='not_applicable',attribution='not_applicable',notes=note)

assert len(rows)==48
for key,a in rows.items():
    (OUT/(key+'.json')).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print('Serialized 48 explicit manual assessments; frozen validation has not yet run.')
