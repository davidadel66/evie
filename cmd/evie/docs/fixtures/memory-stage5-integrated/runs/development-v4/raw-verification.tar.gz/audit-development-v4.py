from pathlib import Path
import json,importlib.util
base=Path('/tmp/evie-memory-stage5');frozen=(base/'integrated-development-v4').resolve()
execution=json.loads((base/'integrated-development-v4-reader/execution.json').read_text())
assert execution['exit_code']==0 and execution['finished_at_utc'] and not execution['execution_exception']
s=importlib.util.spec_from_file_location('runner',frozen/'run.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
command=['python3','-B',str(frozen/'scorer.py'),'--freeze',str(frozen/'freeze.json'),'--results',str(base/'integrated-development-v4-reader'),'--output',str(base/'integrated-development-v4-evidence')]
r.run_command(command,Path('/Users/davidboktor/code/evie-memory-stage-5'),base/'integrated-development-v4-evidence-execution')
report=json.loads((base/'integrated-development-v4-evidence/evidence-report.json').read_text())
print(json.dumps(dict(assessments=len(list((base/'integrated-development-v4-evidence/assessment-packets').glob('*.json'))),violations=len(report['violations']),freeze_sha256=report['freeze_sha256'])),flush=True)
