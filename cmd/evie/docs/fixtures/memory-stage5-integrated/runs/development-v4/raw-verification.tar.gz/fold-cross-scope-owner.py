from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/Users/davidboktor/code/evie-memory-stage-5')
def raw(*a,data=None,env=None): return subprocess.check_output(['git',*a],cwd=root,input=data,env=env)
def git(*a,data=None,env=None): return raw(*a,data=data,env=env).decode().strip()
head=git('rev-parse','HEAD'); assert head=='0269e119e6ffb414a4b766efecf52800e1e08536'
owner=git('rev-parse','5808c54'); parent=git('rev-parse',owner+'^')
chain=git('rev-list','--reverse',parent+'..'+head).splitlines(); assert len(chain)==3 and chain[0]==owner
assert not git('diff','--cached','--name-only')
paths={
'internal/eviedb/retrieval_refresh_validity.go':'fbb3f7060607443b9217163fdd8ee33879ddbf6b6f5a85e5a1257d094742b379',
'internal/agent/retrieval_investigation_scope_refresh_test.go':'0898217b5b26d0f5760fc4745dd886f511aee66af4ae8951b2fbb4681e942b3e',
'cmd/evie/docs/active/memory-stage-5-investigation.md':'7961af311d5163c06fb2efd01d41f8ab51c6405ab90d245dbf615362c490063a'}
blobs={}
for name,expected in paths.items():
 data=(root/name).read_bytes(); assert hashlib.sha256(data).hexdigest()==expected
 blobs[name]=git('hash-object','-w','--stdin',data=data)
 for c in chain:
  if name.endswith('scope_refresh_test.go'): assert not git('ls-tree',c,name)
  elif not name.endswith('retrieval_refresh_validity.go'): assert raw('show',c+':'+name)==raw('show',owner+':'+name)
patch=raw('diff','HEAD','--',*paths)
assert b'memory_retrieval_event_fts' not in patch
mapping={};nextparent=parent
for i,c in enumerate(chain):
 index=Path('/tmp/evie-memory-stage5')/('cross-scope-fold-'+str(i)+'.index'); assert not index.exists()
 env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
 git('read-tree',c,env=env)
 git('apply','--cached','--whitespace=error','-',data=patch,env=env)
 name='internal/agent/retrieval_investigation_scope_refresh_test.go'
 git('update-index','--add','--cacheinfo','100644,'+blobs[name]+','+name,env=env)
 tree=git('write-tree',env=env)
 author=git('log','-1','--format=%an%x00%ae%x00%aI',c).split('\0');env.update(GIT_AUTHOR_NAME=author[0],GIT_AUTHOR_EMAIL=author[1],GIT_AUTHOR_DATE=author[2])
 updated=git('commit-tree',tree,'-p',nextparent,data=raw('log','-1','--format=%B',c),env=env)
 assert set(git('diff','--name-only',c,updated).splitlines())==set(paths)
 mapping[c]=updated;nextparent=updated
branch=git('symbolic-ref','HEAD');assert branch=='refs/heads/codex/memory-stage-5'
git('update-ref','refs/codex/memory-stage5-pre-cross-scope-fold',head)
git('update-ref',branch,nextparent,head);git('read-tree',nextparent)
assert len(git('rev-list','f27546d..HEAD').splitlines())==12
for name in paths: assert raw('show','HEAD:'+name)==(root/name).read_bytes()
record=dict(mapping=mapping,head=nextparent,owner162=mapping[owner],commit_count=12,preserved_uncommitted_issue167_and_168=True)
Path('/tmp/evie-memory-stage5/162-cross-scope-fold.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
