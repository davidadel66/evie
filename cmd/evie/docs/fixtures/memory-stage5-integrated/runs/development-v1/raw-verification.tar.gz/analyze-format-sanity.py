"""Synthetic-format audit probes over copied #161 artifacts; no new measurements."""
import copy,hashlib,json,sys,tempfile
from pathlib import Path
repo=Path('/Users/davidboktor/code/evie-memory-stage-5')
sys.path.insert(0,str(repo/'cmd/evie/docs/fixtures/memory-stage5-integrated'))
from analyze import evidence_report,go_json,wire_evidence
base=repo/'cmd/evie/docs/fixtures/memory-stage5-reference-reader/v2'
read=lambda p:json.loads(p.read_text())
original=read(base/'opaque_alias-case.json')['original_preferences'][0]
alias=next(a for a in original['aliases'] if a['value']=='MOM-27')
raw=(base/'opaque_alias-01-wire-request.json').read_bytes()
request=read(base/'opaque_alias-01-composed-request.json')
sha=hashlib.sha256(raw).hexdigest()
snapshot=next(s for s in read(base/'opaque_alias-request-snapshots.json') if s['request_sha256']==sha)
evidence=wire_evidence(json.loads(raw))
binding={'source':original['source'],'claim_id':original['claim']['claim_id'],'claim_operation_id':original['operation_id'],'subject_entity_id':original['claim']['subject_entity_id'],'accepted_aliases':original['aliases'],'valid_time':original['claim']['valid_time'],'exact_reference':{'intent':'current','identity_matches':[{'kind':'alias','entity_id':alias['entity_id'],'alias_id':alias['alias_id']}]}}
case={'id':'format_sanity','family':'format','gold':{'support_sets':[['original_alias']]}}
seed={'bindings':{'original_alias':binding},'rendered_question':'Format sanity only','case':case}
with tempfile.TemporaryDirectory(prefix='evie-analyze-format-sanity-') as directory:
 directory=Path(directory);inputs=directory/'inputs';(inputs/case['id']).mkdir(parents=True)
 def write(p,x):p.write_text(json.dumps(x))
 write(inputs/case['id']/'seed.json',seed)
 workload=directory/'workload.json';write(workload,{'partition':'synthetic_format_sanity','cases':[case]})
 gates=read(repo/'cmd/evie/docs/fixtures/memory-stage5-integrated/development/v1/proposed-gates.json');gates['conditions']=['automatic'];gates_path=directory/'gates.json';write(gates_path,gates)
 freeze={'inputs_path':str(inputs),'workload_path':str(workload),'gates_path':str(gates_path)}
 for probe in ['baseline','wrong_receipt_status','missing_second_wire','invalid_second_wire','invalid_projection']:
  results=directory/probe;results.mkdir();out=directory/(probe+'-audit');out.mkdir()
  memory_bytes=sum(len(go_json(m)) for m in request['messages'] if m.get('content','').startswith('EVIE_MEMORY_DATA\n'))
  for call in [1,2]:
   snap=copy.deepcopy(snapshot)
   if probe=='wrong_receipt_status':snap['memory']['status']='failed'
   dispatch={'call':call,'composed_request':request,'request_sha256':sha,'request_bytes':len(raw),'serialized_memory_message_bytes':memory_bytes,'serialized_outcome_replay_bytes':0,'cumulative_memory_delivery_bytes':memory_bytes*call,'snapshot':snap,'evidence':evidence,'charged_tool_call_ids':[],'boundary_errors':[]}
   stem=f'format_sanity-automatic-{call:02d}'
   write(results/(stem+'-dispatch.json'),dispatch)
   (results/(stem+'-encoded-request.json')).write_bytes(raw)
   if probe!='missing_second_wire' or call!=2:
    actual=raw
    if probe=='invalid_second_wire' and call==2:actual=b'{'
    if probe=='invalid_projection' and call==2:
     payload=json.loads(raw)
     next(i for i in payload['input'] if i.get('type')=='message' and isinstance(i.get('content'),str) and i['content'].startswith('EVIE_MEMORY_DATA\n'))['content']='EVIE_MEMORY_DATA\n[]'
     actual=json.dumps(payload).encode()
    (results/(stem+'-wire-request.json')).write_bytes(actual)
   write(results/(stem+'-http.json'),{'method':'POST','url':'https://openrouter.ai/api/v1/responses','status':200})
   write(results/(stem+'-answer.json'),{'response':read(base/'opaque_alias-01-normalized-response.json'),'elapsed_ns':1,'error':'<nil>'})
  write(results/'format_sanity-automatic-case.json',{'error':'<nil>','semantic_revisions_unchanged':True,'dispatch_count':2,'model_calls':2,'kernel_searches':1,'whole_turn_elapsed_ns':1,'final_answer':'SYNTHETIC format sanity only'})
  try:
   evidence_report(freeze,results,out)
   report=read(out/'evidence-report.json');row=report['cases'][0]
   assert report['results_manifest_sha256']==hashlib.sha256((out/'results-manifest.json').read_bytes()).hexdigest()
   if probe=='baseline':assert not report['violations'] and row['final']==['original_alias'],row
   else:assert report['violations'] and row['final']==[],row
   print('PASS',probe,{'violations':report['violations'],'successful_http_responses':row['successful_http_responses'],'final':row['final']})
  except Exception as error:
   print(probe,'CRASH',type(error).__name__,str(error));raise
