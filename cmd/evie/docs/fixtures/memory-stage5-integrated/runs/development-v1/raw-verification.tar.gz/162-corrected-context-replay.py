from pathlib import Path
import os, json, shutil, importlib.util, subprocess, hashlib, time
from datetime import datetime, timezone
root=Path('/Users/davidboktor/code/evie-memory-stage-5')
runner=root/'cmd/evie/docs/fixtures/memory-stage5-integrated/run.py'
spec=importlib.util.spec_from_file_location('runner',runner); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
oldpath=Path('/private/tmp/evie-memory-stage5/integrated-development-v1/freeze.json')
old=json.loads(oldpath.read_text())
out=Path('/private/tmp/evie-memory-stage5/162-corrected-context-replay-v1');out.mkdir(exist_ok=False)
source=out/'source';source.mkdir()
manifest={name:module.sha256(root/name) for name in module.compiled_paths(root)}
for name in manifest:
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
module.write_json(out/'compiled-source-manifest.json',manifest)
module.archive(source,manifest,out/'compiled-source.tar.gz')
binary=out/'integrated.test'
module.run_command(['go','test','-c','./internal/agent','-o',str(binary)],source,out/'build',module.worker_environment(old))
assert manifest=={name:module.sha256(root/name) for name in manifest}
shutil.copyfile(oldpath.parent/'input-manifest.json',out/'input-manifest.json')
f=dict(old)
f.update(version='diagnostic-corrected-context-replay-v1',frozen_at_utc=datetime.now(timezone.utc).isoformat(),binary_path=str(binary),binary_sha256=module.sha256(binary),source_root=str(source),compiled_source_manifest_sha256=module.sha256(out/'compiled-source-manifest.json'),compiled_source_archive_sha256=module.sha256(out/'compiled-source.tar.gz'),purpose='Single exact original failing case replay using corrected source; not a full cohort or a replacement of v1 measurements.',original_development_freeze_sha256=module.sha256(oldpath))
module.write_json(out/'freeze.json',f)
result=out/'results';result.mkdir()
env=module.worker_environment(old);env.update(EVIE_MEMORY_INTEGRATED_FREEZE=str(out/'freeze.json'),EVIE_MEMORY_INTEGRATED_INPUTS=old['inputs_path'],EVIE_MEMORY_READER_ARTIFACTS=str(result),EVIE_MEMORY_EMBEDDING_ENDPOINT=old['endpoint'])
cmd=[str(binary),'-test.run=^TestMemoryStage5IntegratedLocalEvaluation$/^dev05_clear_reference$/^tool_only$/^01$','-test.count=1','-test.v','-test.timeout=60s']
start=time.monotonic();utc=datetime.now(timezone.utc).isoformat()
with (out/'replay.log').open('x') as stream:r=subprocess.run(cmd,cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT)
integrity=module.tree_hashes(Path(old['inputs_path']))==json.loads((out/'input-manifest.json').read_text())
module.write_json(out/'replay.json',dict(command=cmd,cwd=str(source),started_at_utc=utc,finished_at_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,exit_code=r.returncode,canonical_inputs_unchanged=integrity,purpose=f['purpose'],freeze_sha256=module.sha256(out/'freeze.json')))
print((out/'replay.json').read_text());print((out/'replay.log').read_text())
raise SystemExit(r.returncode or (0 if integrity else 1))
