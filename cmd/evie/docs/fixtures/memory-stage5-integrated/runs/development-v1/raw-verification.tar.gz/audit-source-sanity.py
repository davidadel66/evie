"""Read-only public-API sanity checks using retained #159/#161 artifacts."""
import copy
import hashlib
import json
from pathlib import Path

repo = Path('/Users/davidboktor/code/evie-memory-stage-5')
module = repo / 'cmd/evie/docs/fixtures/memory-stage5-integrated/audit_sources.py'
namespace = {}
exec(compile(module.read_text(), str(module), 'exec'), namespace)
audit, merge = namespace['audit_evidence'], namespace['merge_support']
base = repo / 'cmd/evie/docs/fixtures'


def delivered(path):
    for message in json.loads(path.read_text())['messages']:
        if message.get('content', '').startswith('EVIE_MEMORY_DATA\n'):
            return json.loads(message['content'].split('\n', 1)[1])['evidence']
    raise AssertionError('retained request contains no memory evidence')


reference = base / 'memory-stage5-reference-reader/v2'
case = json.loads((reference / 'opaque_alias-case.json').read_text())
original = case['original_preferences'][0]
alias = next(a for a in original['aliases'] if a['value'] == 'MOM-27')
binding = {
    'source': original['source'], 'claim_id': original['claim']['claim_id'],
    'claim_operation_id': original['operation_id'],
    'subject_entity_id': original['claim']['subject_entity_id'],
    'accepted_aliases': original['aliases'], 'valid_time': original['claim']['valid_time'],
    'exact_reference': {'intent': 'current', 'identity_matches': [
        {'kind': 'alias', 'entity_id': alias['entity_id'], 'alias_id': alias['alias_id']}]} }
seed = {'bindings': {'opaque_alias': binding}}
evidence = delivered(reference / 'opaque_alias-01-composed-request.json')
result = audit(evidence, seed)
assert result['supported_records'] == ['opaque_alias'] and not result['violations'], result
missing = copy.deepcopy(evidence)
missing[0].pop('identity_matches')
result = audit(missing, seed)
assert result['present_records'] == ['opaque_alias'] and not result['supported_records'] and not result['violations'], result
bad = copy.deepcopy(evidence)
bad[0]['sources'][0]['observed_at'] = bad[0]['sources'][0]['observed_at'].replace('553000Z', '553001Z')
result = audit(bad, seed)
assert not result['supported_records'] and result['violations'], result

old = base / 'memory-stage5-reader/v4'
historical = delivered(old / 'historical_retired-01-composed-request.json')
item = historical[0]
# This old format lacks an independent seed; adapt the two actual Kernel source
# representations only to check compatibility. It is not a quality reassessment.
historical_seed = {'bindings': {'historical_retired': {
    'source': item['sources'][0], 'claim_id': item['claim_id'],
    'claim_operation_id': item['claim_operation_id'],
    'subject_entity_id': item['claim']['subject_entity_id'],
    'valid_time': item['effective_valid_time'], 'retired': True,
    'exact_reference': {'intent': 'historical'}}},
    'all_public_sources': [historical[1]['sources'][0]]}
result = audit(historical, historical_seed)
assert result['supported_records'] == ['historical_retired'] and not result['violations'], result

raw = next(i for i in delivered(old / 'tentative_quote_and_inference-01-composed-request.json') if i['kind'] == 'conversation_excerpt')
source = raw['sources'][0]
raw_seed = {'bindings': {'original_statement': {'source': source, 'exact_reference': {'intent': raw['intent']}}}}
raw_bytes = source['evidence'].encode()
start, end = map(int, source['locator_value'].split(':'))
boundaries = [i for i in range(1, len(raw_bytes)) if not (raw_bytes[i] & 192) == 128]
cut = boundaries[len(boundaries) // 2]
parts = []
for low, high in [(0, cut), (cut, len(raw_bytes))]:
    part = copy.deepcopy(raw)
    part['text'] = raw_bytes[low:high].decode()
    part['id'] = f"excerpt:{source['event_id']}:{start+low}:{start+high}"
    part['sources'][0].update(evidence=part['text'], locator_kind='utf8_byte_range',
        locator_value=f'{start+low}:{start+high}', evidence_sha256=hashlib.sha256(raw_bytes[low:high]).hexdigest())
    parts.append(part)
for part in parts:
    result = audit([part], raw_seed)
    assert not result['supported_records'] and not result['violations'], result
result = merge([[parts[0]], [parts[1]], [parts[0]]], raw_seed)
assert result['supported_records'] == ['original_statement'] and not result['violations'], result
invalid = copy.deepcopy(parts[1])
invalid['sources'][0]['actor'] = 'invented actor'
result = merge([[parts[0]], [invalid]], raw_seed)
assert not result['supported_records'] and result['violations'], result
result = audit([raw], {'bindings': {}, 'all_public_sources': [source]})
assert not result['supported_records'] and result['present_records'] == ['unlabeled-event:' + source['event_id']] and not result['violations'], result
result = audit([raw], {'bindings': {}})
assert not result['supported_records'] and result['violations'], result
print('PASS: actual alias/whole/range/hash-prefix/historical representations; missing identity loses support; one-nanosecond tamper fails; partial source earns no full credit; union deduplicates and rejects invalid spans; unlabeled and unresolved originals stay distinct. No new quality measurement.')
