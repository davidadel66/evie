import copy, hashlib, importlib.util, json, pathlib, tempfile, sys
root=pathlib.Path('/Users/davidboktor/code/evie-memory-stage-5/cmd/evie/docs/fixtures/memory-stage5-integrated')
sys.path.insert(0,str(root))
import resources, analyze, audit_sources
r=resources.Report.__new__(resources.Report)
r.helper=analyze;r.audit=audit_sources;r.limits=json.loads((root/'adopted-gates-v1.json').read_text())['resources']
text='The owner keeps a blue notebook.'
source={'event_id':'event-1','session_id':'session-1','source_scope_key':'global','event_part':'content','source_type':'user_message','actor':'owner','authority':'owner_statement','observed_at':'2026-09-01T00:00:00Z','evidence':text,'locator_kind':'utf8_byte_range','locator_value':'0:'+str(len(text.encode())),'evidence_sha256':hashlib.sha256(text.encode()).hexdigest(),'eligibility':'eligible'}
evidence={'id':'excerpt:event-1:'+source['locator_value'],'kind':'conversation_excerpt','intent':'current','valid_at_constrained':False,'current_status':'active','as_known_at':'2026-09-02T00:00:00Z','valid_at':'2026-09-02T00:00:00Z','scope_key':'global','status':'active','text':text,'sources':[source],'paths':['lexical']}
seed={'bindings':{},'all_public_sources':[source]};case={'gold':{}}
message={'role':'developer','content':'EVIE_MEMORY_DATA\n'+analyze.go_json({'evidence':[evidence]}).decode()}
payload={'model':'test','input':[{'type':'message','role':'developer','content':[{'type':'input_text','text':message['content']}]}]}
wire=analyze.go_json(payload);memory_bytes=len(analyze.go_json(message))
accounting={'version':'v1','search_attempts':1,'refresh_attempts':1,'reused_evidence':0,'cumulative_memory_bytes':memory_bytes,'kernel_work_ns':10,'outcomes':['success']}
d={'call':1,'composed_request':{'messages':[message]},'request_sha256':hashlib.sha256(wire).hexdigest(),'request_bytes':len(wire),'snapshot':{'request_sha256':hashlib.sha256(wire).hexdigest(),'serialized_bytes':len(wire),'memory':{'evidence':[analyze.reference(evidence)],'investigation':accounting}},'evidence':[evidence],'charged_tool_call_ids':[],'serialized_memory_message_bytes':memory_bytes,'serialized_outcome_replay_bytes':0,'cumulative_memory_delivery_bytes':memory_bytes,'boundary_errors':[]}
result={'status':'success','evidence':[evidence],'serialized_bytes':0};result['serialized_bytes']=len(analyze.go_json(result))
call={'query':{'kind':'conversation_excerpt','text':'notebook'},'status':'success','elapsed_ns':5,'result':result,'result_marshaled_bytes':len(analyze.go_json(result)),'result_reported_serialized_bytes':result['serialized_bytes'],'result_evidence_count':1,'evidence':[analyze.reference(evidence)]}
args=([d],[payload],[call],seed,case)
errors,metrics=r.turn(*args)
assert errors==[],errors
print('PASS exact public dispatch/source/ledger positive control')
for label,mutate in [
 ('hash',lambda a:a[0][0].update(request_sha256='wrong')),
 ('bytes',lambda a:a[0][0].update(request_bytes=1)),
 ('runtime ledger',lambda a:a[0][0]['snapshot']['memory']['investigation'].update(cumulative_memory_bytes=1)),
 ('ref metadata',lambda a:a[0][0]['snapshot']['memory']['evidence'][0].update(scope_key='other')),
 ('result size',lambda a:a[2][0].update(result_marshaled_bytes=1)),
 ('failed generator',lambda a:a[2][0].update(error='failed')),
 ('work undercount',lambda a:a[0][0]['snapshot']['memory']['investigation'].update(kernel_work_ns=1)),
 ('overcall',lambda a:a[2].extend([a[2][0]]*8)),
 ('expansion bound',lambda a:a[2][0]['query'].update(kind='conversation_expansion',before=3)),
 ('source hash',lambda a:a[3]['all_public_sources'][0].update(evidence_sha256='bad')),
]:
 mutated=copy.deepcopy(args);mutate(mutated)
 assert r.turn(*mutated)[0],label
 print('PASS rejects',label)
assert resources.quantiles(list(range(1,21)))=={'count':20,'p50_ns':10,'p95_ns':19,'max_ns':20}
print('PASS nearest-rank twenty-sample control')
# Go JSON and Vitest schema controls use real structured-log forms, not a test pass assertion.
r.checks=[];r.inputs={};r.summaries={};r.freeze_hash='frozen';r.freeze={'matrix_sha256':'matrix'}
r.matrix={'rows':[{'tests':[{'path':'internal/agent/x_test.go','name':'TestBoundary','seam':'complete_turn_real_sqlite'},{'path':'internal/web/ui/src/x.test.tsx','names':['preserves boundary'],'seam':'focused_ui'}]}]}
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp);g=p/'go.log';g.write_text(json.dumps({'Action':'pass','Package':'github.com/davidadel66/evie/internal/agent','Test':'TestBoundary'})+'\n')
 ui=p/'ui.log';ui.write_text('vitest output\n');uj=p/'ui.json';uj.write_text(json.dumps({'success':True,'numFailedTests':0,'testResults':[{'name':'/repo/internal/web/ui/src/x.test.tsx','assertionResults':[{'title':'preserves boundary','status':'passed'}]}]}))
 v=p/'verify.log';v.write_text('successful verify command output\n')
 a={'version':1,'freeze_sha256':'frozen','matrix_sha256':'matrix','commands':[
 {'id':'go','command':['go','test','./internal/agent','-json','-count=1'],'cwd':'/repo','log_path':str(g),'log_sha256':resources.sha(g),'exit_code':0,'kind':'go_matrix','matched_tests':[{'package':'github.com/davidadel66/evie/internal/agent','name':'TestBoundary'}]},
 {'id':'ui','command':['./node_modules/.bin/vitest','run'],'cwd':'/repo/internal/web/ui','log_path':str(ui),'log_sha256':resources.sha(ui),'exit_code':0,'kind':'ui_matrix','structured_results_path':str(uj),'structured_results_sha256':resources.sha(uj),'matched_tests':[{'path':'internal/web/ui/src/x.test.tsx','name':'preserves boundary'}]},
 {'id':'verify','command':['./scripts/verify-change.sh'],'cwd':'/repo','log_path':str(v),'log_sha256':resources.sha(v),'exit_code':0,'kind':'verify_change'}]}
 ap=p/'attest.json';ap.write_text(json.dumps(a));r.deterministic(ap)
 assert all(c['status']=='pass' for c in r.checks),r.checks
 print('PASS structured Go/UI/fullverify positive control')
 a['commands'][0]['matched_tests']=[];ap.write_text(json.dumps(a));r.checks=[];r.deterministic(ap)
 assert any(c['status']=='fail' for c in r.checks)
 print('PASS rejects false matrix matched-count assertion')
print('ALL SYNTHETIC CONTROLS PASS; no quantitative pilot claims')
# Read all twenty traces, reject a missing twentieth sample without optimistic p95.
r.checks=[];r.inputs={};r.summaries={};r.execution=lambda directory,mode:None
c={'id':'probe','memory_mode':'enabled','gold':{}}
r.cases=[c];r.conditions=['tool_only'];r.seeds={'probe':seed}
with tempfile.TemporaryDirectory() as tmp:
 import gzip
 path=pathlib.Path(tmp)/'probe-tool_only-local-traces.jsonl.gz'
 dispatch=copy.deepcopy(d);dispatch['elapsed_to_dispatch_ns']=100
 rows=[{'case_id':'probe','condition':'tool_only','repetition':i,'dispatches':[dispatch],'encoded_requests':[payload],'kernel_calls':[call],'error':'<nil>','semantic_revisions_unchanged':True,'reader_model_calls':0,'kernel_searches':1,'summed_observed_kernel_search_ns':5,'runtime_kernel_work_ns':10,'first_dispatch_elapsed_ns':100,'whole_turn_elapsed_ns':500} for i in range(1,21)]
 def traces(values):
  with gzip.open(path,'wt') as f:
   for row in values:f.write(json.dumps(row)+'\n')
 traces(rows);r.local(tmp)
 assert all(item['status']=='pass' for item in r.checks),r.checks
 print('PASS twenty-sample retained local trace positive control')
 traces(rows[:-1]);r.checks=[];r.local(tmp)
 assert any(item['status']=='incomplete' and item['id'].endswith('initial_p95') for item in r.checks)
 print('PASS missing attempt cannot establish a latency pass')
 r.checks=[];r.freeze={'partition':'development'};r.freeze_hash='frozen'
 r.gate('control',True,True)
 report=r.finish();assert report['all_required_gates_pass'] and not report['release_ready']
 print('PASS development all-gates does not declare release readiness')
print('EXTENDED SYNTHETIC CONTROLS PASS')
r.checks=[];r.inputs={};r.summaries={};r.execution=lambda directory,mode:None
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)/'measurements';p.mkdir()
 (p/'configuration.json').write_text(json.dumps({'repetitions_per_condition':20,'conditions':list(resources.MODES),'max_tail_ns':1000000000}))
 request={'bytes':len(wire),'sha256':hashlib.sha256(wire).hexdigest(),'encoded_json':wire.decode()}
 event={'Type':'context_snapshot','Payload':d['snapshot']}
 samples=[]
 for mode in resources.MODES:
  for repetition in range(20):
   samples.append({'mode':mode,'repetition':repetition,'complete':True,'failures':[],'error_classification':mode,'send_error':'expected terminal','tail_ns':100,'boundary_at':'2026-09-01T00:00:00Z','returned_at':'2026-09-01T00:00:00.000000100Z','approval_calls':0,'requests':[request,request],'events_before_boundary':[event],'events_after_return':[event],'accepted_revisions_before':[],'accepted_revisions_after':[],'replacement_lease':{'token':2} if mode=='lease_replacement' else None,'lease_after_return':{'token':2} if mode=='lease_replacement' else None,'evidence_before_boundary':d['snapshot']['memory']['evidence']})
 def write_samples():
  (p/'samples.ndjson').write_text(''.join(json.dumps(s)+'\n' for s in samples))
 write_samples();r.operating(tmp)
 assert all(item['status']=='pass' for item in r.checks),r.checks
 print('PASS sixty-sample operating JSON schema positive control')
 samples[0]['tail_ns']=1000000001;write_samples();r.checks=[];r.operating(tmp)
 assert any(item['status']=='fail' and item['id']=='operating:cancellation:maximum_tail' for item in r.checks)
 print('PASS one over-limit operating tail cannot be averaged away')
print('OPERATING SYNTHETIC CONTROLS PASS')
r.checks=[];r.inputs={};r.summaries={};r.execution=lambda directory,mode:None
c={'id':'indexcontrol','memory_mode':'enabled','records':[{}],'gold':{}}
coverage={'generation':'generation-1','state':'active','pending':0,'indexed':1}
r.cases=[c];r.seeds={c['id']:{**seed,'seed_database_sha256':'seed','index_elapsed_ns':100,'index_batches':1,'index_coverage':coverage,'rendered_question':'notebook'}}
empty_payload={'model':'test','input':[]};empty_wire=analyze.go_json(empty_payload)
empty_dispatch={'call':1,'composed_request':{'messages':[]},'request_sha256':hashlib.sha256(empty_wire).hexdigest(),'request_bytes':len(empty_wire),'snapshot':{'request_sha256':hashlib.sha256(empty_wire).hexdigest(),'serialized_bytes':len(empty_wire)},'evidence':[],'charged_tool_call_ids':[],'serialized_memory_message_bytes':0,'serialized_outcome_replay_bytes':0,'cumulative_memory_delivery_bytes':0,'boundary_errors':[]}
last=copy.deepcopy(d);last['call']=2
refs=copy.deepcopy(d['snapshot']['memory']['evidence']);refs[0]['as_known_at']='0001-01-01T00:00:00Z';refs[0]['valid_at']='0001-01-01T00:00:00Z'
turn={'query':'notebook','bounded_search_query':'notebook','dispatches':[empty_dispatch,last],'encoded_requests':[empty_payload,payload],'kernel_calls':[call],'canonical_references':refs,'accepted_revisions_unchanged':True,'delivered_sources_match_current_inspection':True}
stages=('baseline','reopened','rebuilt','before_append','incremental')
index={'version':'integrated-index-v1','case_id':c['id'],'test_failed':False,'seed_database_sha256':'seed','source_records':1,'original_seed_index_elapsed_ns':100,'original_seed_index_batches':1,'original_seed_index_coverage':coverage,'coverage':{s:coverage for s in (*stages,'after_append')},'storage':{s:{'database_bytes':4096,'wal_bytes':0,'derived_page_bytes':4096,'derived_storage_upper_bound_bytes':4096,'method':'dbstat-derived-pages-plus-all-WAL-upper-bound'} for s in stages},'rebuild':{'elapsed_ns':100,'refresh_batches':1,'coverage':coverage,'progress':[coverage]},'incremental_refresh':{'elapsed_ns':100,'refresh_batches':1,'coverage':coverage,'progress':[coverage]},'public_append_elapsed_ns':100,'warm_incremental_rss_before':{'pid':1,'method':'ps','bytes':100000},'warm_incremental_rss_after':{'pid':1,'method':'ps','bytes':101000},'warm_incremental_rss_delta_bytes':1000,'baseline':turn,'reopened':turn,'rebuilt':turn,'incremental_turn':turn,'restart_agreement':True,'rebuild_agreement':True,'incremental_original_source':source,'incremental_source_inspectable':True,'endpoint_rss_before':{'error':'not a real observation'},'endpoint_rss_after':{'error':'not a real observation'},'endpoint_observation':'synthetic schema control'}
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)/('index-'+c['id']+'.json');p.write_text(json.dumps(index));r.index(tmp)
 assert all(item['status']=='pass' for item in r.checks),r.checks
 print('PASS index schema/storage/RSS/recovery positive control')
 index['storage']['rebuilt']['derived_storage_upper_bound_bytes']=0;p.write_text(json.dumps(index));r.checks=[];r.index(tmp)
 assert any(item['status']=='fail' and item['id'].endswith('boundaries') for item in r.checks)
 print('PASS false derived-storage arithmetic cannot pass')
print('INDEX SYNTHETIC CONTROLS PASS')
