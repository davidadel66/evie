# Fresh heldout V2 semantic assessment: hold01–hold08

Assessor: `/root/architecture`, Codex agent. No human or second assessment is claimed. Reviewed after the full reader attempt closed and the frozen auditor produced all 144 packets. These 48 judgments do not establish overall heldout readiness.

Read each assigned final answer, actual supplied owner/assistant context, canonical compaction where present, accepted/original source binding, delivered memory, and every intermediate response/tool continuation. All 55 actual provider requests in this group use the same identity text (SHA-256 `475064f98dccd1ed4a6b6240ed3f5c118093d98d26e5bd13f8ffd06c36fa9ed5`); that text and the three tool schemas were examined as untrusted captured evaluation data. Fresh answers were assessed directly, without copied development judgments or keyword classification. There are no failed/empty reader turns in this group and no source-auditor violations in these 48 rows; the overall run's failures remain separate.

## Results

- 48 explicit assessments; frozen structural/provenance validation: 48 valid, zero errors/conflicts.
- 46 semantic passes, including honest missing-evidence baseline exceptions; this is not 46 complete personal answers.
- 72 expected personal components: 49 supported, 23 missing.
- 57 independently inventoried personal propositions: all grounded. This includes the separately stated saved-preference status in hold01, provisional diagnostic inference in hold04, and recipient interpretation separately from stored preference in hold05/07.
- 36 required citations: 22 correct and 14 missing. All actual event-ID occurrences were inventoried; zero additional citations.
- Zero passages are presented as literal original-source quotations. Quotation marks around illustrative teaching scripts, invented examples, fill-in templates, or a printer UI setting are not claims of verbatim stored text. This zero denominator is not a quotation-accuracy success rate.
- No fabricated citations, retired-as-current assertions, speaker/authority violations or silent conflict resolutions were found in this assigned group.

## Semantic failures retained

1. `hold03_damp_dough-oracle.json`: the source was delivered completely, and the answer correctly recounts both owner observations. It omits the required original event citation. Both components and both personal propositions keep their earned support; the citation remains missing and `semantic_pass` is false.
2. `hold07_handover_continuity-tool_only.json`: the delivered canonical summary correctly identifies Hollis, but the model makes no memory read and answers with generic walkthrough advice. The numbered-diagram preference and its original citation are absent. Recipient interpretation keeps its working-context credit. Tool-only has no honest-absence baseline exception, so `semantic_pass` is false.

## Decisions requiring semantic interpretation

The no-recall and recent-context baselines in answerable cases retain missing components/citations. Their generic advice does not become a stored preference, and hypothetical examples do not become past events. In hold05 recent-context, “Unless you know her preferred feedback style” makes the suggested format a generic starting point; the actual original discussion supports only Amara's identity. In hold07 recent-context, the actual canonical summary supports Hollis's identity, while the practical walkthrough is newly offered advice, not an assertion of Hollis's preference.

In hold06 no-recall, asking who is being taught and which process is one clarification of the teaching situation. The following “good default” is generic instruction, not a personalized choice for Ravi or Tomas. In hold08 no-recall, the identity/location question similarly asks for the missing pickup context without inventing either candidate or a meeting point. Both meet the meaning of the recipient-clarification obligation; question-clause counting is not used as a substitute for semantic assessment. All context-bearing hold06/08 answers ask only which named person is meant and make no conditional personal recommendations.

Hold03's moisture explanation is general reasoning tied to an attributed observation, not a claimed controlled experiment. Hold04's “points to” inference remains explicitly provisional and is inventoried separately from the two observed facts; it does not assert a completed repair or confirmed internal diagnosis. The hold01 recent-context printing advice is generic, not a claimed saved printer setting. All such distinctions are recorded in individual assessment notes.

## Verification and retained authorship

`python3 -B /tmp/evie-memory-stage5/author-architecture-heldout-v2-assessments.py` completed successfully. The script serializes explicit manually chosen judgments and exact spans, then calls the immutable heldout V2 `grader.py::validate_assessment` for each assigned packet. It does not choose semantic labels or call a model. Validation also checks the frozen grader/schema/rubric hashes, seed hashes, exact bindings/question identity, and every inventoried original event occurrence. Initial display-helper handling of a null evidence list was corrected only in the temporary viewer; no frozen file or judgment was changed to obtain validator success.

The check record is `architecture-assessment-check-heldout-v2.json`; `architecture-heldout-v2-assessment-summary.json` contains every assessment filename/hash and the exact authoring-script hash. The 48-file directory is `integrated-heldout-v2-assessments-architecture/`. The view helper is `view-architecture-heldout-v2-packets.py`. No production, evaluator, corpus, configuration, Git index/branch, model call, retry, or frozen artifact was changed.
