import pathlib,json,sys
P=pathlib.Path('/tmp/evie-memory-stage5/integrated-heldout-v2-evidence/assessment-packets')
case=sys.argv[1];conditions=sys.argv[2:]
for f in sorted(P.glob(case+'-*.json')):
 d=json.loads(f.read_text())
 if conditions and d['condition'] not in conditions:continue
 print('\nCASE',case,d['condition'],'ANSWER:',d['final_answer'])
 print('GOLD',d['gold'],'RECENT',d['recent_discussion_fixture'],'COMPACTION',d['compaction_fixture'])
 if d['condition']=='automatic':
  print('BINDINGS',json.dumps({k:{x:v.get(x) for x in ['source','subject_entity_id','record_kind','retired','valid_time']} for k,v in d['bindings'].items()},ensure_ascii=False))
 print('AUDIT',d['evidence_metrics']);print('READER_ERROR',d['reader_error']);print('ARTIFACTS',d['artifact_files'])
 seen={}
 for i,r in enumerate(d['actual_provider_inputs']):
  print('ACTUAL REQUEST',i)
  for m in r['input']:
   if m.get('type')=='reasoning':
    print('OPAQUE_REASONING_RECORD',m.get('id'));continue
   c=m.get('content','')
   if c.startswith('# Identity'):continue
   if c.startswith('EVIE_MEMORY_DATA\n'):
    z=json.loads(c.split('\n',1)[1]);print('MEMORYSTATUS',z.get('status'))
    for e in z.get('evidence',[]) or []:
     fields={k:v for k,v in e.items() if k in ['id','kind','intent','status','current_status','text','valid_at','valid_at_constrained','as_known_at','effective_valid_time','sources','claim','identity_matches']}
     if 'claim' in fields:fields['claim']={k:v for k,v in e['claim'].items() if k in ['subject_entity_id','object','valid_time','transaction_time']}
     for s in fields.get('sources',[]):
      for k in ['create','eligibility','operation_id','session_id','evidence_sha256','source_link_id','event_part']:s.pop(k,None)
     serialized=json.dumps(fields,ensure_ascii=False)
     if serialized in seen:print('EXACT_REPEAT_OF_REQUEST',seen[serialized],fields.get('id'))
     else:print('EVIDENCE',serialized);seen[serialized]=i
   else:print('MESSAGE',json.dumps(m,ensure_ascii=False))
