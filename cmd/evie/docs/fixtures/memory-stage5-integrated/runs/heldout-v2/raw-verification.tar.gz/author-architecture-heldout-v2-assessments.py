"""Serialize /root/architecture's fresh manual hold01–08 judgments.
This is an explicit judgment record, not an answer classifier. Span assertions
and the frozen API validate spelling/provenance after manual semantic review.
"""
import json,hashlib,importlib.util,re
from pathlib import Path
ROOT=Path('/tmp/evie-memory-stage5')
FREEZE=ROOT/'integrated-heldout-v2/freeze.json'
PACKETS=ROOT/'integrated-heldout-v2-evidence/assessment-packets'
OUT=ROOT/'integrated-heldout-v2-assessments-architecture'
assert not OUT.exists()
OUT.mkdir()
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(FREEZE)
assert sha(FREEZE)=='c6d6a2c8627580963fb7f2edb341173bd34487e09c80a3e9a9813f0fef169ed2'
for field in ['grader','assessment','rubric']:
 assert sha(f[field+'_path'])==f[field+'_sha256']
spec=importlib.util.spec_from_file_location('frozen_heldout_v2_grader',f['grader_path'])
g=importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
packets={}
for n in range(1,9):
 for p in PACKETS.glob(f'hold{n:02d}_*.json'):
  d=read(p); packets[(n,d['condition'])]=(p,d)
assert len(packets)==48
judgments={}
def evidence(span,record): return ('retrieved_evidence',span,record)
def context(span,text): return ('working_context',span,text)
def missing(): return None

def enter(n,cond,components,propositions,citation_status,semantic_pass,notes,*,attribution='not_applicable',abstention='not_applicable',clarification='not_applicable'):
 assert (n,cond) not in judgments
 p,d=packets[(n,cond)]; answer=d['final_answer'] or ''
 def item(v,status):
  if v is None: return {'status':'missing','answer_spans':[],'basis':'none','source_record_ids':[],'source_event_ids':[],'context_spans':[]}
  basis,span,origin=v; assert span in answer,(n,cond,span)
  records=[origin] if basis=='retrieved_evidence' else []
  events=[d['bindings'][origin]['source']['event_id']] if records else []
  return {'status':status,'answer_spans':[span],'basis':basis,'source_record_ids':records,'source_event_ids':events,'context_spans':[origin] if basis=='working_context' else []}
 comp=[dict(item(v,'supported'),index=i) for i,v in enumerate(components)]
 assert len(comp)==len(d['gold']['expected_answer_components'])
 props=[item(v,'grounded') for v in propositions]
 required=d['gold']['support_sets'][0]
 assert len(citation_status)==len(required)
 citations=[]
 for record,status in zip(required,citation_status):
  event=d['bindings'][record]['source']['event_id'] if status=='correct' else ''
  assert not event or answer.count(event)==1,(n,cond,'citation occurrence needs explicit additional inventory')
  citations.append({'record_id':record,'status':status,'cited_event_id':event,'answer_span':event})
 # Every quote below was examined manually: these 48 answers contain no claimed
 # verbatim source quotations. Illustrative teaching scripts/labels are new examples.
 a={'schema_version':1,'case_id':d['case_id'],'condition':cond,'freeze_sha256':sha(FREEZE),'packet_sha256':sha(p),'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),
 'assessor':{'kind':'agent','identity':'/root/architecture','role':'Codex agent semantic assessor; fresh heldout V2 hold01–08 review'},'second_assessment':None,'review_complete':True,
 'components':comp,'personal_propositions':props,'citations':citations,'additional_citations':[],'source_quotes':[],
 'behavior':{'clarification':clarification,'abstention':abstention,'attribution':attribution,'temporal':'not_applicable','conflict':'not_applicable','general':'not_applicable','unnecessary_clarification':False},
 'hard_violations':{k:0 for k in g.HARD},'semantic_pass':semantic_pass,'notes':notes}
 # Mechanical inventory cross-check only; status and semantic labels above are manual.
 ids=re.findall(r'\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b',answer)
 assert ids==[x['cited_event_id'] for x in citations if x['cited_event_id']],(n,cond,'unaccounted UUID')
 judgments[(n,cond)]=a

S=('automatic','automatic_deeper','oracle','tool_only')
# 01. A3 and included allowances are independent preference facts. The explicit
# saved-statement wording is separately inventoried, supported by accepted Claim.
for c in S:
 if c=='tool_only':
  spans=['A3 sheets','seam allowances already included','that matches your saved preference']
 else:
  spans=['A3 sheets','seam allowances already included','your saved statement' if c=='automatic' else 'your saved preference']
 vals=[evidence(s,'pattern_format') for s in spans]
 enter(1,c,vals[:2],vals,['correct'],True,'Both format details match the active accepted owner Claim and exact original event. The explicit saved-preference attribution is separately grounded. No action/printing claim or original-text quotation.',attribution='pass')
for c in ('no_recall','recent_context'):
 enter(1,c,[None,None],[],['missing'],True,'No original preference was delivered. The answer explicitly withholds a personal choice and asks for the missing preference, so the honest-absence baseline exception applies with zero component/citation credit. '+('Printing at actual size and checking the square are clearly generic advice, not a claim about a saved printer setting; “fit to page” is a UI-setting label, not a source quote.' if c=='recent_context' else 'The suggested page options are questions, not asserted personal preferences.'),abstention='pass')
# 02. All four evidence-using answers independently state the preference and its
# owner-reported explanation; no medical explanation or neighbor attribution.
for c in S:
 vals=[evidence('You’ve said you prefer one narrator throughout','single_narrator'),evidence('switching among an ensemble makes the voices harder to follow','single_narrator')]
 enter(2,c,[evidence('The **solo-narrated audiobook** fits you better.','single_narrator'),vals[1]],vals,['correct'],True,'The solo recommendation, preference and owner-reported difficulty are supported by the accepted original and cited accurately. The neighbor’s different taste is not attributed to the owner. No original-text quotation.',attribution='pass')
for c in ('no_recall','recent_context'):
 enter(2,c,[None,None],[],['missing'],True,'No listening source was delivered. The response explicitly declines to infer past taste and presents conditional generic comparisons, not personal facts. Honest baseline abstention; both required components and citation remain missing.',abstention='pass')
# 03. Original reported comparison is retained; ordinary moisture explanation is
# general reasoning, not an invented controlled experiment or accepted memory.
for c in S:
 a='In your comparison, the dough beside the open pantry window developed that skin' if c=='automatic' else ('Your comparison supports that: the dough beside the open pantry window dried out' if c=='oracle' else 'In your comparison, the dough beside the open pantry window dried out')
 b='the covered bowl stayed soft' if c in ('automatic','automatic_deeper') else 'the covered dough stayed soft'
 vals=[evidence(a,'dough_observation'),evidence(b,'dough_observation')]
 enter(3,c,vals,vals,['missing' if c=='oracle' else 'correct'],c!='oracle','The two observations are faithfully attributed to the owner’s comparison, not an accepted Claim or completed experiment. General evaporation/draft reasoning is not a new personal claim. '+('FAIL: despite complete original evidence, the oracle final answer omits the mandatory original event citation; correct observations retain coverage.' if c=='oracle' else 'The exact original event is cited; no original-text quotation.'),attribution='pass')
for c in ('no_recall','recent_context'):
 enter(3,c,[None,None],[],['missing'],True,'The answer says the prior comparison is unavailable and phrases the possible outcome conditionally. Generic proofing advice is not asserted as the owner’s actual observation. Honest baseline abstention retains both missing components and missing original citation.',abstention='pass')
# 04. The two observations and explicitly inferential diagnostic suggestion are
# separately inventoried. “Points to” is provisional reasoning, not proven repair.
spans4={
 'automatic':['You said the rattle happened only while the cap was dangling','stopped when you held it still','which points to the cap or tether rather than an internal fault'],
 'automatic_deeper':['You said the rattle happened only while the cap was hanging','holding it still stopped it','That points to the cap or tether vibrating against something rather than an internal fault.'],
 'oracle':['You said the rattle occurred only while the cap was hanging','holding it still stopped it','That points to the cap or tether rather than an internal fault.'],
 'tool_only':['You said the projector rattled only while the cap was hanging','holding it still stopped the noise','That points to the cap or tether vibrating against something, rather than an internal fault.']}
for c,spans in spans4.items():
 vals=[evidence(s,'projector_observation') for s in spans]
 enter(4,c,vals[:2],vals,['correct'],True,'The original owner account supports dangling-cap rattle and its stopping when held. The separately inventoried “points to” statement is provisional inference from that comparison; advice says to check/test, not that a fault is proven or repair completed. The exact owner event is cited; no source quote.',attribution='pass')
for c in ('no_recall','recent_context'):
 enter(4,c,[None,None],[],['missing'],True,'The answer explicitly lacks the earlier account and asks about the pattern of noise. External-check and cooling advice is general, not invented observation or repair. Honest baseline absence keeps all personal components/citation missing.',abstention='pass')
# 05. Recipient interpretation comes from actual original working context;
# accepted original alone supplies the preference. Examples are explicitly new.
ctx5='I am preparing rehearsal notes for Amara Fell. Help me choose a feedback format for her.'
for c in S:
 recipient=context('Give Amara',ctx5)
 pref=evidence('marked score pages','amara_format')
 enter(5,c,[recipient,pref],[recipient,pref],['correct'],True,'Actual working context clearly returns the rehearsal notes to Amara despite Priya’s separate riser topic. Her format comes from the active accepted original, cited accurately. Subsequent annotation instructions and any illustrative wording are new general advice, not saved preferences or source quotes.',attribution='pass',clarification='pass')
enter(5,'recent_context',[context('For Amara',ctx5),None],[context('For Amara',ctx5)],['missing'],True,'Actual context supports Amara as recipient. The source preference is absent; “Unless you know her preferred feedback style” explicitly frames the suggested format as a generic starting point, not Amara’s stored taste. Baseline exception applies only to the missing preference and citation. The illustrative correction is not an original-source quote.',attribution='pass',abstention='pass',clarification='pass')
enter(5,'no_recall',[None,None],[],['missing'],True,'No recipient context or accepted preference was supplied. The answer does not invent a name or claim to know her preference; it explicitly lacks the earlier notes and offers generic feedback advice with invented examples identified as examples. Honest baseline absence retains both missing components and citation.',abstention='pass')
# 06. Compound identity/process inquiry is one focused attempt to identify the
# teaching situation. Generic default advice is not a conditional recommendation
# personalized to either known candidate, nor a stored-preference assertion.
for c in ('automatic','automatic_deeper','oracle','recent_context','tool_only'):
 enter(6,c,[],[],[],True,'One focused recipient question resolves the actual two-person ambiguity before any personal recommendation. Candidate names are supplied in the actual context. No preference claims, citations or source quotations are made.',clarification='pass')
enter(6,'no_recall',[],[],[],True,'With all recipient context absent, the answer asks who is being taught and which process. These are linked clarification of the teaching situation, with no invented candidate names. The following “good default” is explicitly generic instruction, not a person-specific preference or conditional recommendation for Ravi/Tomas; no personal factual assertion or source quotation.',clarification='pass')
# 07. The exact supplied canonical compaction establishes recipient continuity,
# not the accepted preference. The tool-only model makes no read at all.
ctx7='The equipment handover is being prepared for Hollis Ward.'
for c in ('automatic','automatic_deeper','oracle'):
 vals=[context('For Hollis Ward',ctx7),evidence('numbered diagrams','hollis_format')]
 enter(7,c,vals,vals,['correct'],True,'The actual canonical summary resolves Hollis as recipient; the independently delivered accepted original establishes numbered diagrams and is cited accurately. Practical steps and illustrative captions are advice, not purported source quotes or completed operations. The equipment question where present does not reopen the already resolved recipient.',attribution='pass',clarification='pass')
for c in ('recent_context','tool_only'):
 vals=[context('For Hollis Ward',ctx7)]
 enter(7,c,[vals[0],None],vals,['missing'],c=='recent_context',('The actual summary identifies Hollis. No accepted preference is supplied; the response offers a generic walkthrough without claiming it was preferred. Honest baseline absence preserves recipient credit but leaves the numbered-diagram preference and source citation missing.' if c=='recent_context' else 'FAIL: the model resolves Hollis from the actual summary but invokes no memory read and gives only a generic walkthrough. The required numbered-diagram preference and original citation are absent. Tool-only is not eligible for the honest-absence baseline exception. Recipient credit remains grounded in context.')+' Instructional example wording is not an original source quote.',attribution='pass',abstention='pass' if c=='recent_context' else 'not_applicable',clarification='pass')
enter(7,'no_recall',[None,None],[],['missing'],True,'No recipient context or original preference is delivered. The answer asks about equipment/experience and gives a plainly generic safety walkthrough without inventing a recipient or claiming stored preference. Baseline absence keeps both expected personal components and original citation missing. Quoted fill-in-the-blank wording is an illustrative script, not a source quote.',abstention='pass')
# 08. All actual candidates remain unresolved; no conditional pickup instructions.
for c in ('automatic','automatic_deeper','oracle','recent_context','tool_only'):
 enter(8,c,[],[],[],True,'The actual canonical summary retains both plausible passengers. One focused question asks which person is meant, before any meeting-point recommendation; there are no personal assertions or citations.',clarification='pass')
enter(8,'no_recall',[],[],[],True,'With no passenger context delivered, the answer asks for the passenger identity and location in one pickup clarification. It invents neither candidate names nor a meeting point and gives no personal recommendation. The semantic purpose of the focused clarification is met.',clarification='pass')

assert set(judgments)==set(packets)
# Frozen structural/provenance verification is separate from the above judgments.
checks=[]
manifest=read(FREEZE.parent/'input-manifest.json')
for (n,c),a in sorted(judgments.items()):
 p,d=packets[(n,c)]
 seedpath=Path(f['inputs_path'])/d['case_id']/'seed.json'
 assert sha(seedpath)==manifest[d['case_id']+'/seed.json']
 seed=read(seedpath)
 assert d['bindings']==seed['bindings'] and d['question']==seed['rendered_question']
 sources=seed.get('all_public_sources') or []
 reader=seed['readers']['empty' if c=='no_recall' else 'recent']['id']
 working=[s for s in sources if s['session_id']==reader]
 case={'id':d['case_id'],'gold':d['gold']}
 result=g.validate_assessment(a,d,case,d['evidence_metrics'],c,sha(FREEZE),sha(p),sources,working)
 target=OUT/(d['case_id']+'-'+c+'.json')
 target.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
 checks.append({'path':str(target),'packet_sha256':sha(p),'assessment_sha256':sha(target),'semantic_pass_as_entered_by_assessor':a['semantic_pass'],'errors':result['errors'],'validation':result})
report={'schema_valid':all(not c['errors'] for c in checks),'assessment_count':len(checks),'semantic_pass_count':sum(a['semantic_pass'] for a in judgments.values()),'assessor':'/root/architecture','frozen_grader_sha256':sha(f['grader_path']),'freeze_sha256':sha(FREEZE),'semantic_judging_performed_by_script':False,'release_ready':False,'assessments':checks}
checkpath=ROOT/'architecture-assessment-check-heldout-v2.json'; checkpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
summary={'assessment_directory':str(OUT),'assessment_count':48,'semantic_passes':report['semantic_pass_count'],'semantic_failures':[{'case_id':a['case_id'],'condition':a['condition'],'notes':a['notes']} for a in judgments.values() if not a['semantic_pass']],
'components':{},'personal_propositions':{},'required_citations':{},'additional_citations':0,'source_quotes':0,'reader_errors':sum(d['reader_error']!='<nil>' for p,d in packets.values()),'schema_valid':report['schema_valid'],'validation_errors':[{'path':x['path'],'errors':x['errors']} for x in checks if x['errors']],
'files':{Path(x['path']).name:x['assessment_sha256'] for x in checks}}
for name,field in [('components','components'),('personal_propositions','personal_propositions'),('required_citations','citations')]:
 for a in judgments.values():
  for item in a[field]: summary[name][item['status']]=summary[name].get(item['status'],0)+1
summary['authoring_sha256']=sha(__file__)
(ROOT/'architecture-heldout-v2-assessment-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='files'},ensure_ascii=False,indent=2))
