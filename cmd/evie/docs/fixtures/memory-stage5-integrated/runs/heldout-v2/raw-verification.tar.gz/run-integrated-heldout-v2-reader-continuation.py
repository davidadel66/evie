from pathlib import Path
import json, importlib.util
from datetime import datetime, timezone
b=Path('/tmp/evie-memory-stage5'); root=Path('/Users/davidboktor/code/evie-memory-stage-5')
f=(b/'integrated-heldout-v2/freeze.json').resolve(); runner=f.parent/'run.py'
s=importlib.util.spec_from_file_location('frozen_heldout_v2_runner',runner);r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
withheld=json.loads((b/'integrated-heldout-v2-reader-not-run.json').read_text())
assert withheld['failed_modes']==['index','local']
assert not (b/'integrated-heldout-v2-reader').exists()
frozen=r.verify_freeze(f)
command=['python3','-B',str(runner),'run','--freeze',str(f),'--mode','reader','--output',str(b/'integrated-heldout-v2-reader')]
r.write_json(b/'integrated-heldout-v2-reader-continuation.json',dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),freeze_sha256=r.sha256(f),binary_sha256=frozen['binary_sha256'],workload_sha256=frozen['workload_sha256'],original_wrapper_withheld_record_sha256=r.sha256(b/'integrated-heldout-v2-reader-not-run.json'),command=command,attempt=1,reason='Complete the user-required independent reader assessment after local/index execution failures. This is the first reader attempt, following the original wrapper withholding it. The continuation changes the wrapper stop policy after observing prerequisite outputs and is explicitly a protocol deviation; it does not change frozen code, corpus, annotations, scores, budgets, or gates. Preserve every failed prerequisite and failed/blocked reader turn in the planned denominators. No failed gate is waived and no result may claim release readiness. No retry, warmup, replacement, or retuning.'))
r.write_json(b/'integrated-heldout-v2-reader-command.json',command)
try:r.run_command(command,root,b/'integrated-heldout-v2-reader-execution')
except RuntimeError as error: print(str(error),flush=True)
result=json.loads((b/'integrated-heldout-v2-reader-execution.json').read_text())
print(json.dumps(dict(stage='integrated-heldout-v2-reader',exit_code=result['exit_code'])),flush=True)
raise SystemExit(result['exit_code'])
