from pathlib import Path
source=Path('/tmp/evie-memory-stage5/preserve-integrated-heldout-v1.py')
s=source.read_text().replace('heldout-v1','heldout-v2')
# The actual exact-V4 checks were completed for V1 and are reused without relabeling their bytes.
s=s.replace('DEVELOPMENT = "integrated-development-v4"','DEVELOPMENT = "integrated-development-v4"\nFINAL_CHECKS = "integrated-heldout-v1-final-checks"\nSUPERSEDED_CHECKS = "integrated-heldout-v1-checks"')
s=s.replace('"raw-verification.tar.gz": [RUN + "-final-checks"]','"raw-verification.tar.gz": [FINAL_CHECKS]')
s=s.replace('"superseded-v3-checks.tar.gz": [RUN + "-checks"]','"superseded-v3-checks.tar.gz": [SUPERSEDED_CHECKS]')
s=s.replace('"168-verify-heldout-v2-final.py"','"168-verify-heldout-v1-final.py"')
s=s.replace('"168-verify-heldout-v2.py"','"168-verify-heldout-v1.py"')
s=s.replace('CURATION_DIR = Path("cmd/evie/docs/fixtures/memory-stage5-integrated/heldout/v1")','CURATION_DIR = Path("cmd/evie/docs/fixtures/memory-stage5-integrated/heldout/v2")\nORIGINAL_CURATION_DIR = Path("cmd/evie/docs/fixtures/memory-stage5-integrated/heldout/v1")\nORIGINAL_CURATION_FILES = ["curation-record.json", "curation.md", "report-author-metadata-exposure.json"]')
# Preparation failure was already preserved for V1. This new driver handles the completed V2 evaluation only.
start=s.index('\ndef make_failed_setup_plan(');end=s.index('\ndef copy_plan(',start);s=s[:start]+s[end:]
s=s.replace('    failed = commands.add_parser("failed-setup-plan")\n    failed.add_argument("--source", default="/tmp/evie-memory-stage5")\n    failed.add_argument("--output", required=True)\n','')
start=s.index('    elif args.mode == "failed-setup-plan":');end=s.index('    elif args.mode == "copy":',start);s=s[:start]+s[end:]
# Explicit original V1 curation and exposure are captured as bytes, not interpreted or displayed.
old='''    curation_members = {str(path.relative_to(REPO)): describe(path) for path in sorted((REPO / CURATION_DIR).rglob("*")) if path.is_file()}
    if not curation_members:
        raise ValueError("independent curation provenance is missing")'''
new='''    curation_members = {str(path.relative_to(REPO)): describe(path) for path in sorted((REPO / CURATION_DIR).rglob("*")) if path.is_file()}
    if not curation_members:
        raise ValueError("independent V2 correction provenance is missing")
    for name in ["preparation-correction.json", "preparation-correction.md", "workload.json"]:
        path = REPO / CURATION_DIR / name
        if str(path.relative_to(REPO)) not in curation_members:
            raise ValueError("V2 correction provenance missing: " + name)
    for name in ORIGINAL_CURATION_FILES:
        path = REPO / ORIGINAL_CURATION_DIR / name
        curation_members[str(path.relative_to(REPO))] = describe(path)'''
assert old in s;s=s.replace(old,new)
s=s.replace('"original V4 source_root/binary_path"','"original V4 source_root/binary_path"')
s=s.replace('"Earlier V3-only checks are historical evidence and cannot certify release."','"Earlier V3-only checks are historical evidence and cannot certify release; the separate original V1 final checks certify the unchanged V4 compiled input and matrix."')
s=s.replace('"curation_directory_byte_capture": str(CURATION_DIR),','"curation_directory_byte_capture": str(CURATION_DIR),\n            "original_v1_curation_byte_capture": [str(ORIGINAL_CURATION_DIR / name) for name in ORIGINAL_CURATION_FILES],\n            "reused_final_checks": FINAL_CHECKS,')
s=s.replace('"integrated-heldout-v2-checks and its old script are preserved in a separate historical archive, never release proof."','"integrated-heldout-v1-checks and its old V3 script stay separate; integrated-heldout-v1-final-checks and its exact original V4 check script are reused without relabeling."')
# Keep the metadata-only inventory explicit about both reused directories.
s=s.replace('"superseded_policy": "integrated-heldout-v1-checks','"superseded_policy": "integrated-heldout-v1-checks')
Path('/tmp/evie-memory-stage5/preserve-integrated-heldout-v2.py').write_text(s)
