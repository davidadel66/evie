"""External explicit-judgment authoring/check aid for this closed held-out group.
No automatic semantic judging, provider calls, or frozen-file writes.
"""
import json, pathlib, hashlib, importlib.util, sys
ROOT=pathlib.Path('/tmp/evie-memory-stage5')
FREEZE=ROOT/'integrated-heldout-v2/freeze.json'
EVIDENCE=ROOT/'integrated-heldout-v2-evidence/evidence-report.json'
OUTPUT=ROOT/'integrated-heldout-v2-assessments-requirements'

def read(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def context():
 f=read(FREEZE); fh=sha(FREEZE); assert fh=='c6d6a2c8627580963fb7f2edb341173bd34487e09c80a3e9a9813f0fef169ed2'
 assert f['partition']=='heldout'
 for field in ['grader','assessment','rubric','workload','gates']:
  assert sha(f[field+'_path'])==f[field+'_sha256'],field
 manifest_path=FREEZE.parent/'input-manifest.json'; assert sha(manifest_path)==f['input_manifest_sha256']; manifest=read(manifest_path)
 report=read(EVIDENCE); assert report['freeze_sha256']==fh and report['partition']=='heldout'
 assert report['scorer_sha256']==f['scorer_sha256'] and report['auditor_sha256']==f['auditor_sha256']
 rm=EVIDENCE.parent/'results-manifest.json';assert sha(rm)==report['results_manifest_sha256'];rm=read(rm)
 results=pathlib.Path(report['results_path']);execution=read(results/'execution.json');assert execution['finished_at_utc'] and execution['exit_code'] is not None
 spec=importlib.util.spec_from_file_location('heldout_v2_frozen_grader_requirements',f['grader_path']);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 cases={c['id']:c for c in read(f['workload_path'])['cases'] if any(c['id'].startswith('hold'+str(i)+'_') for i in range(17,25))};assert len(cases)==8
 rows={(r['case_id'],r['condition']):r for r in report['cases']};packets={};seeds={};packet_paths={};conds=read(f['gates_path'])['conditions']
 for cid,case in cases.items():
  seedpath=pathlib.Path(f['inputs_path'])/cid/'seed.json';assert sha(seedpath)==manifest[cid+'/seed.json'];seed=read(seedpath);seeds[cid]=seed
  for cond in conds:
   name=cid+'-'+cond;path=EVIDENCE.parent/'assessment-packets'/(name+'.json');p=read(path);resultpath=results/(name+'-case.json');assert sha(resultpath)==rm[resultpath.name];result=read(resultpath)
   assert p['gold']==case['gold'] and p['bindings']==seed['bindings'] and p['question']==seed['rendered_question']
   assert p['final_answer']==result['final_answer'] and p['reader_error']==result['error']
   assert p['evidence_metrics']==rows[(cid,cond)]
   packets[(cid,cond)]=p;packet_paths[(cid,cond)]=path
 return f,fh,g,cases,packets,packet_paths,seeds

def skeletons():
 f,fh,g,cases,packets,paths,seeds=context();OUTPUT.mkdir(exist_ok=False)
 for (cid,cond),p in packets.items():
  answer=p.get('final_answer') or ''
  a={'schema_version':1,'case_id':cid,'condition':cond,'freeze_sha256':fh,'packet_sha256':sha(paths[(cid,cond)]),'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),'assessor':{'kind':'agent','identity':'/root/requirements','role':'Fresh held-out semantic assessment of cases17–24 across six conditions'},'second_assessment':None,'review_complete':False,'components':[{'index':i,'status':None,'answer_spans':[],'basis':None,'source_record_ids':[],'source_event_ids':[],'context_spans':[]} for i in range(len(p['gold']['expected_answer_components']))],'personal_propositions':None,'citations':[{'record_id':r,'status':None,'cited_event_id':None,'answer_span':None} for r in p['gold']['support_sets'][0]],'additional_citations':None,'source_quotes':None,'behavior':{**{n:None for n in g.BEHAVIORS},'unnecessary_clarification':None},'hard_violations':{n:None for n in g.HARD},'semantic_pass':None,'notes':''}
  (OUTPUT/(cid+'-'+cond+'.json')).write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
 print('48 incomplete skeletons created; no semantic labels filled.')

def check():
 f,fh,g,cases,packets,paths,seeds=context();found=list(OUTPUT.glob('*.json'));assert len(found)==48;checked=[]
 for path in sorted(found):
  a=read(path);key=(a['case_id'],a['condition']);p=packets[key];s=seeds[key[0]];sources=s['all_public_sources'];reader=s['readers']['empty' if key[1]=='no_recall' else 'recent']['id'];working=[v for v in sources if v['session_id']==reader]
  row=g.validate_assessment(a,p,cases[key[0]],p['evidence_metrics'],key[1],fh,sha(paths[key]),sources,working)
  checked.append({'file':path.name,'errors':row['errors'],'review_complete':a['review_complete'],'semantic_pass_as_entered':a['semantic_pass']})
 result={'freeze_sha256':fh,'grader_sha256':f['grader_sha256'],'assessment_count':len(checked),'assessments':checked,'schema_valid':all(not v['errors'] for v in checked),'semantic_judgment_performed_by_program':False,'release_ready':False}
 target=ROOT/'integrated-heldout-v2-assessments-requirements-check.json';target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return not result['schema_valid']
if __name__=='__main__':
 if sys.argv[1]=='skeletons':skeletons()
 elif sys.argv[1]=='check':sys.exit(check())
 else:raise ValueError('choose skeletons or check')
