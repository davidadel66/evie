from pathlib import Path
import importlib.util,json,collections
b=Path('/tmp/evie-memory-stage5');f=b/'integrated-heldout-v2/freeze.json'
s=importlib.util.spec_from_file_location('frozen_resources',f.parent/'resources.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.Report(f);r.setup()
for mode in ['local','index','operating']:r.stage(mode,lambda mode=mode:getattr(r,mode)(b/('integrated-heldout-v2-'+mode)))
out=dict(scope='Partial diagnostic reconstruction using exact frozen resource methods. Quality, reader and deterministic gates are not included; this is not a complete readiness report.',freeze_sha256=m.sha(f),resource_program_sha256=m.sha(f.parent/'resources.py'),gates=r.checks,summaries=r.summaries,input_sha256=r.inputs,execution_records=r.executions,release_ready=False)
p=b/'heldout-v2-local-index-operating-summary.json'
with p.open('x') as stream:json.dump(out,stream,indent=2,sort_keys=True,default=lambda v:sorted(v) if isinstance(v,set) else str(v));stream.write('\n')
print(json.dumps(dict(gate_counts=collections.Counter(x['status'] for x in r.checks),nonpassing=[x for x in r.checks if x['status']!='pass'],summary_keys=list(r.summaries))),flush=True)
