import json,sys,hashlib
from pathlib import Path
base=Path('/tmp/evie-memory-stage5/integrated-heldout-v2-evidence/assessment-packets')
seen_system={}
for n in map(int,sys.argv[1:]):
 paths=sorted(base.glob(f'hold{n:02d}_*.json'))
 first=json.loads(paths[0].read_text())
 print('\nCASE', first['case_id'],'GOLD',json.dumps(first['gold'],ensure_ascii=False),'ROLES',first['gate_roles'])
 print('QUESTION',first['question'])
 print('FIXTURE DISCUSSION',json.dumps(first['recent_discussion_fixture'],ensure_ascii=False),'COMPACTION',json.dumps(first['compaction_fixture'],ensure_ascii=False))
 for k,b in first['bindings'].items():
  print('BINDING',k,json.dumps({x:b.get(x) for x in ['record_kind','claim_id','claim_operation_id','subject_entity_id','retired','valid_time','source','accepted_aliases'] if x in b},ensure_ascii=False))
 for p in paths:
  d=json.loads(p.read_text()); print('\nCONDITION',d['condition'],'ERROR',d['reader_error'],'METRICS',json.dumps(d['evidence_metrics'],ensure_ascii=False))
  print('FINAL',json.dumps(d['final_answer'],ensure_ascii=False))
  seen_messages=set()
  for i,req in enumerate(d['actual_provider_inputs']):
   print('REQUEST',i+1)
   for m in req['input']:
    if m.get('role')=='system' and m.get('content','').startswith('# Identity'):
     h=hashlib.sha256(m['content'].encode()).hexdigest(); print('COMMON INSTRUCTIONS SHA',h); continue
    raw=json.dumps(m,ensure_ascii=False)
    if raw in seen_messages: print('REPLAY SAME MESSAGE'); continue
    seen_messages.add(raw)
    content=m.get('content','')
    if isinstance(content,str) and content.startswith('EVIE_MEMORY_DATA\n'):
     mem=json.loads(content.split('\n',1)[1]); print('MEMORY STATUS',mem['status'])
     for ev in (mem.get('evidence') or []):
      print('DELIVERED',json.dumps({**{k:ev.get(k) for k in ['kind','claim_id','claim_operation_id','intent','current_status','effective_valid_time','text','identity_matches','graph_paths'] if k in ev},'sources':[{k:s.get(k) for k in ['event_id','actor','authority','source_type','evidence','locator_kind','locator_value']} for s in ev.get('sources',[])]},ensure_ascii=False))
    else: print('ACTUAL MESSAGE',raw)
  for i,r in enumerate(d['intermediate_responses']):
   print('RESPONSE',i+1,json.dumps({'error':r.get('error'), 'choices':r.get('response',{}).get('choices')},ensure_ascii=False))
