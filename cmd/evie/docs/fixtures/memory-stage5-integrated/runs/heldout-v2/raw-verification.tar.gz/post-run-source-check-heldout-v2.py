from pathlib import Path
import importlib.util,hashlib,json
b=Path('/tmp/evie-memory-stage5');f=b/'integrated-heldout-v2/freeze.json';root=Path('/Users/davidboktor/code/evie-memory-stage-5')
s=importlib.util.spec_from_file_location('frozen_heldout_v2_runner',f.parent/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.verify_freeze(f)
manifest=json.loads((f.parent/'compiled-source-manifest.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in manifest.items())
reader=b/'integrated-heldout-v2-reader';execution=json.loads((reader/'execution.json').read_text());assert execution['finished_at_utc'] and execution['exit_code'] is not None
cases=list(reader.glob('*-case.json'));assert len(cases)==144
encoded=list(reader.glob('*-encoded-request.json'));wires=list(reader.glob('*-wire-request.json'));http=list(reader.glob('*-http.json'));answers=list(reader.glob('*-answer.json'));dispatches=list(reader.glob('*-dispatch.json'))
assert len(dispatches)==len(encoded)
for p in wires:assert p.read_bytes()==p.with_name(p.name.replace('-wire-request.json','-encoded-request.json')).read_bytes()
rows=[json.loads(p.read_text()) for p in cases]
observed=sum(r['model_calls'] for r in rows)
assert observed==len(answers)
assert sum(r['dispatch_count'] for r in rows)==len(dispatches)
assert len(wires)==len(http)
prepared_only=[p.name for p in encoded if not p.with_name(p.name.replace('-encoded-request.json','-wire-request.json')).exists()]
print(json.dumps(dict(frozen_inputs_verified=True,current_compiled_inputs_equal=len(manifest),reader_cases=len(cases),observed_model_calls=observed,prepared_dispatches=len(dispatches),encoded_requests=len(encoded),actual_http_requests=len(wires),http_status_artifacts=len(http),answer_artifacts=len(answers),exact_actual_wire_and_encoded_agreement=True,prepared_only_requests=prepared_only,turn_errors=sum(r.get('error')!='<nil>' for r in rows),note='Prepared-only requests are retained failures, not observed HTTP dispatches. This integrity check does not waive any frozen source, quality, or resource gate.')),flush=True)
