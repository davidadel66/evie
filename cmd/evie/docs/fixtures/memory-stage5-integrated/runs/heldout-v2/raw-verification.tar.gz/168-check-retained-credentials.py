from pathlib import Path
import os,subprocess,json,gzip,io,tarfile,hashlib
from datetime import datetime,timezone
root=Path('/Users/davidboktor/code/evie-memory-stage-5')
secrets={v.encode() for k,v in os.environ.items() if any(t in k.upper() for t in ['API_KEY','ACCESS_TOKEN','AUTH_TOKEN','SECRET_KEY']) and len(v)>=16}
assert secrets, 'No inherited credential values available for exact-value check'
paths=set(subprocess.check_output(['git','diff','--name-only','f27546d...HEAD'],cwd=root,text=True).splitlines())
paths.update(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
paths.update(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
findings=[];checked_bytes=0;checked_streams=0;files={}
def scan(data,label,depth=0):
 global checked_bytes,checked_streams
 checked_bytes+=len(data);checked_streams+=1
 if any(value in data for value in secrets):findings.append(label)
 if depth>=4:return
 if data.startswith(b'\x1f\x8b'):
  scan(gzip.decompress(data),label+'::gzip',depth+1)
 elif len(data)>262 and data[257:262]==b'ustar':
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as archive:
   for member in archive:
    if member.isfile():scan(archive.extractfile(member).read(),label+'::'+member.name,depth+1)
for name in sorted(paths):
 p=root/name
 if p.is_file():
  data=p.read_bytes();files[name]=hashlib.sha256(data).hexdigest();scan(data,name)
out=dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),scope='Exact inherited credential-value scan of changed tracked and untracked deliverable files, including nested gzip/tar payloads; does not claim arbitrary-secret detection.',credential_values_checked=len(secrets),files_checked=len(files),payload_streams_checked=checked_streams,payload_bytes_checked=checked_bytes,matching_paths=findings,file_sha256=files)
p=Path('/tmp/evie-memory-stage5/168-retained-credential-check.json')
with p.open('x') as stream:json.dump(out,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['file_sha256','matching_paths']} | {'match_count':len(findings)}),flush=True)
raise SystemExit(bool(findings))
