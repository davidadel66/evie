from pathlib import Path
import json,importlib.util
base=Path('/tmp/evie-memory-stage5');frozen=(base/'integrated-heldout-v2').resolve()
execution=json.loads((base/'integrated-heldout-v2-reader/execution.json').read_text())
assert execution['finished_at_utc'] and execution['exit_code'] is not None
s=importlib.util.spec_from_file_location('runner',frozen/'run.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
command=['python3','-B',str(frozen/'scorer.py'),'--freeze',str(frozen/'freeze.json'),'--results',str(base/'integrated-heldout-v2-reader'),'--output',str(base/'integrated-heldout-v2-evidence')]
try:r.run_command(command,Path('/Users/davidboktor/code/evie-memory-stage-5'),base/'integrated-heldout-v2-evidence-execution')
except RuntimeError as error:print(str(error),flush=True)
report_path=base/'integrated-heldout-v2-evidence/evidence-report.json'
if report_path.exists():
 report=json.loads(report_path.read_text())
 print(json.dumps(dict(assessments=len(list((report_path.parent/'assessment-packets').glob('*.json'))),violations=len(report['violations']),freeze_sha256=report['freeze_sha256'])),flush=True)
