import json,pathlib,sys
base=pathlib.Path('/tmp/evie-memory-stage5/integrated-heldout-v2-evidence/assessment-packets')
for n in sys.argv[1:]:
 files=sorted(base.glob('hold'+n+'_*'));p=json.loads(files[0].read_text());print('\nCASE',p['case_id']);print('QUESTION',p['question']);print('GOLD',json.dumps(p['gold'],ensure_ascii=False));print('RECENT',p['recent_discussion_fixture']);print('COMPACTION',p['compaction_fixture'])
 for name,b in p['bindings'].items():print('BOUND',name,b['record_kind'],'retired',b['retired'],json.dumps(b['source'],ensure_ascii=False))
 global_seen=set()
 for f in files:
  x=json.loads(f.read_text());print('\nCONDITION',x['condition'],'ERROR',x['reader_error']);print('SUPPORT',x['evidence_metrics']['union'],'FORBIDDEN',x['evidence_metrics']['violations']);print('ACTUAL INPUTS:')
  seen=set()
  for i,req in enumerate(x['actual_provider_inputs']):
   print('REQUEST',i+1)
   for item in req.get('input',req.get('messages',[])):
    content=item.get('content');content=content if isinstance(content,str) else json.dumps(content,ensure_ascii=False)
    if content.startswith('# Identity'):continue
    if content.startswith('EVIE_MEMORY_DATA\n'):
     data=json.loads(content.split('\n',1)[1]);print('MEMORY STATUS',data['status'])
     for e in data.get('evidence') or []:
      value={k:e.get(k) for k in ['id','kind','status','current_status','intent','effective_valid_time','conflicts','text']}; value['sources']=[{k:z.get(k) for k in ['event_id','actor','authority','evidence','locator_kind','locator_value','observed_at']} for z in e.get('sources',[])];s=json.dumps(value,ensure_ascii=False)
      if s not in global_seen:print('DELIVERED',s);global_seen.add(s)
      else:print('DELIVERED SAME',e['id'],e['kind'],e['intent'])
    else:
     s=json.dumps(item,ensure_ascii=False)
     if s not in seen: print('PUBLIC',s);seen.add(s)
  print('FINAL ANSWER\n'+x['final_answer'])
