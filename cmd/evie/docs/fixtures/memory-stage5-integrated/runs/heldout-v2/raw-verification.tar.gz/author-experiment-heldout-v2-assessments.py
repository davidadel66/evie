"""Serialize this agent's fresh, explicit hold09..16 semantic judgments.
No source/answer keywords determine grades; assertions below only verify exact spans.
Frozen evaluation programs, inputs and outputs are never edited.
"""
import json, pathlib, hashlib
B=pathlib.Path('/tmp/evie-memory-stage5')
P=B/'integrated-heldout-v2-evidence/assessment-packets'
O=B/'integrated-heldout-v2-assessments-experiment'
def packet(case, condition): return json.loads((P/f'{case}-{condition}.json').read_text())
def support(span,*records,basis='retrieved_evidence',context=()):
 return dict(status='supported',answer_spans=[span] if isinstance(span,str) else list(span),basis=basis,source_record_ids=list(records),source_event_ids=[],context_spans=list(context))
def missing(): return dict(status='missing',answer_spans=[],basis='none',source_record_ids=[],source_event_ids=[],context_spans=[])
def prop(span,*records,basis='retrieved_evidence',context=()):
 d=support(span,*records,basis=basis,context=context);d['status']='grounded';return d
def quote(record,text): return dict(status='correct',source_record_id=record,source_event_id='',answer_span=text,quote=text)
def save(case,condition,components,propositions,cited,quotes,semantic,notes,extras=(),temporal='not_applicable',abstention='not_applicable',attribution='pass',clarification='not_applicable'):
 p=packet(case,condition);f=O/f'{case}-{condition}.json';d=json.loads(f.read_text());answer=p['final_answer'];bindings=p['bindings']
 assert len(components)==len(p['gold']['expected_answer_components']),(case,condition)
 for i,c in enumerate(components): c['index']=i
 for c in components+propositions:
  assert all(s in answer for s in c['answer_spans']),(case,condition,c)
  c['source_event_ids']=[bindings[r]['source']['event_id'] for r in c['source_record_ids']]
 for q in quotes:
  q['source_event_id']=bindings[q['source_record_id']]['source']['event_id']
  assert q['quote'] in answer and q['quote'] in bindings[q['source_record_id']]['source']['evidence'],(case,condition,q)
 citations=[]
 for r in p['gold']['support_sets'][0]:
  event=bindings[r]['source']['event_id'] if r in cited else ''
  assert not event or event in answer
  citations.append(dict(record_id=r,status='correct' if r in cited else 'missing',cited_event_id=event,answer_span=event))
 additional=[]
 for r in extras:
  event=bindings[r]['source']['event_id'];assert event in answer
  additional.append(dict(status='correct',cited_event_id=event,answer_span=event,source_record_ids=[r],source_event_ids=[event]))
 d.update(review_complete=True,components=components,personal_propositions=propositions,citations=citations,additional_citations=additional,source_quotes=quotes,behavior=dict(clarification=clarification,abstention=abstention,attribution=attribution,temporal=temporal,conflict='not_applicable',general='not_applicable',unnecessary_clarification=False),hard_violations=dict(fabricated_source_citations=0,retired_as_current_assertions=0,authority_or_speaker_violations=0,silent_conflict_resolutions=0),semantic_pass=semantic,notes='Fresh held-out v2 manual agent assessment; all actual inputs, original bindings and answer read. '+notes)
 assert d['assessor']['kind']=='agent' and d['assessor']['identity']=='/root/experiment_readiness'
 f.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')

# These sixteen baseline answers were individually read. They make no personal
# factual assertion and seek unavailable identifying/context evidence without guesses.
baselines={
'hold09_darkroom_alias':'Asks which Quill is meant; no darkroom, identity, alias or citation is invented.',
'hold10_instrument_entity_id':'Cannot resolve the exact entity identifier from its available information and asks which source it belongs to; no instrument or identity asserted.',
'hold11_observatory_chain':'Asks which observatory Nadia volunteers with, rather than inventing an observatory or instrument checker.',
'hold12_screen_free_errands':'Asks which sort of stops the question concerns; no claimed stored preference or personalized paper recommendation appears.',
'hold13_shadow_box_choice':'Explicitly lacks the previous discussion and asks for the exchange/options; does not invent the selected backing or reason.',
'hold14_divider_trial':'Explicitly lacks the earlier discussion and cannot establish a final cabinet design or completed load test. The proposed review of future notes is not a claim that any test occurred.',
'hold15_archive_historical':'Cannot access the historical record and enumerates the information needed to answer, without inventing the venue, interval, retirement or observation timestamp.',
'hold16_print_returns_current':'Asks which print cooperative is meant and explicitly lacks its current hand-in and receipt locations; no retired wording or invented current location appears.'}
for case,note in baselines.items():
 for condition in ['no_recall','recent_context']:
  save(case,condition,[missing() for _ in packet(case,condition)['gold']['expected_answer_components']],[],[],[],True,'Honest-absence comparison baseline: '+note+' All missing components and original citations remain in their denominators. This semantic abstention pass confers zero personal answer coverage.',abstention='pass',clarification='pass' if case!='hold15_archive_historical' else 'not_applicable',attribution='not_applicable',temporal='pass' if case in ('hold15_archive_historical','hold16_print_returns_current') else 'not_applicable')

case='hold09_darkroom_alias'
rows={
'automatic':('Quill—Juniper Moss—uses the **Tern darkroom**.','Quill—Juniper Moss'),
'automatic_deeper':('Quill—Juniper Moss—uses the **Tern darkroom**.','Quill—Juniper Moss'),
'oracle':('Quill uses the **Tern darkroom**.',None),
'tool_only':('Quill—your nickname for Juniper Moss—uses the **Tern darkroom**.','Quill—your nickname for Juniper Moss')}
for condition,(span,identity) in rows.items():
 ps=([prop(identity,'quill_darkroom')] if identity else [])+[prop('uses the **Tern darkroom**.','quill_darkroom')]
 save(case,condition,[support(span,'quill_darkroom')],ps,['quill_darkroom'],[],True,'The accepted Quill-to-Juniper-Moss mapping and Tern-darkroom Claim are actually supplied. The response uses that requested identity, not Quilla Stone, and cites the exact original owner event. Oracle need not repeat the canonical name when it answers the bound alias correctly. No source text is claimed as a verbatim quotation.')

case='hold10_instrument_entity_id'
rows={
'automatic':'Entity ID `98e15ad8-5102-490f-bba4-dab571ae33fe` is **Soren Bell**',
'automatic_deeper':'Entity ID `98e15ad8-5102-490f-bba4-dab571ae33fe` is **Soren Bell**',
'oracle':'Entity `98e15ad8-5102-490f-bba4-dab571ae33fe` (Soren Bell)',
'tool_only':'Entity `98e15ad8-5102-490f-bba4-dab571ae33fe` is **Soren Bell**'}
for condition,identity in rows.items():
 instrument='plays the **alto recorder**.'
 save(case,condition,[support([identity,instrument],'soren_instrument')],[prop(identity,'soren_instrument'),prop(instrument,'soren_instrument')],['soren_instrument'],[],True,'The exact requested Entity ID is the actual accepted Claim subject for Soren Bell. Its original owner source supports alto recorder, and its exact event is cited. The near-name Soren Hale/tenor-horn record is not substituted. No invented saved action or verbatim quotation.')

case='hold11_observatory_chain'
for condition in ['automatic','automatic_deeper','oracle','tool_only']:
 relationship='Fern Observatory, where Nadia Rusk volunteers.'
 checker='Dr. Lenox Vale checks the instruments at Fern Observatory'
 cited=['nadia_observatory','fern_checker'] if condition in ('automatic','tool_only') else ['fern_checker']
 save(case,condition,[support(relationship,'nadia_observatory'),support(checker,'fern_checker')],[prop(relationship,'nadia_observatory'),prop(checker,'fern_checker')],cited,[],condition in ('automatic','tool_only'),'Both accepted source-bearing relationships were actually supplied: Nadia volunteers with Fern Observatory, whose instruments are checked by Dr. Lenox Vale. The answer correctly connects them. '+('Both original owner events are cited.' if condition in ('automatic','tool_only') else 'FAILURE: only the instrument-checker event is cited; the required original Nadia-to-observatory event is missing despite its evidence being supplied. Correct prose does not excuse the missing relationship citation. No wrong or fabricated event is asserted.'))

case='hold12_screen_free_errands'
rows={
'automatic':('A **printed errand checklist** would suit you best—you’ve said you prefer paper so you don’t have to unlock a screen while you’re out.','you’ve said you prefer paper','so you don’t have to unlock a screen while you’re out.'),
'automatic_deeper':('A **small printed errand checklist** would suit you best—you’ve said you prefer a printed list so you don’t have to unlock a screen while you’re out.','you’ve said you prefer a printed list','so you don’t have to unlock a screen while you’re out.'),
'oracle':('A **printed errand checklist** would suit you—you’ve said you prefer one so you don’t have to unlock a screen while you’re out.','you’ve said you prefer one','so you don’t have to unlock a screen while you’re out.')}
for condition,(component,pref,reason) in rows.items():
 note='The paper-checklist suggestion follows the original owner preference and stated screen-avoidance reason, both paraphrased faithfully with the exact original event. Additional pocket/route/check-box/pen suggestions are new general advice, not claims about the owner’s recorded behavior. No quotation is claimed. '
 if condition in ('automatic','automatic_deeper'):
  note+='EVALUATOR CONFLICT: actual successful HTTP input contains the complete original owner statement as an eligible ConversationExcerpt (UTF-8 bytes 0:82) with event eec0d0f0-428c-4313-9c86-bd0e21761bf3. The frozen accepted binding has present_records=[paper_errands] but union/final=[] because no accepted Claim was delivered. This assessment truthfully records the source-grounded owner report and correct citation; it grants NO accepted-memory retrieval credit and anticipates frozen validator rejection of this provenance. Do not relabel actually supported prose unsupported merely to make that validator pass.'
 else: note+='Oracle supplies the full accepted Claim and original owner source.'
 save(case,condition,[support(component,'paper_errands')],[prop(pref,'paper_errands'),prop(reason,'paper_errands')],['paper_errands'],[],True,note)
save(case,'tool_only',[missing()],[],[],[],False,'FAILURE: the accepted and conversation searches did not supply the paper preference. The answer asks a reasonable generic clarification about kinds of stops and makes no unsupported personal claim, but it omits the requested personalized paper recommendation and required original source citation. The honest-absence exception applies only to no_recall/recent_context.',clarification='pass',abstention='pass',attribution='not_applicable')

case='hold13_shadow_box_choice'
# Automatic received only comparison and assistant question, not the later owner choice.
a='you said it lies flat, whereas the cork catches on the glass lip.'
ps=[prop('**Grey felt looks like the likely choice**','backing_options'),prop('you said it lies flat','backing_options'),prop('the cork catches on the glass lip.','backing_options')]
save(case,'automatic',[missing(),support(a,'backing_options')],ps,['backing_options'],[],False,'FAILURE: the actual input supplies the owner comparison and assistant question, but not the later owner selection. The response accurately reports the fit comparison and clearly labels grey felt as a likely inference, while limiting its lack-of-confirmation statement to the available record. That qualified comparative inference is grounded in the supplied fit comparison, not credited as proof of an actual owner choice. Selection component and original selection citation remain missing. No final choice is falsely asserted; no authority violation or exact quote is claimed.',abstention='pass')
rows={
'automatic_deeper':('You chose **grey felt**','it lies flat','the cork tile catches on the glass lip.'),
'oracle':('You chose **grey felt**—the latter of the two options','it lies flat','the cork catches on the glass lip.'),
'tool_only':('You chose **grey felt**—you picked the latter of cork tile and grey felt.','felt lies flat','cork catches on the glass lip')}
for condition,(choice,felt,cork) in rows.items():
 save(case,condition,[support(choice,'backing_options','backing_selection'),support([felt,cork],'backing_options')],[prop(choice,'backing_options','backing_selection'),prop(felt,'backing_options'),prop(cork,'backing_options')],['backing_options','backing_selection'],[quote('backing_selection','the latter')] if condition=='automatic_deeper' else [],True,'The original owner option-order comparison plus subsequent owner selection jointly establish grey felt as the latter. Both sources are actually delivered and cited by their distinct original owner events. The reason is the recorded fit comparison: felt lies flat, cork catches on the glass lip. '+('The quoted fragment “the latter” exactly preserves original source bytes.' if condition=='automatic_deeper' else 'No verbatim source quotation is claimed.'))

case='hold14_divider_trial'
rows={
'automatic':('you were leaning toward sliding dividers but explicitly hadn’t settled it.','I recommended loading one drawer with full packets to check whether the dividers bow','**I have no confirmation that we performed that test**. That was advice, not a completed check.'),
'automatic_deeper':('you were leaning toward **sliding dividers**, but explicitly hadn’t settled on them.','I recommended loading one drawer with full packets and checking that the dividers didn’t bow','that was advice, not a recorded test result.'),
'oracle':('You were leaning toward **sliding dividers**, but explicitly said it wasn’t decided.','I recommended loading one drawer with full packets to check whether the dividers bowed.','That was a proposed test—not a recorded result. **I have no confirmation that we checked it under load.**'),
'tool_only':('You were leaning toward sliding dividers, but explicitly hadn’t settled it.','I suggested loading one drawer with full packets and checking that the dividers didn’t bow.','That was a recommendation, not a recorded test result.')}
choice_parts={
'automatic':('you were leaning toward sliding dividers','explicitly hadn’t settled it.'),
'automatic_deeper':('you were leaning toward **sliding dividers**','explicitly hadn’t settled on them.'),
'oracle':('You were leaning toward **sliding dividers**','explicitly said it wasn’t decided.'),
'tool_only':('You were leaning toward sliding dividers','explicitly hadn’t settled it.')}
for condition,(choice,advice,uncertain) in rows.items():
 inclination,provisional=choice_parts[condition]
 save(case,condition,[support(choice,'divider_tentative'),support([advice,uncertain],'divider_suggested_test')],[prop(inclination,'divider_tentative'),prop(provisional,'divider_tentative'),prop(advice,'divider_suggested_test'),prop(uncertain,'divider_suggested_test')],['divider_tentative','divider_suggested_test'],[],True,'The owner’s sliding-divider preference remains explicitly provisional. The assistant’s actual neighboring source recommends a drawer load/bowing check; the answer correctly attributes that advice to the assistant and does not claim a completed test. Both exact original actor/events are cited. Statements about lack of confirmation are limited to available evidence, not exhaustive claims about all history. No source quote is presented.')

case='hold15_archive_historical'
ps=[prop('The only owner-sourced record available says **Ashbridge vault**','current_archive_pickup'),prop('**Recorded validity interval:** unspecified (both start and end are null).','current_archive_pickup'),prop('**Retired now:** No—currently active.','current_archive_pickup'),prop('**Original statement recorded:** **2026-09-11 at 06:41:44.767903 UTC**.','current_archive_pickup')]
save(case,'automatic',[missing(),missing(),missing(),missing()],ps,[],[],False,'FAILURE: only the current Ashbridge-vault Claim and original owner source reached the reader. The response correctly refuses to backdate it to 2020, accurately reports its unspecified validity, current active status and actual September 2026 source observation timestamp, and cites the correct current event as an additional citation. It omits all four requested historical components and the required retired historical source citation. Automatic is not the no-recall baseline exception. No retired source reached this actual HTTP request or was asserted as current.',extras=['current_archive_pickup'],temporal='pass',abstention='pass')
for condition in ['automatic_deeper','tool_only','oracle']:
 save(case,condition,[missing(),missing(),missing(),missing()],[],[],[],False,'EXECUTION FAILURE: final answer is empty after the frozen provider-boundary check rejected prepared historical evidence before the corresponding HTTP request. The historical source was NOT delivered to the reader. '+('Oracle had zero actual reader HTTP calls.' if condition=='oracle' else 'The earlier successful HTTP input did not deliver the historical source; the later prepared request is not source-delivery evidence.')+' All four historical components and required original citation remain missing. Empty output asserts no personal fact or retired-current claim. The frozen contradictory forbidden-text diagnostic is retained; no gate or historical-source rule is waived.',attribution='not_applicable')

case='hold16_print_returns_current'
rows={
'automatic':('Hand print-cooperative returns to the **front desk**.','The receipts are kept in the **violet binder**.'),
'automatic_deeper':('Hand print-cooperative returns to the **front desk**.','The receipts are kept in the **violet binder**.'),
'oracle':('Hand print-cooperative return parcels to the **front desk**.','The receipts are kept in the **violet binder**.'),
'tool_only':('Hand parcels to the **front desk**.','You previously said they’re kept in the **violet binder**.')}
for condition,(route,receipt) in rows.items():
 save(case,condition,[support(route,'active_return_route'),support(receipt,'receipt_location')],[prop(route,'active_return_route'),prop(receipt,'receipt_location')],['active_return_route','receipt_location'],[],True,'The active accepted front-desk return Claim and independent eligible owner ConversationExcerpt about the violet-binder receipts are both actually supplied. The response preserves those two facts and correctly cites both original owner events. Retiring the old route does not hide the live receipt source; no retired route wording is present in the actual provider inputs or answer. No exact source quote is claimed.',temporal='pass')

files=sorted(O.glob('*.json'));assert len(files)==48
for f in files: assert json.loads(f.read_text())['review_complete']
manifest={'schema_version':1,'assessor':{'kind':'agent','identity':'/root/experiment_readiness','role':'Codex agent semantic assessor'},'freeze_sha256':hashlib.sha256((B/'integrated-heldout-v2/freeze.json').read_bytes()).hexdigest(),'assessment_directory':str(O),'assessment_count':48,'files':[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]}
(B/'experiment-assessment-manifest-heldout-v2.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'assessment_count':48,'semantic_pass':sum(json.loads(f.read_text())['semantic_pass'] for f in files),'manifest':str(B/'experiment-assessment-manifest-heldout-v2.json')}))
