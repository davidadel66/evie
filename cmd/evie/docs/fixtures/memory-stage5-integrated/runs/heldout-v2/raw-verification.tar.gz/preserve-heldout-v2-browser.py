import datetime, gzip, hashlib, io, json, pathlib, shutil, tarfile
root = pathlib.Path('/Users/davidboktor/code/evie-memory-stage-5')
tmp = pathlib.Path('/tmp/evie-memory-stage5')
dest = root / 'cmd/evie/docs/fixtures/memory-stage5-integrated/heldout/v2/browser-demonstration'
dest.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
def write(name, value):
 p = dest / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(value, indent=2) + '\n')
def copy(src, rel):
 p = dest / rel; p.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, p)
for suffix in ['preflight-v1','preflight-v2','preflight-v3','live-v1']:
 copy(tmp / ('heldout-v2-browser-'+suffix+'.log'), 'logs/'+suffix+'.log')
for p in sorted((tmp/'heldout-v2-browser-manual').iterdir()):
 assert p.is_file(); copy(p, 'manual/'+p.name)
for name in ['ready.json','closed.json']:
 copy(tmp/'heldout-v2-browser-live-v1'/name, 'live-'+name)
copy(tmp/'heldout-v2-browser-preparation.md', 'preparation-notes.md')
copy(tmp/'heldout-v2-browser-source-proof.json', 'pre-run-source-proof.json')
for name in ['memory_stage5_browser_test.go','candidate_clock_test.go','repl_cancellation_test.go','session_composition_test.go']:
 copy(root/'cmd/evie'/name, 'source/'+name+'.txt')
compiled = tmp/'integrated-heldout-v2/compiled-source-manifest.json'
copy(compiled, 'frozen-compiled-source-manifest.json')
manifest=json.loads(compiled.read_text())
mismatches=[name for name, expected in manifest.items() if sha((root/name).read_bytes()) != expected]
assert not mismatches, mismatches
members={}
archive=dest/'session-artifacts.tar.gz'
with archive.open('wb') as out, gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as z, tarfile.open(mode='w',fileobj=z) as tar:
 for suffix in ['preflight-v1','preflight-v2','preflight-v3','live-v1']:
  directory=tmp/('heldout-v2-browser-'+suffix)
  for p in sorted(directory.iterdir()):
   assert p.is_file() and not p.is_symlink(), p
   rel=suffix+'/'+p.name; data=p.read_bytes()
   info=tarfile.TarInfo(rel); info.size=len(data); info.mode=0o600; info.mtime=0
   tar.addfile(info,io.BytesIO(data))
   members[rel]={'sha256':sha(data),'bytes':len(data),'original_path':str(p)}
write('archive-members.json',members)
closed=json.loads((dest/'live-closed.json').read_text()); fresh=closed['cases'][0]
assert closed['fresh_browser_answer_persisted'] and closed['fresh_scripted_response_returned']
assert not closed['manual_checks_attested_by_fixture']
assert len(fresh['answer_ids']) == len(fresh['snapshot_ids']) == 1
observations=json.loads((dest/'manual/observations.json').read_text())
assert len(observations['observations']) == 11 and len(observations['screenshots']) == 8
write('preservation-record.json',{
 'version':'stage5-browser-preservation-v1','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_checkout_head_at_preservation':'efef0dba4d34bc8d28d0b2f80ab91e1a3621f1f6',
 'not_reader_quality_evaluation':True,'browser_operator':'Codex root agent through the real browser UI','human_review_claimed':False,
 'closed_reason':closed['reason'],'live_process_exit_code':0,'live_test_wall_seconds_including_browser_wait':1576.97,
 'fresh_answer_id':fresh['answer_ids'][0],'fresh_snapshot_id':fresh['snapshot_ids'][0],
 'fresh_answer_persisted':True,'fresh_memory_statuses':fresh['memory_statuses'],
 'browser_ax_observations':len(observations['observations']),'browser_screenshots':len(observations['screenshots']),
 'archive_members':len(members),'captured_requests_by_run':{run:sum(k.startswith(run+'/request-') for k in members) for run in ['preflight-v1','preflight-v2','preflight-v3','live-v1']},
 'original_binary_path':str(tmp/'heldout-v2-browser.test'),'binary_included':False,'binary_sha256':sha((tmp/'heldout-v2-browser.test').read_bytes()),
 'helper_sha256':sha((root/'cmd/evie/memory_stage5_browser_test.go').read_bytes()),
 'frozen_compiled_input_count':len(manifest),'frozen_input_mismatches':mismatches,'new_cmd_helper_outside_frozen_manifest':True,
 'prebuild_complete_cmd_input_manifest_was_recorded':False,
 'source_snapshot_qualification':'Final helper bytes and three referenced existing cmd test-helper files are retained. The 394 frozen inputs are verified unchanged. Build reproduction uses the reviewed repository and these exact helper bytes; no bit-identical executable rebuild is claimed.'
})
write('preflight-history.json',{
 'classification':'fixture setup and compilation checks, not production RED/GREEN or quality measurements',
 'initial_compile':{'result':'failed','cause':'new fixture omitted internal/web import','diagnostic':'undefined: web','raw_log_available':False,'provenance':'recorded tool result before the named setup logs; summarized here without inventing a raw transcript'},
 'preflight-v1':{'result':'failed','cause':'new fixture omitted required lifecycle idempotency_key','log':'logs/preflight-v1.log','all_partial_data_retained':True,'exact_earlier_helper_snapshot_available':False},
 'preflight-v2':{'result':'passed','test_seconds':0.32,'package_seconds':0.662,'log':'logs/preflight-v2.log','change':'fixture supplies public lifecycle idempotency key'},
 'preflight-v3':{'result':'passed','test_seconds':0.33,'package_seconds':0.657,'log':'logs/preflight-v3.log','change':'assert both persisted unavailable receipts and add memory status metadata'},
 'production_changes':False,'frozen_outputs_changed':False
})
print(dest)
print('archive_members',len(members),'compressed_bytes',archive.stat().st_size)
