"""Serialize explicit fresh semantic judgments from all48 held-out answers.
This program never chooses a grade from answer keywords or previous labels.
"""
import pathlib,json,hashlib
R=pathlib.Path('/tmp/evie-memory-stage5');OUT=R/'integrated-heldout-v2-assessments-requirements';PACKETS=R/'integrated-heldout-v2-evidence/assessment-packets';D={}
# Each source-bearing tuple is an exact manually selected answer span and the
# original records supporting it. A None component is explicitly missing.
def put(n,condition,components,props,*,quotes=(),additional=(),pass_=True,unsupported=(),behavior=None,hard=None,note=''):
 D[(n,condition)]={'components':components,'props':props,'quotes':quotes,'additional':additional,'semantic_pass':pass_,'unsupported':unsupported,'behavior':behavior or {},'hard':hard or {},'note':note}
T='shift_ten';W='shift_twelve';N='shift_new_report'
put(17,'automatic',[
('both records remain active, so the stored disagreement hasn’t been formally resolved.',[T,W]),None],[
('**10:00** — earlier statement',[T,W]),('**12:00 (noon)** — newer statement',[T,W]),
('both records remain active, so the stored disagreement hasn’t been formally resolved.',[T,W])],pass_=False,
unsupported=['**Noon is your latest stated time**'],behavior={'attribution':'pass','temporal':'fail','conflict':'pass'},
note='Only the two older accepted times were supplied. The newer11:00 owner report and its citation are missing. Noon is newer than10:00 in the supplied pair, but the unqualified latest-stated-time assertion is unsupported by partial retrieval and conflicts with the independently declared newer episode. No accepted conflict is silently erased.')
put(17,'automatic_deeper',[
('My saved memories still disagree: **10:00**',[T,W]),
('Your newer roster update points to **11:00**, but that correction has not yet been reconciled in saved memory.',[T,W,N])],[
('**11:00 is the latest time you reported**, after checking the new roster.',[N]),
('**10:00**',[T]),('**12:00**',[W]),
('My saved memories still disagree:',[T,W]),
('that correction has not yet been reconciled in saved memory.',[T,W,N])],behavior={'attribution':'pass','temporal':'pass','conflict':'pass'},
note='A targeted read supplied the newer roster episode.11:00 is framed as the latest owner report, while the two saved entries explicitly remain unreconciled. The word correction describes the proposed update, not a completed memory mutation.')
put(17,'oracle',[
('both conflicting memories remain active.',[T,W]),
('**11:00 is the latest start time you reported**, after checking the new roster.',[N])],[
('**11:00 is the latest start time you reported**, after checking the new roster.',[N]),
('older saved times of **10:00** and **12:00**',[T,W]),
('both conflicting memories remain active.',[T,W])],pass_=False,
unsupported=['That explicit update resolves the disagreement between the older saved times of **10:00** and **12:00**'],
behavior={'attribution':'pass','temporal':'pass','conflict':'fail'},hard={'silent_conflict_resolutions':1},
note='All three sources and correct original citations are present. The answer nevertheless claims the newer update resolves the disagreement. That automatic-resolution assertion exceeds the owner episode’s authority and contradicts the still-active accepted conflict; acknowledging active entries later does not undo the explicit resolution claim. The hard conflict count records unsupported resolution without approved correction, not a claim that the answer omitted every mention of conflict.')
put(17,'tool_only',[
('**10:00** and **12:00** are both active entries',[T,W]),
('I’d use **11:00** based on your newer, explicit roster update, while noting that the saved entries haven’t been reconciled.',[T,W,N])],[
('You said you’d checked the new roster and your regular volunteer shift now starts at 11:00.',[N]),
('**10:00** and **12:00** are both active entries',[T,W]),
('There’s still a disagreement in saved memory:',[T,W]),
('the saved entries haven’t been reconciled.',[T,W,N])],behavior={'attribution':'pass','temporal':'pass','conflict':'pass'},
note='The practical11:00 recommendation is openly based on the newer owner report. Both saved values, their current conflict, and lack of reconciliation remain explicit; no approved correction or completed write is claimed.')
N='pickup_north';E='pickup_east';G='pickup_tentative'
put(18,'automatic',[
('Your saved information conflicts:',[N,E]),None],[
('**North Hall** — your statement',[N]),('**East gate** — your later statement',[N,E]),
('Both remain active',[N,E]),('I can’t confirm it replaced North Hall',[N,E])],pass_=False,behavior={'attribution':'pass','temporal':'pass','conflict':'pass','clarification':'pass'},
note='The response preserves the two accepted values but lacks the Garden kiosk report and its original citation because that episode was not supplied. East gate may be the change is explicitly a hypothesis followed by a question, not an asserted confirmed move; it does not substitute for the missing newer tentative source.')
put(18,'automatic_deeper',[
('both **North Hall** and **East gate** are saved as active, conflicting locations.',[N,E]),
('You also mentioned a possible move to **Garden kiosk**, explicitly saying it was **not confirmed**',[G])],[
('**North Hall**',[N]),('**East gate**',[E]),
('both **North Hall** and **East gate** are saved as active, conflicting locations.',[N,E]),
('neither explicitly replaces the other.',[N,E]),
('You also mentioned a possible move to **Garden kiosk**, explicitly saying it was **not confirmed**',[G])],behavior={'attribution':'pass','conflict':'pass','temporal':'pass','clarification':'pass'},
note='All three records are cited with correct speaker and state. The confirmation question is appropriate because the answer exposes the unresolved accepted conflict and tentative Garden kiosk possibility.')
put(18,'oracle',[
('conflicting with North Hall; neither entry is retired.',[N,E]),
('**Garden kiosk** was only a possible move you explicitly said was unconfirmed—not an established pickup location.',[G])],[
('**North Hall** is saved from your statement.',[N]),
('**East gate** is also saved from your statement',[E]),
('conflicting with North Hall; neither entry is retired.',[N,E]),
('**Garden kiosk** was only a possible move you explicitly said was unconfirmed—not an established pickup location.',[G])],behavior={'attribution':'pass','conflict':'pass','temporal':'pass','clarification':'pass'},
note='The accepted conflict and tentative report remain distinct. The answer neither picks a location nor claims a correction, and asks for confirmation.')
put(18,'tool_only',[
('two saved statements conflict',[N,E]),
('**Garden kiosk** — you said the coordinator might move pickup there, but you hadn’t confirmed it.',[G])],[
('**North Hall** — saved from your statement.',[N]),
('**East gate** — also saved from your statement',[E]),
('neither record supersedes the other.',[N,E]),
('**Garden kiosk** — you said the coordinator might move pickup there, but you hadn’t confirmed it.',[G])],behavior={'attribution':'pass','conflict':'pass','temporal':'pass','clarification':'pass'},
note='The answer retains both saved alternatives, their unresolved conflict, and the coordinator report’s uncertainty, with all three original citations.')
B='beatrice_quote'
put(19,'automatic',[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly recorded her words and stated they were not your own preference.',[B])],[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly recorded her words and stated they were not your own preference.',[B])],quotes=[(B,'Velvet collars itch; linen is comfortable.')],behavior={'attribution':'pass'},
note='The opening reported quotation is grounded by the explicitly identified owner-message source and subsequent statement that the owner recorded Beatrice’s words. Neither a direct Beatrice event nor an accepted owner preference is invented.')
put(19,'automatic_deeper',[
('Beatrice Kwan said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly said you were recording her words, not your own preference.',[B])],[
('Beatrice Kwan said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly said you were recording her words, not your own preference.',[B])],quotes=[(B,'Velvet collars itch; linen is comfortable.')],behavior={'attribution':'pass'},
note='Correct exact nested quotation and original owner event keep both speaker levels explicit and deny owner preference attribution.')
put(19,'oracle',[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly said you were recording her words, not your own preference.',[B])],[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly said you were recording her words, not your own preference.',[B])],quotes=[(B,'Velvet collars itch; linen is comfortable.')],behavior={'attribution':'pass'},
note='The source is the owner’s report of Beatrice, not a direct stored message from her. Exact wording and the own-preference boundary are preserved.')
put(19,'tool_only',[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly recorded her words, not your own preference.',[B])],[
('Beatrice said, “Velvet collars itch; linen is comfortable.”',[B]),
('You explicitly recorded her words, not your own preference.',[B])],quotes=[(B,'Velvet collars itch; linen is comfortable.')],behavior={'attribution':'pass'},
note='Historical retrieval of the active original owner episode supports the quote. The answer correctly identifies the reporting speaker and does not make an accepted clothing Claim.')
P='manual_problem';S='flag_suggestion'
put(20,'automatic',[None,
('That was my suggestion, not a preference you stated.',[S])],[
('That was my suggestion',[S]),
('The available excerpt doesn’t show you confirming that preference.',[S])],quotes=[(S,None)],pass_=False,behavior={'attribution':'pass'},
note='The actual assistant quote is exact and speculative. The answer narrows its nonconfirmation statement to the available excerpt, not all history. The owner’s losing-place problem and original owner-event citation are missing; the assistant source alone does not earn that coverage.')
put(20,'automatic_deeper',[None,
('It was my suggestion—not a preference you stated.',[S])],[
('It was my suggestion—not a preference you stated.',[S])],quotes=[(S,None)],pass_=False,behavior={'attribution':'pass'},
note='The reply correctly identifies the quoted words as the assistant’s suggestion. Read in the question’s explicit this-exchange scope, it does not claim exhaustive absence across all history. It omits the owner’s actual manual-reading problem and required owner-event citation; no missing context is invented or credited.')
put(20,'oracle',[
('You said, “I keep losing my place in long manuals.”',[P]),
('That was my suggestion, not a preference you stated.',[P,S])],[
('You said, “I keep losing my place in long manuals.”',[P]),
('I then suggested a page tab or removable index flag.',[S]),
('That was my suggestion, not a preference you stated.',[P,S])],quotes=[(P,None)],behavior={'attribution':'pass'},
note='Both sides of the actual exchange are supplied and correctly cited. The owner problem is quoted exactly, the suggested aid remains assistant-authored, and the conclusion concerns this exchange.')
put(20,'tool_only',[None,
('That wording was speculative, not confirmation of your preference.',[S])],[
('It was my suggestion',[S]),
('That wording was speculative, not confirmation of your preference.',[S])],quotes=[(S,None)],pass_=False,behavior={'attribution':'pass'},
note='The targeted read returned only the assistant episode. The exact quotation supports tentative suggestion attribution, not the omitted owner problem. Scope is the cited wording and exchange, not a claim that the owner never expressed this preference anywhere. Owner coverage/citation remains missing.')
M='mount_donation'
put(21,'automatic',[],[
('You said you donated the mount to the Brook astronomy club',[M]),
('hadn’t copied its serial label.',[M])],additional=[M],behavior={'attribution':'pass','abstention':'pass'},
note='Appropriate evidence-gap answer, with two independently supported owner-reported contextual propositions and an additional correct original-event citation. The suggestion to contact the club is general advice, not a fabricated suffix or claim of completed contact.')
put(21,'automatic_deeper',[],[
('You previously said you donated the mount to the Brook astronomy club',[M]),
('didn’t copy its serial label.',[M])],additional=[M],behavior={'attribution':'pass','abstention':'pass'},
note='The answer limits absence to available records, attributes the donation and missing copied label to the owner, and does not invent the suffix. The contextual citation must count as an additional citation even though the gold support set is empty.')
put(21,'tool_only',[],[
('You said you donated the mount to the Brook astronomy club',[M]),
('hadn’t copied its serial label.',[M])],additional=[M],behavior={'attribution':'pass','abstention':'pass'},
note='Partial reads expose donation context but no suffix. The answer faithfully reports two contextual facts and an additional original citation while preserving uncertainty; it does not equate empty accepted search with exhaustive absence.')
I='global_invoice_preference'
for cond,wording in [
('automatic','Use **plain-text attachments** for the seed-library project’s invoices, based on your saved general preference.'),
('automatic_deeper','Use **plain-text attachments** for the seed-library project’s invoices, based on your saved general preference.'),
('oracle','Use **plain-text attachments** for the seed-library project’s invoices, consistent with your saved general preference.'),
('tool_only','Use **plain-text attachments** for the seed-library project’s invoices, based on your saved general preference.')]:
 put(24,cond,[(wording,[I])],[(wording,[I])],quotes=[(I,None)],behavior={'attribution':'pass'},note='The recommendation applies the currently accepted Global preference to the requested project. The owner quote and exact original event are correct. Other-project and raw Global sources are absent from supplied payloads and the answer.')
# These ten baseline outcomes were individually read. General advice about
# attribution does not earn source-based personal components or citations.
BASE={
(17,'no_recall'):'No times or sources are invented. The conditional offer to examine conflicting times does not assert that a current time was established.',
(17,'recent_context'):'No unavailable start time is guessed. The question asks for absent records and does not invent a one-off exception.',
(18,'no_recall'):'The response appropriately requests the missing saved location and tentative change, without choosing a counter.',
(18,'recent_context'):'The response distinguishes unavailable saved context from a confirmed answer and invents no location.',
(19,'no_recall'):'The conditional explanation of third-party preference is appropriate general attribution advice, not personal source coverage. The actual Beatrice quotation and owner-event citation remain missing.',
(19,'recent_context'):'No fabric or quotation is invented. The answer preserves the distinction between attributed speech and owner confirmation but earns no missing personal component credit.',
(20,'no_recall'):'The assistant does not invent either side of the manual-reading exchange and refuses to attribute a preference without checking.',
(20,'recent_context'):'The actual exchange is unavailable. The response asks for it and does not invent the owner problem, suggestion source or endorsement.',
(24,'no_recall'):'The unavailable general invoice preference is not guessed or replaced with other-project content.',
(24,'recent_context'):'The response appropriately asks for the absent saved general preference; no forbidden format or source is revealed.'}
for k,note in BASE.items():D[k]={'baseline':True,'semantic_pass':True,'note':note}
ABS={
(21,'no_recall'):'The suffix is not available in current context. Asking for a receipt/photo is a focused request, not a claim that the suffix never existed.',
(21,'oracle'):'The oracle support set is empty. The answer limits absence to available context and requests possible original evidence without guessing.',
(21,'recent_context'):'The answer states a local evidence gap and makes no personal factual assertion beyond the task supplied in the question.',
(22,'automatic'):'Earlier details are unavailable; the answer does not guess a sculpture or claim no sponsorship record exists. Its request for neighborhood/year is permissible.',
(22,'automatic_deeper'):'The answer accurately reports unavailable Memory after the two disabled-read errors and does not mistake them for empty success.',
(22,'no_recall'):'I don’t have a record here is explicitly an availability statement, not a global assertion that no sponsorship record exists. No sculpture is invented.',
(22,'oracle'):'The unavailable oracle source is not disclosed. The answer limits its missing-details statement to this conversation and asks for context.',
(22,'recent_context'):'The locally unavailable record is not presented as proof of nonexistence. A focused art-walk clarification is appropriate.',
(22,'tool_only'):'The read errors reflect disabled memory access. The answer accurately states that access limit without revealing or inventing a sculpture.'}
for k,note in ABS.items():D[k]={'abstain':True,'semantic_pass':True,'note':note}
for cond in ['automatic','automatic_deeper','no_recall','oracle','recent_context','tool_only']:
 D[(23,cond)]={'general':True,'semantic_pass':True,'note':'The exact fresh answer is a faithful active-voice transformation using only the current request, without personalization, extra facts, source citations or clarification.'}
assert len(D)==48
for (n,cond),decision in D.items():
 files=list(OUT.glob(f'hold{n}_*-{cond}.json'));assert len(files)==1
 file=files[0];a=json.loads(file.read_text());packet=json.loads((PACKETS/file.name).read_text());answer=packet.get('final_answer') or ''
 assert answer and packet['reader_error']=='<nil>',(n,cond,'unexpected reader error')
 a['review_complete']=True;a['semantic_pass']=decision['semantic_pass'];a['personal_propositions']=[];a['additional_citations']=[];a['source_quotes']=[]
 a['behavior']={k:'not_applicable' for k in ['clarification','abstention','attribution','temporal','conflict','general']};a['behavior']['unnecessary_clarification']=False
 a['hard_violations']={k:0 for k in a['hard_violations']};a['notes']=decision['note']+' Fresh held-out agent assessment by /root/requirements; no second or human assessment. No frozen outputs or labels were changed.'
 def item(span,records,status,index=None):
  assert span in answer,(n,cond,span)
  for record in records:assert record in packet['evidence_metrics']['union'],(n,cond,record)
  v={'status':status,'answer_spans':[span],'basis':'retrieved_evidence' if records else 'none','source_record_ids':records,'source_event_ids':[packet['bindings'][r]['source']['event_id'] for r in records],'context_spans':[]}
  if index is not None:v['index']=index
  return v
 def missing(i):return {'index':i,'status':'missing','answer_spans':[],'basis':'none','source_record_ids':[],'source_event_ids':[],'context_spans':[]}
 if decision.get('baseline'):
  a['components']=[missing(i) for i in range(len(a['components']))]
  for c in a['citations']:c.update(status='missing',cited_event_id='',answer_span='')
  a['behavior']['abstention']='pass';a['behavior']['attribution']='pass'
  if n in [17,18]:a['behavior']['conflict']='pass'
 elif decision.get('abstain'):
  assert not a['components'] and not a['citations'];a['behavior']['abstention']='pass';a['behavior']['clarification']='pass'
 elif decision.get('general'):
  assert answer=='The technician placed the samples in the freezer.'
  a['components']=[{'index':0,'status':'supported','answer_spans':[answer],'basis':'current_request','source_record_ids':[],'source_event_ids':[],'context_spans':['The samples were placed in the freezer by the technician.']}];a['behavior']['general']='pass'
 else:
  a['components']=[missing(i) if value is None else item(value[0],value[1],'supported',i) for i,value in enumerate(decision['components'])]
  a['personal_propositions']=[item(s,ids,'grounded') for s,ids in decision['props']]+[item(s,[],'unsupported') for s in decision['unsupported']]
  a['behavior'].update(decision['behavior']);a['hard_violations'].update(decision['hard'])
  for c in a['citations']:
   event=packet['bindings'][c['record_id']]['source']['event_id']
   # Inventory is explicit: absent required reports in17/18automatic and20
   # retain missing citations, never copied from unseen bound source metadata.
   missing_record=(n==17 and cond=='automatic' and c['record_id']=='shift_new_report') or (n==18 and cond=='automatic' and c['record_id']=='pickup_tentative') or (n==20 and cond in ['automatic','automatic_deeper','tool_only'] and c['record_id']=='manual_problem')
   if missing_record:
    assert event not in answer;c.update(status='missing',cited_event_id='',answer_span='')
   else:
    assert event in answer;c.update(status='correct',cited_event_id=event,answer_span=event)
  for record in decision['additional']:
   event=packet['bindings'][record]['source']['event_id'];assert event in answer
   a['additional_citations'].append({'status':'correct','cited_event_id':event,'answer_span':event,'source_record_ids':[record],'source_event_ids':[event]})
  for record,quote in decision['quotes']:
   source=packet['bindings'][record]['source'];quote=source['evidence'] if quote is None else quote;assert quote in answer and quote in source['evidence']
   a['source_quotes'].append({'status':'correct','source_record_id':record,'source_event_id':source['event_id'],'answer_span':quote,'quote':quote})
 file.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print('48 explicit fresh held-out semantic assessments serialized.')
